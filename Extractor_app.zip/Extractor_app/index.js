var exec = require('child_process').exec;
var shell = require('shelljs');	
var newButton, openButton, saveButton;
var editor;
var menu;
var fileEntry;
var hasWriteAccess;

const {remote, clipboard} = require('electron');
const {Menu, MenuItem, dialog } = remote;
const fs = require("fs");

var onChosenFileToOpen = function(theFileEntry) {
  console.log(theFileEntry);
  //alert("topened file is:\n"+theFileEntry);

	document.getElementById('opened_file').innerHTML=theFileEntry;
	document.getElementById('output_file').innerHTML="Processing";
	// Replace macros in each .js file 
 	exec("cat "+theFileEntry+" | grep -E -o [a-zA-Z0-9.-]+@[a-zA-Z0-9.-]+ > ./output.txt", function (error, stdOut, stdErr) {
    		console.log("output=="+stdOut);
	document.getElementById('output_file').innerHTML="outfile saved in output.txt file";
		console.log("saved");
	});	
 // readFileIntoEditor(theFileEntry);
};


function handleOpenButton() {
  dialog.showOpenDialog({properties: ['openFile']}, function(filename) { 
      onChosenFileToOpen(filename.toString()); });
}


onload = function() {

  openButton = document.getElementById("open");

  openButton.addEventListener("click", handleOpenButton);

};
