var express = require('express');
var mongo=require("mongodb");
var assert=require("assert");
var url="mongodb://localhost:27017/todo_db";
var router = express.Router();


var name;
var resultArray=[];


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

/*SIGN UP ROUTE*/
router.post('/signup', function(req, res, next) {
    var person={
        name :req.body.username,
        password : req.body.password,
        email : req.body.email
    }
    console.log(person);
    mongo.connect(url,function(err,db){
        assert.equal(null,err);
        db.collection('user').insertOne(person,function(err,result){
            assert.equal(null,err);
            console.log("signup successfull");
            console.log("username is:"+person.name);
            db.close();
        });
    });
    res.render('index', { title: 'Express',u_name:name });
});


/*LOGIN ROUTE*/
router.post('/login', function(req, res) {
    resultArray = [];
    name = req.body.username;
    var password = req.body.password;
    console.log("login username is:" + name);
    console.log("login password is:" + password);
    mongo.connect(url, function (err, db) {
        assert.equal(null, err);

        db.collection("user").findOne({$and: [{"name": req.body.username}, {"password": req.body.password}]}, function (err, result) {
            if (err)
                throw err;
            if (result === null) {
                console.log("Enter Correct Details");
                res.send('Register to login');
            }
            else {
                mongo.connect(url, function (err, db) {
                    assert.equal(null, err);
                    var cursor = db.collection(name).find();
                    cursor.forEach(function (doc, err) {
                        assert.equal(null, err);
                        resultArray.push(doc);
                    }, function () {
                        db.close();
                        resultArray.forEach(function (doc, err) {
                        });
                        console.log("in the login in-complete");
                        for (var i = 0; i < resultArray.length; i++)
                            console.log(resultArray[i].task + "\n")

                    });
                });
                res.render("todo", {items: resultArray, u_name: name});
            }
        });
    });
});

/*ADD-ITEM TODO-List*/
router.post('/add-item', function(req, res, next) {
    resultArray=[];
    var item = {task: req.body.item}
    console.log(item);
    if (item.task.length > 0){
        console.log("add-item person-name=" + name);
    mongo.connect(url, function (err, db) {
        assert.equal(null, err);
        db.collection(name).insertOne(item, function (err, result) {
            assert.equal(null, err);
            console.log("item added:" + item.task);
            db.close();
        });
    });

    /*LIST ITEMS DISPLAY-INCOMPLETE*/

    mongo.connect(url, function (err, db) {
        assert.equal(null, err);
        var cursor = db.collection(name).find();
        cursor.forEach(function (doc, err) {
            assert.equal(null, err);
            resultArray.push(doc);
        }, function () {
            db.close();
            resultArray.forEach(function (doc, err) {
            });
            for(var i=0;i<resultArray.length;i++)
                console.log(resultArray[i].task+"\n")
            res.render("todo", {items: resultArray, u_name: name});
        });
    });
    }else{
        res.render("todo", {items: resultArray, u_name: name});
    }

});

/*DELETE-ITEM TODO-List*/
router.post('/del-item', function(req, res, next) {
    console.log("in the del-item_temp route");
    resultArray=[];
    var item = {task: req.body.item};
    console.log(item);
/*REMOVING ITEM FROM TASK LIST*/
        console.log("person-name=" + name);
        mongo.connect(url, function (err, db) {
            assert.equal(null, err);
            db.collection(name).removeOne({task:item.task}, function (err, result) {
                assert.equal(null, err);
                console.log("items deleted from task list:" + item.task);
                db.close();
            });
        });

    /*Display IN-COMPLETE ITEM LIST*/
    mongo.connect(url,function(err,db){
        assert.equal(null,err);
        var cursor=db.collection(name).find();
        cursor.forEach(function(doc,err){
            assert.equal(null,err);
            resultArray.push(doc);
        },function(){db.close();
            resultArray.forEach(function(doc,err){
            });
            console.log("in the del-temp in-complete length=="+resultArray.length);
            for(var i=0;i<resultArray.length;i++)
                console.log(resultArray[i].task+"\n")
            res.render("todo",{items:resultArray,u_name:name});
        });
    });
});
module.exports = router;
