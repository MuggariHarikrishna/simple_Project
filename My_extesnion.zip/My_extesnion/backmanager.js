
console.log("backmanager");
chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    console.log("in func-->",request);
    chrome.tabs.query({active: true}, function (d) {
	console.log(d);
	//alert("THis is alert");
	if(d && d[0]  && d[0].url){
		console.log("url=="+d[0].url);
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4) {
                if(xhr.responseText=="logout"){
                   console.log("in log out");
	             }
	             else{
					// console.log("content===>"+xhr.responseText;
					var string_context=xhr.responseText;
		    		var array_mails = string_context.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi);
					console.log("MAILS-->>"+array_mails);
					// alert("mail ids:",array_mails);
					var response="";					
					for(var i=0;i<array_mails.length;i++){
						response=response+"\n"+array_mails[i];					
					}
					console.log("sending response mails...",array_mails,"\tresponse",response);
					/* chrome.tabs.sendMessage(d[0].id,{output: response}, function (response) {
                });*/
					sendResponse({output:"hari"});
					                
		}
            }
        };
        xhr.open("get", d[0].url, true);
        xhr.send();
	}
	else{
		console.log("url NOT exists");	
	}
	});
  });
