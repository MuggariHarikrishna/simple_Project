$(document).ready(function () {
  console.log("in content script");
  // alert("content script");
  $("#btn_copy").click(function () {
    console.log("in the functin");
    chrome.runtime.sendMessage({input: "sample message from client"}, function(response) {
        console.log("response got from backmanager-->", response);
	if(response === "undefined")
	        $("#output").html("Emails ::" + "No Emails Found");
	else
		 $("#output").html("Emails ::" + "No Emails Found");
	})
    });
  });

