-- MySQL dump 10.13  Distrib 5.7.19, for Linux (x86_64)
--
-- Host: localhost    Database: temp
-- ------------------------------------------------------
-- Server version	5.7.19-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_data`
--

DROP TABLE IF EXISTS `_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_data` (
  `l_date` date DEFAULT NULL,
  `e_date` date DEFAULT NULL,
  `reason` varchar(40) DEFAULT NULL,
  `description` varchar(60) DEFAULT NULL,
  `p_type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_data`
--

LOCK TABLES `_data` WRITE;
/*!40000 ALTER TABLE `_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `all_data`
--

DROP TABLE IF EXISTS `all_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_data` (
  `username` varchar(20) DEFAULT NULL,
  `l_date` date DEFAULT NULL,
  `e_date` date DEFAULT NULL,
  `reason` varchar(40) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `p_type` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_data`
--

LOCK TABLES `all_data` WRITE;
/*!40000 ALTER TABLE `all_data` DISABLE KEYS */;
INSERT INTO `all_data` VALUES ('hari','2017-07-24','2017-07-25','health','nothing','student'),('hari','2017-07-25','2017-07-27','no-reason','nothing\r\n','Student'),('krishna','2017-08-03','2017-08-05','intern evolution','it is important','Student');
/*!40000 ALTER TABLE `all_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ayyappa_data`
--

DROP TABLE IF EXISTS `ayyappa_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ayyappa_data` (
  `l_date` date DEFAULT NULL,
  `e_date` date DEFAULT NULL,
  `reason` varchar(40) DEFAULT NULL,
  `description` varchar(60) DEFAULT NULL,
  `p_type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ayyappa_data`
--

LOCK TABLES `ayyappa_data` WRITE;
/*!40000 ALTER TABLE `ayyappa_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `ayyappa_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `username` varchar(40) DEFAULT NULL,
  `u_text` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES ('hari','hari'),('hari','the extra content is large'),('ayyappa','i am inocent\r\n                    '),('admin','what is all about\r\n'),('admin','yes or no'),('karthik','can ansuggestions\r\n'),('krishna','yes it is working');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hari_data`
--

DROP TABLE IF EXISTS `hari_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hari_data` (
  `l_date` date DEFAULT NULL,
  `e_date` date DEFAULT NULL,
  `reason` varchar(40) DEFAULT NULL,
  `description` varchar(60) DEFAULT NULL,
  `p_type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hari_data`
--

LOCK TABLES `hari_data` WRITE;
/*!40000 ALTER TABLE `hari_data` DISABLE KEYS */;
INSERT INTO `hari_data` VALUES ('2017-07-24','2017-07-25','health','nothing','Student'),('2017-07-26','2017-07-30','sports','to play','Student'),('2017-07-30','2017-07-31','festivel','travel','Student'),('2017-07-25','2017-07-27','no-reason','nothing\r\n','Student');
/*!40000 ALTER TABLE `hari_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kart_data`
--

DROP TABLE IF EXISTS `kart_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kart_data` (
  `l_date` date DEFAULT NULL,
  `e_date` date DEFAULT NULL,
  `reason` varchar(40) DEFAULT NULL,
  `description` varchar(60) DEFAULT NULL,
  `p_type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kart_data`
--

LOCK TABLES `kart_data` WRITE;
/*!40000 ALTER TABLE `kart_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `kart_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `karthik_data`
--

DROP TABLE IF EXISTS `karthik_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `karthik_data` (
  `l_date` date DEFAULT NULL,
  `e_date` date DEFAULT NULL,
  `reason` varchar(40) DEFAULT NULL,
  `description` varchar(60) DEFAULT NULL,
  `p_type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `karthik_data`
--

LOCK TABLES `karthik_data` WRITE;
/*!40000 ALTER TABLE `karthik_data` DISABLE KEYS */;
INSERT INTO `karthik_data` VALUES ('2017-07-15','2017-07-23','glasses','to buy glasses','Student');
/*!40000 ALTER TABLE `karthik_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `krishna_data`
--

DROP TABLE IF EXISTS `krishna_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `krishna_data` (
  `l_date` date DEFAULT NULL,
  `e_date` date DEFAULT NULL,
  `reason` varchar(40) DEFAULT NULL,
  `description` varchar(60) DEFAULT NULL,
  `p_type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `krishna_data`
--

LOCK TABLES `krishna_data` WRITE;
/*!40000 ALTER TABLE `krishna_data` DISABLE KEYS */;
INSERT INTO `krishna_data` VALUES ('2017-08-03','2017-08-05','intern evolution','it is important','Student');
/*!40000 ALTER TABLE `krishna_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store`
--

DROP TABLE IF EXISTS `store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `store` (
  `l_date` date DEFAULT NULL,
  `e_date` date DEFAULT NULL,
  `reason` varchar(40) DEFAULT NULL,
  `p_type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store`
--

LOCK TABLES `store` WRITE;
/*!40000 ALTER TABLE `store` DISABLE KEYS */;
INSERT INTO `store` VALUES ('2017-07-20','2017-07-22','health','STUDENT'),('2017-07-10','2017-07-28','health','STUDENT'),('2017-07-01','2017-07-20','health','STUDENT');
/*!40000 ALTER TABLE `store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sure_data`
--

DROP TABLE IF EXISTS `sure_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sure_data` (
  `l_date` date DEFAULT NULL,
  `e_date` date DEFAULT NULL,
  `reason` varchar(40) DEFAULT NULL,
  `description` varchar(60) DEFAULT NULL,
  `p_type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sure_data`
--

LOCK TABLES `sure_data` WRITE;
/*!40000 ALTER TABLE `sure_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `sure_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `dob` varchar(10) DEFAULT NULL,
  `p_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('','','','null','//','Student'),('ayyappa','ayyappa','ayyappa@gmail','Male','20/22/2222','Student'),('hari','krishna','harirkishna123.rgukt@gmail.com','Male','20/05/1997','Student'),('kart','kart','kart@rgukt','Male','12/12/1212','Student'),('karthik','karthik','karthik@gmail.com','Male','20/05/1997','Student'),('krishna','krishna','krishna@gmail.com','Male','12/23/1997','Student'),('sure','sh','sure@sure','Male','12/12/1998','Student');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-02 14:55:28
