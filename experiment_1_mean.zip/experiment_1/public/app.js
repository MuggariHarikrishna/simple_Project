var app=angular.module("app",['ngRoute']);
app.controller("loginctrl",function($scope,$rootScope,$http,$location){
    $scope.validate=function(){
        var userid=$scope.idno;
        var password=$scope.password;
        $rootScope.loginstatus='false';
        console.log("user id:"+userid);
        console.log("password="+password);

        var user_data={
          userid:userid,
          password:password
        };
        var res=$http.post('/validate',user_data);
        $http.post('/validate', user_data)
            .then(function (response) {
                //alert("success " + JSON.stringify(response));
                //return response.data;
                console.log("success data="+response.data.status);
                if(response.data.status=='true'){
                    alert("Logging u to inbox");
                    console.log("username="+userid);
                    $rootScope.userid=userid;
                    $rootScope.loginstatus='true';
                    $location.url('/inbox');
                }
                else{
                    alert("Username or Password do not Match");
                    $location.url('/login');
                }
            });
    }
});
app.controller("registerctrl",function($scope,$http,$location){
    var user=$scope.user_name;
    console.log("user=="+user);
    $scope.register=function(){
        var idno=$scope.idno;
        var name=$scope.name;
        var branch=$scope.branch;
        var year=$scope.year;
        var password=$scope.password;
        console.log("idno=="+idno+"\tname="+name+"\tbranch=="+branch+"\tyear=="+year+"\tpass=="+password);

     var register_data={
         user_id:idno,
         user_name:name,
         user_branch:branch,
         user_year:year,
         user_password:password
     };
        $http.post('/register', register_data)
            .then(
            function successCallBack(res) {
                console.log("success data="+response.status);
                alert("Data Registered Successully");
            },
            function errorCallBack(res) {
                alert("Error Occured While Registering");
            });
    };
});
app.controller("composectrl",function($scope,$rootScope,$http,$location){
    if($rootScope.loginstatus=='true'){
        $scope.user="composing mail";$scope.name='hari';
        $scope.logout=function(){
            console.log("user logged out");
            $rootScope.loginstatus='false';
            $location.url('/login');
        };
        $scope.insert=function () {
            console.log("in the app composectrl");
            var from_mail=$rootScope.userid;
            var to_mail=$scope.to_mail;
            var subject=$scope.subject;
            var message=$scope.message;
            var item={
                sender:from_mail,
                receiver:to_mail,
                subject:subject,
                message:message,
                trash:'no'
            };
            console.log("from_mail="+from_mail);
            console.log("to_mail="+to_mail);
            console.log("subject="+subject);
            console.log("message="+message);
            $http.post('/compose', item)
                .then(function (response) {
                    console.log("success data="+response.data.status);
                    if(response.data.status=='true'){
                        console.log("alerting the sending msg");
                        alert("Your Message Sent");
                    }
                    else{
                        alert("Error Occured While Sending");
                        $location.url('/login');
                    }
                });
        };
    }
    else{
        alert("Please Login to Continue...");
        $location.url('/login');
    }

});
app.controller("inboxctrl",function($scope,$http,$rootScope,$location){
    if($rootScope.loginstatus=='true') {
        console.log("in the fuinciton");
        $scope.logout=function(){
            console.log("user logged out");
            $rootScope.loginstatus='false';
            $location.url('/login');
        };
        $scope.delete_msg=function(data){
            console.log(data.sender+" "+data.subject+" "+data.message +"-->");
            console.log("deleting msg");
            var sender=$scope.sender;
            var receiver=$scope.userid;
            var message=$scope.message;
            var subject=$scope.subject;
            var item={
                sender:sender,
                receiver:receiver,
                subject:subject,
                message:message
            };
            console.log("sender=="+sender+"\treceiver=="+receiver+"\tsubject=="+subject+"\tmsg=="+message);
            /*$http.post('/inbox_delete', item)
                .then(function (response) {
                    console.log("success data="+response.data.status);
                    if(response.data.status=='true'){
                        console.log("Message Moved To Trash");
                        alert("Your Message Moved to Trash");
                    }
                    else{
                        alert("Error Occured While Moving to Trash");
                        $location.url('/login');
                    }
                });*/
        };
        $http.get("/inbox")
            .then(
                function successCallBack(res) {
                    console.log("success="+JSON.stringify(res));
                    $scope.inbox_data=res.data;
                },
                function errorCallBack(res) {
                    console.log("failure");
                });
    }
    else{
        alert("Please Login To Continue...");
        $location.url('/login');
    }
});
app.controller("sentctrl",function($scope,$rootScope,$http,$location){
    if($rootScope.loginstatus=='true') {
        $scope.user="sent mail";
        $scope.logout=function(){
            console.log("user logged out");
            $rootScope.loginstatus='false';
            $location.url('/login');
        };
        $http.get("/sent")
            .then(
                function successCallBack(res) {
                    console.log("success="+JSON.stringify(res));
                    $scope.inbox_data=res.data;
                },
                function errorCallBack(res) {
                    console.log("failure");
                });
    }
    else{
        alert("Please Login To Continue...");
        $location.url('/login');
    }

});
app.controller("trashctrl",function($scope,$rootScope,$location,$http){
    if($rootScope.loginstatus=='true') {
        $scope.logout=function(){
            console.log("user logged out");
            $rootScope.loginstatus='false';
            $location.url('/login');
        };
        $http.get("/trash")
            .then(
                function successCallBack(res) {
                    console.log("success="+JSON.stringify(res));
                    $scope.inbox_data=res.data;
                },
                function errorCallBack(res) {
                    console.log("failure");
                });
    }
    else{
        alert("Please Login To Continue...");
        $location.url('/login');
    }
});
app.config(function ($routeProvider) {
    $routeProvider
        .when('/login',{
            controller:'loginctrl',
            templateUrl:'./login.html'
        })
        .when('/register',{
            controller:'registerctrl',
            templateUrl:'./register.html'
        })
        .when('/inbox',{
            controller:'inboxctrl',
            templateUrl:'./inbox.html'
        })
        .when('/sent',{
            controller:'sentctrl',
            templateUrl:'./sent.html'
        })
        .when('/trash',{
            controller:'trashctrl',
            templateUrl:'./trash.html'
        })
        .when('/compose',{
            controller:'composectrl',
            templateUrl:'./compose.html'
        })
        .otherwise({
            redirectTo: "/login"
        });
});