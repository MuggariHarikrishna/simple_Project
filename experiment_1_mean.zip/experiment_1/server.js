var express = require('express');
var app = express();
var port = process.env.PORT || 1295;
var morgan = require('morgan');
var MongoClient = require('mongodb').MongoClient;
var bodyParser = require('body-parser');
var router = express.Router();
var path = require('path');
var url= 'mongodb://localhost:27017/angular';

var userid;
var login_status=0;

app.set('views', path.join(__dirname, 'public'));
app.set('view engine', 'ejs');


app.use(express.static(path.join(__dirname, 'public')));

app.use(express.static('assets'));


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname + '/public'));

var status='false';

app.post('/compose',function(req,res){
    console.log("in compose");
    console.log("data in compose sender=="+req.body['sender']);
    console.log("data in compose receiver=="+req.body['receiver']);
    var sender=req.body['sender'];
    var receiver=req.body['receiver'];
    var recordd=req.body;
    console.log("data in compose=="+recordd['sender']);

    MongoClient.connect(url, function(err, db) {

        console.log("Connected correctly to server.");
        db.collection(sender).insert( recordd,function(err,resonse){
            if(!err){
                console.log("inserted in sender success");
                db.collection(receiver).insert( recordd,function(err,resonse){
                    if(!err){
                        console.log("inserted in receiver success");
                        db.close();
                        res.json({status:'true'});
                    }
                });
            }
        });
    });
});
app.get('/inbox',function(req,res){
    var data=[];
    if(login_status==1){
        MongoClient.connect(url, function(err, db) {
            console.log("Connected correctly to server.");
            var cursor = db.collection(userid).find({'receiver':userid,'trash':'no'});
            cursor.forEach(function (doc, err) {
                console.log("doc tomails="+doc.to_mail);
                data.push(doc);
            }, function () {
                db.close();
                console.log("in the inbox data length="+data.length);
                return res.json(data);
            });
        });
    }
    else{
        res.json({status:'false'})
    }


});

app.get('/sent',function(req,res){
    if(login_status==1){
        var data=[];
        MongoClient.connect(url, function(err, db) {
            console.log("Connected correctly to server.");
            var cursor = db.collection(userid).find({'sender':userid,'trash':'no'});
            cursor.forEach(function (doc, err) {
                console.log("doc tomails="+doc.to_mail);
                data.push(doc);
            }, function () {
                db.close();
                console.log("in the sent data length="+data.length);
                return res.json(data);
            });
        });
    }
});

router.post('/inbox_delete', function(req, res, next) {
    var sender=req.body.sender;
    var receiver=req.body.receiver;
    var subject=req.body.subject;
    var message=req.body.message;
    var status="";
    console.log("inthe inbox delete");
    console.log("sender="+sender+"\nreceiver=="+receiver+"\nsubject=="+subject);
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var myquery = {sender:sender,receiver:receiver,subject:subject,message:message };

        db.collection(userid).updateOne(myquery,{$set:{'trash':'yes'}}, function(err, res) {
            if(!err){
                console.log("1 record updated");
                status="true";
                db.close();
                res.json({status:'true'})
            }
            else{
                res.json({status:'false'})
            }
        });
    });
});


app.get('/trash',function(req,res){
    if(login_status==1){
        var data=[];
        MongoClient.connect(url, function(err, db) {
            console.log("Connected correctly to server.");
            var cursor = db.collection(userid).find({
                $and:[
                    {$or:[
                        {"sender" : userid},
                        {"receiver" : userid}
                    ]},
                    {"trash": "yes"}
                ]});
            cursor.forEach(function (doc, err) {
                console.log("doc tomails="+doc.to_mail);
                data.push(doc);
            }, function () {
                db.close();
                console.log("in the trash data length="+data.length);
                return res.json(data);
            });
        });
    }
    else{
        return res.json({status:'false'})
    }
});

app.post('/register',function (req,res) {
    var id=req.body.user_id;
    var name=req.body.user_name;
    var branch=req.body.user_branch;
    var year=req.body.user_year;
    var password=req.body.user_password;
    var user_data={
        user_id:id,
        user_name:name,
        user_branch:branch,
        user_year:year,
        user_password:password
    };
    console.log("in server\nid=="+id+"\tname="+name+"\tbranch="+branch+"\tyear="+year+"\tpassword="+password);
    MongoClient.connect(url, function(err, db) {
        console.log("Connected correctly to server.");
        db.collection('users').insert( user_data,function(err,res){
            if(!err){
                console.log("user data inserted success");
                db.close();
               // res.json({status:'true'})

            }
            /*else{
                res.json({status:'false'})
            }*/
        });
    });
    //res.json({status:'true'})
});

app.post('/validate',function (req,res) {
    var id=req.body.userid;
    userid=id;
    var password=req.body.password;
    console.log("userid=="+id+"\tpass=="+password);
    if(id!=null){
        MongoClient.connect(url, function(err, db) {
            console.log("Connected correctly to server.");
            db.collection('users').findOne({user_id: id}, function (err, users) {
                if (!err && users) {
                    console.log("in the if");
                    if (password == users.user_password) {
                        console.log("in the if if");
                        status = "true";
                    }
                    else {
                        console.log("in the if else");
                        status = 'failed';
                    }
                }
                else {
                    console.log("in the else");
                    status = 'failed';
                }
                console.log("status==" + status);
                if (status == "true") {
                    console.log("status==true");
                    login_status=1;
                    status='true';
                    res.json({status:'true'})
                }
                else{
                    /* res.sendFile(path.join(__dirname + '/public/index.html'));*/
                    res.json({status:'false'})
                }
            });
        });
    }
    else{
        res.json({status:'false'})
    }
});


/*app.get('/success', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/index1.html'))});*/

app.get('/', function(req, res) {
    login_status=0;
    res.sendFile(path.join(__dirname + '/public/index.html'))});


app.listen(port, function() {
    console.log('Running the server on port ' + port);
});
