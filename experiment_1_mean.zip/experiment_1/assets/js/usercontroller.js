var sampleApp = angular.module('TAPP', ['notification','ngRoute','ngCookies','ngTagsInput','xeditable','froala']);


sampleApp.value('froalaConfig', {
    toolbarInline: false,
    placeholderText: 'Enter Text Here'
});


sampleApp.factory('todayData0', function () {

    var data = {
        date: '',
        campId:''
    };

    return {
        getDate: function () {
            return data.date;
        },
        setDate: function (date) {
            data.date = date;
        },
        getCampId: function () {
            return data.campId;
        },
        setCampId: function (campId) {
            data.campId = campId;
        }
    };
});

sampleApp.factory('mycampaignData0', function () {

    var data = {
        date: '',
        nlmId:'',
        pickVol:'',
        pushVol:'',
        userId:'',
        campDate:''
    };

    return {
        setDate: function (date) {
            data.date = date;
        },
        setNlmId: function (nlmId) {
            data.nlmId = nlmId;
        },
        setPickVol: function (pickVol) {
            data.pickVol = pickVol;
        },
        setPushVol: function (pushVol) {
            data.pushVol = pushVol;
        },
        setUserId: function (userId) {
            data.userId = userId;
        },
        setCampDate: function (campDate) {
            data.campDate = campDate;
        },
        getDate: function () {
            return data.date;
        },
        getNlmId: function () {
            return data.nlmId;
        },
        getPickVol: function () {
            return data.pickVol;
        },
        getPushVol: function () {
            return data.pushVol;
        },
        getUserId: function () {
            return data.userId;
        },
        getCampDate: function () {
            return data.campDate;
        }
    };
});


sampleApp.factory('innerCampEdit0', function () {

    var data = {
        date: '',
        nlmId:'',
        pickVol:'',
        pushVol:'',
        userId:'',
        campDate:'',
        ctdOn:'',
        campId:'',
        nlId:''
    };

    return {
        setNlId: function (nlId) {
            data.nlId = nlId;
        },
        setCampId: function (campId) {
            data.campId = campId;
        },
        setCtdOn: function (ctdOn) {
            data.ctdOn = ctdOn;
        },
        setDate: function (date) {
            data.date = date;
        },
        setNlmId: function (nlmId) {
            data.nlmId = nlmId;
        },
        setPickVol: function (pickVol) {
            data.pickVol = pickVol;
        },
        setPushVol: function (pushVol) {
            data.pushVol = pushVol;
        },
        setUserId: function (userId) {
            data.userId = userId;
        },
        setCampDate: function (campDate) {
            data.campDate = campDate;
        },
        getCampId: function () {
            return data.campId;
        },
        getCtdOn: function () {
            return data.ctdOn;
        },
        getDate: function () {
            return data.date;
        },
        getNlId: function () {
            return data.nlId;
        },
        getNlmId: function () {
            return data.nlmId;
        },
        getPickVol: function () {
            return data.pickVol;
        },
        getPushVol: function () {
            return data.pushVol;
        },
        getUserId: function () {
            return data.userId;
        },
        getCampDate: function () {
            return data.campDate;
        }
    };
});


sampleApp.factory('reportsData0', function () {

    var data = {
        date: '',
        campId:'',
        date1:''
    };

    return {
        getDate1: function () {
            return data.date1;
        },
        setDate1: function (date) {
            data.date1 = date;
        },
        getDate: function () {
            return data.date;
        },
        setDate: function (date) {
            data.date = date;
        },
        getCampId: function () {
            return data.campId;
        },
        setCampId: function (campId) {
            data.campId = campId;
        }
    };
});


sampleApp.factory('campaignData0', function () {

    var data = {
        date: '',
        campId:'',
        show:'',
        back:''
    };

    return {
        getDate: function () {
            return data.date;
        },
        setShow: function (bool) {
            data.bool = bool;
        },
        setDate: function (date) {
            data.date = date;
        },
        getShow: function () {
            return data.bool;
        },
        getCampId: function () {
            return data.campId;
        },
        setCampId: function (campId) {
            data.campId = campId;
        },
        setBack: function (bool) {
            data.bool = bool;
        },
        getBack: function () {
            return data.bool;
        }
    };
});


sampleApp.factory('socket', ['$rootScope', function($rootScope) {

    var socket = io.connect('1111');

    return {
        on: function(eventName, callback){
            socket.on(eventName, callback);
        },
        emit: function(eventName, data) {
            socket.emit(eventName, data);
        }
    };
}]);


sampleApp.directive('focusMe', function($timeout, $parse) {
    return {
        link: function(scope, element, attrs) {
            var model = $parse(attrs.focusMe);
            scope.$watch(model, function(value) {
               // console.log('value=',value);
                if(value === true) {
                    $timeout(function() {
                        element[0].focus();
                    }); }
            });
        }
    };
});




sampleApp.config(['$routeProvider',
    function ($routeProvider) {
        $routeProvider.
        when('/users/innerCamp', {
            templateUrl: 'livepages/innerCampEdit.html'
        }).
        when('/users/innerCampR', {
            templateUrl: 'livepages/innerCampEditR.html'
        }).
        when('/users/startRetarget', {
            templateUrl: 'livepages/startRetarget.html',
            controller:'startRetargetCtrl'
        }).
        when('/users/createcampaign', {
            templateUrl: 'livepages/createcampaign1.html'
        }).
        when('/users/alldomains', {
            templateUrl: 'livepages/alldomains.html',
            controller: 'all_domains_controller'
        }).
        when('/users/adddomain', {
            templateUrl: 'livepages/AddEsp.html',
            controller: 'add_esp_controller'
        }).
        when('/users/mail/:domainId/:name/:hScore', {
            templateUrl: 'livepages/domainDetails.html',
            controller: 'single_domain_controller'
        }).
        when('/users/dashboard', {
            templateUrl: 'livepages/dashboard.html'
        }).
        when('/users/viewmain',{

            templateUrl : 'livepages/viewMain.html'
        }).
        when('/users/viewsub',{

            templateUrl : 'livepages/subMenu.html'
        }).
        when('/users/step2/:campId', {

            templateUrl: 'livepages/createcampaign2.html',
            controller:'campaignStep2Ctrl'
        }).
        when('/users/step3/:campId/:newsId', {

            templateUrl: 'livepages/createcampaign3.html'

        }).
        when('/users/step4/:campId/:newsId', {

            templateUrl: 'livepages/createcampaign4.html',
            controller : 'campaignStep4Ctrl'
        }).
        when('/users/step5/:campId/:newsId', {

            templateUrl: 'livepages/createcampaign5.html',
            controller : 'campaignStep5Ctrl'
        }).
        when('/users/step6/:campId/:newsId', {

            templateUrl: 'livepages/createcampaign6.html',
            controller : 'campaignStep6Ctrl'
        }).
        when('/users/step7/', {

            templateUrl: 'livepages/createcampaign1.html'
            /* ,controller : 'home-controller'*/
        }).
        when('/user/campaign', {

            templateUrl: 'livepages/createcampaign5.html',
            controller : 'campaignStep5Ctrl'
        }).
        when('/users/reply', {

            templateUrl: 'livepages/createcampaign6.html',
            controller : 'campaignStep6Ctrl'
        }).
        when('/users/reports', {

            templateUrl: 'livepages/reports1.html',
            controller : 'reportsCtrl'
        }).
        when('/users/mycampaigns', {
            templateUrl: 'livepages/mycampaigns.html'
        }).
        when('/campaigns/startCampaign', {
            templateUrl: 'livepages/start-campaign.html'
        }).
        when('/users/campaigns/', {
            templateUrl: 'livepages/campaigns1.html',
            controller : 'outer-campaigns-controller'
        }).
        when('/users/innerCampaigns', {
            templateUrl: 'livepages/campaigns.html',
            controller : 'inner-campaigns-controller'
        }).
        when('/users/innerCampaignR', {
            templateUrl: 'livepages/campaignR1.html',
            controller : 'innerR-campaignsR-controller'
        }).
        when('/users/today', {

            templateUrl: 'livepages/today.html'
        }).
        when('/users/replys', {

            templateUrl: 'livepages/Replys.html'
        }).
        when('/users/drafts', {

            templateUrl: 'livepages/Drafts.html',
            controller:'draftsCtrl'
        }).
        when('/users/viewusers/', {

            templateUrl: 'livepages/viewusers.html'
        }).
        when('/users/viewdomains/', {

            templateUrl: 'livepages/viewdomain.html'
        }).
        when('/users/viewNL', {

            templateUrl: 'livepages/viewNewsLetter.html'
        }).
        when('/users/viewNL/:campId', {

            templateUrl: 'livepages/viewNewsLetter.html'
        }).
        when('/users/reports2',{

            templateUrl : 'livepages/reports-2.html',
            controller : 'reportNlmCtrl'
        }).
        when('/users/reports2R',{

            templateUrl : 'livepages/reports-2R.html',
            controller : 'reportNlmCtrlR'
        }).
        when('/users/CreateCampaignR', {
            templateUrl: 'livepages/createcampaign1R.html'
        }).
        when('/users/step2R/:campId', {

            templateUrl: 'livepages/createcampaign2R.html',
            controller:'campaignStep2Ctrl'
        }).
        when('/users/step3R/:campId/:newsId', {

            templateUrl: 'livepages/createcampaign3R.html'

        }).
        when('/users/step4R/:campId/:newsId', {

            templateUrl: 'livepages/createcampaign4R.html',
            controller : 'campaignStep4CtrlR'
        }).
        when('/users/step5R/:campId/:newsId', {

            templateUrl: 'livepages/createcampaign5R.html',
            controller : 'campaignStep5CtrlR'
        }).
        when('/users/step6R/:campId/:newsId', {

            templateUrl: 'livepages/createcampaign6R.html',
            controller : 'campaignStep6CtrlR'
        }).
        when('/users/step7R/', {

            templateUrl: 'livepages/createcampaign1R.html'
            /* ,controller : 'home-controller'*/

        }).
        when('/users/campaignsR/', {
            templateUrl: 'livepages/campaignsR.html',
            controller : 'outerR-campaignsR-controller'
        }).
        when('/users/reportsR', {
            templateUrl: 'livepages/reports1R.html',
            controller : 'reportsCtrlR'
        }).
        when('/users/draftsR', {

            templateUrl: 'livepages/DraftsR.html',
            controller:'draftsCtrlR'
        }).
        when('/users/datastats', {

            templateUrl: 'livepages/data.html',
            controller : 'data_controller'
        }).
        otherwise({
            redirectTo: '/'
        })


    }]);


sampleApp.controller('innerCampEditCtrl',[ 'innerCampEdit0','fileUpload','$rootScope','$timeout','$scope', '$cookies', '$cookieStore', '$window', '$routeParams', '$http', function (innerCampEdit0,fileUpload,$rootScope,$timeout,$scope, $cookies, $cookieStore, $window, $routeParams, $http) {

    $scope.subjects = [];
    $scope.senders = [];


    $scope.userId = innerCampEdit0.getUserId();
    $scope.nlmId = innerCampEdit0.getNlmId();



    $scope.showUploadNew = true;

    $scope.fileUndefined=false;
    $scope.fileNoZip = false;
    var oFCKeditor = new FCKeditor('editor');
    $scope.fileUpload = function () {

        console.log("fileUpload");

        var file = $scope.myFile;

        var file1 = document.getElementById("uploadFile");
        var fileName1=file1.value.toString();
        if(fileName1.split('.').pop().toLowerCase() == "zip" ){

            var uploadUrl = "/users/uploadFile";
            fileUpload.async(file,uploadUrl).then(function(res){

                $scope.uploadDetails = res.data;
                $scope.fckmodel= res.data;

                //  console.log(res.data);
                //document.getElementById("editor").innerHTML(res.data);

                $scope.fckValue = 0;
                var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
                oEditor.SetHTML(res.data);
                $scope.radioModel='create';
                $scope.showUploadNew ="true";

            });


        }else if(typeof file=="undefined"){
            $scope.fileNoZip = false;
            $scope.fileUndefined=true;
            //alert("Please Select the file to be uploaded");
        }else{ $scope.fileNoZip = true;
            $scope.fileUndefined=false;
            //alert("Please Upload Only Zip File");
        }

    }

    $scope.fcmodelSpan = false;


    $http({
        method: 'POST',
        url: "users/getNewsLetter",
        data: {
            'nlId': parseInt($scope.nlmId),
        }
    }).then(function successCallback(response) {

        if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
            window.location.href = "./";
        } else {
            if (response.data.error) {
                console.log(response.data.error)
                alert(response.data.error);
            } else if (response.data.success) {

                $scope.newsletter = response.data.success;


                for (sn in $scope.newsletter.SN) {
                    if (typeof $scope.newsletter.SN[sn] != "function") {
                        $scope.senders.push($scope.newsletter.SN[sn]);
                    }
                }


                for (sl in $scope.newsletter.SL) {
                    if (typeof $scope.newsletter.SL[sl] != "function") {
                        $scope.subjects.push($scope.newsletter.SL[sl]);

                    }

                }


                var myEl = angular.element(document.querySelector('#editor'));
                myEl.html($scope.newsletter.creative);




                $scope.fckValue = 0;


                //alert("ctrl3 called");
                $scope.fckeditor = function(){
                    //alert("fckeditor  ");
                    if($scope.fckValue<1){

                        oFCKeditor.BasePath = "/FCKeditor_2.0rc3/";
                        oFCKeditor.Width = 700;
                        oFCKeditor.Height = 500;
                        oFCKeditor.ProcessHTMLEntities = false;
                        oFCKeditor.ReplaceTextarea();
                        $scope.fckValue++;

                    }else{
                        var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
                        oEditor.SetHTML($scope.newsletter.creative);
                    }
                }

                $scope.fckeditor();

            } else {

            }

        }
    }, function errorCallback(response) {
        alert('error5' + response);
    });




    $scope.senderData = [];
    $scope.senderData = $scope.senders;
    var i=0;
    $scope.senderSubmit= false;
    $scope.addSender = function(senderName)
    {

        if(senderName!='' && senderName != null && $scope.senderData.length<3){
            $scope.senderData.push(senderName);
            $scope.senderName='';
        }
        if(senderName != null && senderName!='' )
        {    i++;
            if(i>3 && $scope.senderData.length==3){
                $scope.senderSubmit=true;}

        }

    }


    $scope.subjectData = [];
    $scope.subjectData = $scope.subjects;
    $scope.subjectSubmit=false;
    var j=0;
    $scope.addSubject = function(subject)
    {

        if(subject!='' && subject != null && $scope.subjectData.length<3){
            $scope.subjectData.push(subject);
            $scope.subject='';
        }
        if(subject != null && subject!='')
        {    j++;
            if(j>3 && $scope.subjectData.length==3){
                $scope.subjectSubmit=true;}
            //alert("Sender Name limit exceed");
        }
    }
    $scope.removeSender=function(index)
    {
        $scope.senderData.splice(index,1);
        $scope.senderSubmit=false;
    }
    $scope.removeSubject=function(index)
    {
        $scope.subjectData.splice(index,1);
        $scope.subjectSubmit=false;
    }


    $scope.processing=false;
    $scope.saveInnerEdit = function()
    {

        console.log("editor");
        var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
        var cont = oEditor.GetHTML();
        $scope.editorContent=oEditor.GetHTML();


        if(typeof cont == "undefined" || cont==''|| $scope.senderData=='' || $scope.subjectData== '' ||cont=='<br>')
        {
            if($scope.senderData!='' && $scope.subjectData!= ''){
                $scope.fcmodelSpan = true;
            }
            else {
                $scope.fcmodelSpan = false;
            }

            console.log("Incomplete data line no.:625");
        }
        else{
            $scope.processing=true;
            var obj ={status:'',SN:$scope.senderData,SL:$scope.subjectData,cBy:$scope.userId,newsId:$scope.nlmId, creative:cont};
            console.log("obj : "+obj);

            $http({

                method:'POST',
                url : '/users/updateStep3',
                data:obj

            }).then(function successCallBack(res){

                    if(res.length<1){
                        $window.location.reload();
                    }
                    else{
                        $window.location ="#/users/innerCampaigns";
                    }

                },
                function errorCallBack(res){
                    console.log(res.data);
                    $scope.processing=false;
                })
        }
    }



}])



sampleApp.controller('startRetargetCtrl',[ 'innerCampEdit0','fileUpload','$rootScope','$timeout','$scope', '$cookies', '$cookieStore', '$window', '$routeParams', '$http', function (innerCampEdit0,fileUpload,$rootScope,$timeout,$scope, $cookies, $cookieStore, $window, $routeParams, $http)
{

    $scope.subjects = [];
    $scope.senders = [];

    $scope.userId = innerCampEdit0.getUserId();
    $scope.nlmId = innerCampEdit0.getNlmId();
    var ctdOn = innerCampEdit0.getCtdOn();
    var campId = innerCampEdit0.getCampId();



    $scope.valideVal = 'hello';

   // $scope.sentVol= mycampaignData0.getPushVol();
    //$scope.userId = mycampaignData0.getUserId();
    //$scope.nlmId = mycampaignData0.getNlmId();
   // $scope.pickVol = mycampaignData0.getPickVol();
    //$scope.dateStamp = mycampaignData0.getCampDate();



    $scope.newsletter = null;
    $scope.senders = [];
    $scope.subjects = [];
    $scope.showingTest = 0;


    $scope.fileUndefined=false;
    $scope.fileNoZip = false;
    var oFCKeditor = new FCKeditor('editor');
    $scope.fileUpload = function () {

        console.log("fileUpload");
        var file = $scope.myFile;

        var file1 = document.getElementById("uploadFile");
        var fileName1=file1.value.toString();
        if(fileName1.split('.').pop().toLowerCase() == "zip" ){

            var uploadUrl = "/users/uploadFile";
            fileUpload.async(file,uploadUrl).then(function(res){

                $scope.uploadDetails = res.data;
                $scope.fckmodel= res.data;

                //  console.log(res.data);
                //document.getElementById("editor").innerHTML(res.data);

                $scope.fckValue = 0;
                var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
                oEditor.SetHTML(res.data);
                $scope.radioModel='create';
                $scope.showUploadNew ="true";

            });


        }else if(typeof file=="undefined"){
            $scope.fileNoZip = false;
            $scope.fileUndefined=true;
            //alert("Please Select the file to be uploaded");
        }else{ $scope.fileNoZip = true;
            $scope.fileUndefined=false;
            //alert("Please Upload Only Zip File");
        }

    }

    $scope.fcmodelSpan = false;

    $scope.showSubjects = "false";
    $scope.selectSubject = function (bool,v) {

        $scope.showSubjects = bool;
        $scope.subject=v;
    }


    $scope.showSender = false;
    $scope.selectSender = function (bool,v) {

        $scope.showSender = bool;
        $scope.sender1=v;
    }





    $http({
        method: 'POST',
        url: "users/getNewsLetter",
        data: {
            'nlId': parseInt($scope.nlmId),
        }
    }).then(function successCallback(response) {


        if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
            window.location.href = "./";
        } else {
            if (response.data.error) {
                console.log(response.data.error)
                alert(response.data.error);
            } else if (response.data.success) {

                $scope.newsletter = response.data.success;

                for (sn in $scope.newsletter.SN) {
                    if (typeof $scope.newsletter.SN[sn] != "function") {
                        $scope.senders.push($scope.newsletter.SN[sn]);
                    }
                }

                $scope.sender1 = $scope.senders[0];

                for (sl in $scope.newsletter.SL) {
                    if (typeof $scope.newsletter.SL[sl] != "function") {
                        $scope.subjects.push($scope.newsletter.SL[sl]);
                    }
                }


                $scope.subject = $scope.subjects[0];


                var myEl = angular.element(document.querySelector('#editor'));
                myEl.html($scope.newsletter.creative);




                $scope.fckValue = 0;

                var oFCKeditor = new FCKeditor('editor');
                //alert("ctrl3 called");
                $scope.fckeditor = function(){
                    //alert("fckeditor  ");
                    if($scope.fckValue<1){

                        oFCKeditor.BasePath = "/FCKeditor_2.0rc3/";
                        oFCKeditor.Width = 700;
                        oFCKeditor.Height = 500;
                        oFCKeditor.ProcessHTMLEntities = false;
                        oFCKeditor.ReplaceTextarea();
                        $scope.fckValue++;

                    }
                    else{
                        var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
                        oEditor.SetHTML($scope.newsletter.creative);
                    }

                }
              //  $scope.fckeditor();








                $scope.nTags = [];
                $scope.newsTagIds = 0;
                for (i = 0; i < $scope.newsletter.tags.length; i++) {
                    //$scope.newsTagIds.push(res.data.tags[i]);
                    $scope.newsTagIds = $scope.newsletter.tags[i];
                    $http({

                        method: 'GET',
                        url: '/users/getNewsTags1/' + $scope.newsTagIds

                    }).then(
                        function successCallBack(res) {
                            // console.log("response ");
                            // console.log(res);
                            //console.log("response of campaingn7 ctrl" + res);
                            $scope.news1Tags = res.data;

                            //  console.log("res.data.name...." + res.data.id);

                            $scope.nTags.push({"name": res.data.name, "id": res.data.id});
                            /*$scope.tagIn.push({"text":res.data.name, "id":res.data.id});*/

                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });
                }


                $scope.nBrands = [];
                $scope.newsBrandIds = 0;
                if(typeof $scope.newsletter.tBrands != 'undefined'){
                    for (i = 0; i < $scope.newsletter.tBrands.length; i++) {
                        //$scope.newsTagIds.push(res.data.tags[i]);
                        $scope.newsBrandIds = $scope.newsletter.tBrands[i];

                        $http({

                            method: 'GET',
                            url: '/users/getNewsTags1/' + $scope.newsBrandIds


                        }).then(
                            function successCallBack(res) {
                                // console.log("response ");
                                // console.log(res);
                                // console.log("response of campaingn7 ctrl" + res);
                                $scope.brand1Tags = res.data;

                                // console.log("res.data.name...." + res.data.id);

                                $scope.nBrands.push({"name": res.data.name, "id": res.data.id});


                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }}

                $scope.ntPRs = [];
                $scope.newstPrIds = 0;
                if(typeof $scope.newsletter.tPR != 'undefined'){
                    for (i = 0; i < $scope.newsletter.tPR.length; i++) {
                        //$scope.newsTagIds.push(res.data.tags[i]);
                        $scope.newstPrIds = $scope.newsletter.tPR[i];

                        $http({

                            method: 'GET',
                            url: '/users/getNewsTags1/' + $scope.newstPrIds

                        }).then(
                            function successCallBack(res) {
                                // console.log("response ");

                                //  console.log("res.data.name...." + res.data.id);

                                $scope.ntPRs.push({"name": res.data.name, "id": res.data.id});

                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }
                }

                $scope.nCatTags = [];
                $scope.catIds = 0;

                if (typeof $scope.newsletter.reTarget != 'undefined')
                {
                    if (typeof $scope.newsletter.reTarget.catTags != 'undefined')
                    {
                        for (i = 0; i < $scope.newsletter.reTarget.catTags.length; i++) {

                            $scope.catIds = $scope.newsletter.reTarget.catTags[i];

                            $http({

                                method: 'GET',
                                url: '/users/getNewsTags1/' + $scope.catIds


                            }).then(
                                function successCallBack(res) {
                                    // console.log("response ");
                                    // console.log(res);
                                    // console.log("response of campaingn7 ctrl" + res);
                                    //  console.log("res.data.name...." + res.data.id);

                                    $scope.nCatTags.push({"name": res.data.name, "id": res.data.id});

                                },
                                function errorCallBack(res) {
                                    //alert("error");
                                    console.log("error in tags");

                                    return res.data;
                                });
                        }
                    }

                    var idObj = {countryId:$scope.newsletter.reTarget.countries};
                    $http({

                        method: 'POST',
                        url: '/users/getCountriesById/',
                        data:idObj

                    }).then(
                        function successCallBack(res) {

                            console.log("getCountriesById  res  :  "+JSON.stringify(res.data))
                            if(typeof res.data.data != 'undefined'){
                                console.log("    and  :  ",res.data.data.name);
                                $scope.newsletter.country=res.data.data.name;
                            }

                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });

                    var idObj = {eDomain:$scope.newsletter.reTarget.eDomain};
                    $http({

                        method: 'POST',
                        url: '/users/getEdomainById/',
                        data:idObj

                    }).then(
                        function successCallBack(res) {

                            // console.log("getEdomainById  res  :  "+JSON.stringify(res.data)," and name  :  ",res.data.name);
                            $scope.newsletter.eDomain=res.data.name;
                            //  console.log("$scope.newsletter.eDomain   :  "+$scope.newsletter.eDomain);
                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });
                }

                if(typeof $scope.newsletter.reTarget != 'undefined'){
                    if(typeof $scope.newsletter.reTarget.cities != 'undefined'){
                        var idObj = {cityIds:$scope.newsletter.reTarget.cities};
                        $http({

                            method: 'POST',
                            url: '/users/getCityByIds/',
                            data:idObj

                        }).then(
                            function successCallBack(res) {

                                console.log("getcityById  res  :  "+JSON.stringify(res.data));
                                $scope.newsletter.city=res.data.data;

                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }}

            } else {

            }

        }
    }, function errorCallback(response) {
        alert('error5' + response);
    });


    $scope.showLoading = false;

    $scope.sendReTestMail = function () {

        $scope.showLoading = true;

        $scope.domainObj = [];
        //alert("Testmail in STARTCAMPAIGN");
        $scope.showingTest = 1;

        var flag=false;
        //var value = document.getElementById('sendtestemailid').value;
        var value = $scope.testMailInput;
        //alert(value);
        var duplicatesArray = new Array();
        var uniqueArray = new Array();
        value = value.replace(/ /g, "");
        if (value.indexOf(",") !== -1) {
            var result = value.split(",");
            $scope.emailIdLength = result.length;
            //alert("result  :  "+result);
            if (result.length <= 1000) {
                for (var i = 0; i < result.length; i++) {
                    var actualEmail = result[i];
                    actualEmail = $.trim(actualEmail);
                    if (actualEmail != "") {
                        if (!validateEmail(actualEmail)) {
                            alert(actualEmail + " is invalid email Id.Please enter valid email Id");
                            flag = false;
                            break;
                        } else {
                            duplicatesArray.push(actualEmail.toLowerCase());
                            flag = true;
                        }
                    } else {
                        alert("Invalid email Id.Please remove comma at the end");
                        flag = false;
                        break;
                    }

                }

            } else {
                alert("Only 10 email Id's seperated by comma are allowed");
            }

        } else {
            $scope.emailIdLength = 1;
            if (!validateEmail(value)) {
                alert(value + " is invalid email Id.Please enter valid email Id");
                flag = false;
            } else {
                flag = true;
            }

        }

        function validateEmail(sEmail) {
            var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (filter.test(sEmail)) {
                return true;
            }
            else {
                return false;
            }
        }

        if (flag == true) {

            var ids = "";
            var c = document.getElementsByName('listgroup');
            var totd=0;
            for (var i = 0; i < c.length; i++)
            {
                // alert("c[i].id  : "+c[i].id);
                if (c[i].checked) {
                    $scope.domainObj.push({id:c[i].id,vol:$scope.emailIdLength})
                    ids = ids + c[i].id + ",";
                    totd++;
                }
                else
                {
                }
            }


            var d1 = new Date();
            var date1 = d1.setHours(0, 0, 0,0);
            var startOn =  date1/ 1000;

            var id = $cookieStore.get("userid");

            var oFCKeditor = new FCKeditor('creative');
            var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
            var cont = oEditor.GetHTML();


            var obj = {

                "nlmId": $scope.nlmId,
                "campId": $scope.newsletter.campId,
                "userId": $scope.userId,
                "SN": $scope.sender,
                "SL": $scope.subject,
                "creative": cont,
                "domains": $scope.selection,
                "emails": [$scope.testMailInput],
                "startAt": $scope.newsletter.startOn,
                "totalVol": parseInt($scope.emailIdLength)*parseInt(totd),
                "domainWise": $scope.domainObj,
                "tempVol": $scope.emailIdLength,
                "dateStamp": startOn

            };


            //console.log("sendTestMailIn  : "+JSON.stringify(obj));

            $scope.testMailInput = "";
            console.log('test mail will be sent')

            var id = $cookieStore.get("userid");
            if (id === undefined || ( JSON.stringify(id).indexOf('null') > -1)) {
                window.location.href = "./";
            } else {

                //alert("calling testmail:  " + JSON.stringify(obj));
                $http({
                    method: 'POST',
                    url: "users/createTestNews",
                    data: obj
                }).then(function successCallback(response) {
                    //alert(JSON.stringify(response));

                    if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1)
                    {
                        window.location.href = "./";
                    } else {

                        if(response.data.error == "campaign sent successfully !")
                        {
                            alert("Test Mail Sent Successfully");
                        }
                        else{
                            alert(response.data.error);
                        }
                        $scope.showLoading = false;

                        //$scope.selection=[];

                        $('#myModal1').modal('hide');


                    }
                }, function errorCallback(response) {
                    $scope.selection=[];
                    alert('error4' + response);
                })

            }
        }
        else {
            //alert(" improper data");
            $('#myModal1').modal('show');
            // $scope.showingTest = 0;
        }

        //alert($scope.showingTest)
    }

    $scope.exceedPick = false;
    $scope.pushUp =$scope.pickVol-$scope.sentVol;
    $scope.exceedIndex=-1;
    $scope.closeExceed = function()
    {
        //alert("closeExceed");
        $scope.pushUp =$scope.pickVol-$scope.sentVol;
        $scope.exceedPick = false;
    }

    $scope.takeVol = [];
    $scope.uniqueVol = [];
    $scope.checkPickVol=function(ipVal,y,index)
    {
        //alert("ipVal  : "+ipVal+" index  "+index+" task "+JSON.stringify($scope.taskselection));
        //alert(" y "+$scope.taskselection.indexOf(y));


        if($scope.taskselection.indexOf(y) != -1 && typeof ipVal != 'undefined'){
            //$scope.takeVol[index]={id:y,vol:ipVal};
            $scope.takeVol.push({id:y,vol:ipVal});
            //alert(JSON.stringify($scope.takeVol));
        }else {
            // $scope.takeVol[index]={};
        }

    }
        //$scope.takeVol[index]=ipVal;
        $scope.exceedIndex = index;
        $scope.pushUp = $scope.pushUp - ipVal;
        if($scope.pushUp<0){$scope.exceedPick = true;}
        else{
            $scope.exceedPick = false;}
        // alert("$scope.pushUp "+$scope.pushUp+"ipVal  :  "+ipVal);

    $scope.taskselection = [];
    $scope.validIp = [];


    $scope.changedTask = function (x, y,index) {
        // alert(x+" and y is  "+y+" takeSEl  "+$scope.taskselection.indexOf(y));

        if(x){
            $scope.validIp.push(x);
        }
        else if($scope.validIp!=[]){

            $scope.validIp.pop(x);
        }

        if(x){

            if($scope.taskselection.indexOf(y)==-1)
            {
                $scope.taskselection.push(y);
            }

            var obj = {userId:$scope.userId,nlmId:$scope.nlmId,sentOn:$scope.newsletter.startOn}

            $http({
                method: 'POST',
                url: 'users/checkDomain',
                data: obj
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    var obj=response.data;
                    // console.log("obj checkDomain  :  ",obj,"  obj.length   :  ",obj.length);
                    if(obj.length != 0)
                    {
                        alert("domain already exist");
                    }
                }

            }, function errorCallback(response) {
                console.log('error');
                console.log(response);
            });
        }

    }

    $scope.emptyVol = false;
    $scope.showLoading = false;
    $scope.startMailing = function() {

        $scope.showLoading = true;
        //alert("takeVol   :  " + JSON.stringify($scope.takeVol));
        if ($scope.takeVol.length !=0) {

            $scope.temp = 0;
            $scope.tempTake = $scope.takeVol;
            $scope.tempTake.forEach(function (obj) {
                $scope.temp = $scope.temp + obj.vol;
            });
            //!************* TestNews Create **********************



            //console.log("JSON.stringify(newsletter)  :  "+JSON.stringify($scope.newsletter));

            var oFCKeditor = new FCKeditor('creative');
            var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
            var cont = oEditor.GetHTML();



            var objTest = {
                newsName:$scope.newsletter.title,
                agentName: $cookieStore.get('userName'),
                userRelId:$scope.newsletter.userRel.id,
                campId: $scope.newsletter.campId,
                nlmId: $scope.nlmId,
                SN: $scope.sender,
                SL: $scope.subject,
                creative: cont,
                startAt: $scope.newsletter.startOn,
                userId: $scope.userId,
                totalVol: $scope.temp,
                domainWise: $scope.takeVol,
                tempVol: $scope.temp,
                dateStamp: $scope.dateStamp
            }



            //console.log("objTest  : "+JSON.stringify(objTest));

            //alert("OBJECT Of STARTMAIL  :  "+JSON.stringify(objTest));
            $http({
                method: 'POST',
                url: 'users/createTestNews',
                data: objTest
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {

                    var obj=response.data;
                    //$scope.newsData=obj.data;
                    /*  alert(obj.error);*/
                    /* if(response.data.error == "campaign sent successfully !")
                     {
                     alert("Test Mail Sent Successfully");
                     }
                     else{*/
                    alert(response.data.error);
                    /*}*/
                    // console.log("newsData of campaign:   ",obj);
                    $scope.showLoading = false;

                    $scope.pushUp = $scope.pickVol - $scope.sentVol;
                    $scope.exceedPick = false;
                    $("#myModal").modal('hide');

                    window.location.href = "#users/mycampaigns";

                }

            },function errorCallback(response){
                $scope.showLoading = false;
                console.log('error');
                console.log(response);

                /* $scope.pushUp = $scope.pickVol - $scope.sentVol;
                 $scope.exceedPick = false;*/
                $("#myModal").modal('hide');
            });


        }
        else {
            //alert("inside else");
            $scope.emptyVol = true;
            $("#myModal").modal('show');
        }

    }


    $scope.startTest = false;

    $scope.getUserDomain = function(){

        $http({
            method: 'GET',
            url: 'users/allDomainDetail',

        }).then(function successCallback(response) {
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {
                var obj=response.data;
                $scope.userDomains=obj.data;
                // console.log("getUserDomain:   ",$scope.userDomains);
            }

        }, function errorCallback(response) {
            console.log('error');
            console.log(response);
        });
    }

    $scope.getUserDomain();

    $scope.startCampaign = function () {

        $scope.showLoading = false;
        //alert("startCampaign 1111");
        $scope.getUserDomain();
        $scope.startTest = true;
        var obj = {
            "id": parseInt(id),
            "nlmId": $scope.nlmId,
            "SN": $scope.sender,
            "SL": $scope.subject
        }
        // console.log('will start the campaign');
        // console.log(obj);
        var id = $cookieStore.get("userid");
        if (id === undefined || ( JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {

        }

    }




}])







sampleApp.controller('innerCampEditCtrlR',[ 'innerCampEdit0','fileUpload','$rootScope','$timeout','$scope', '$cookies', '$cookieStore', '$window', '$routeParams', '$http', function (innerCampEdit0,fileUpload,$rootScope,$timeout,$scope, $cookies, $cookieStore, $window, $routeParams, $http) {

    $scope.subjects = [];
    $scope.senders = [];



    $scope.userId = innerCampEdit0.getUserId();
    $scope.nlmId = innerCampEdit0.getNlmId();
    var ctdOn = innerCampEdit0.getCtdOn();
    var campId = innerCampEdit0.getCampId();
    var nlId = innerCampEdit0.getNlId();



    $scope.fileUndefined=false;
    $scope.fileNoZip = false;
    var oFCKeditor = new FCKeditor('editor');
    $scope.fileUpload = function () {

        console.log("fileUpload");

        var file = $scope.myFile;

        var file1 = document.getElementById("uploadFile");
        var fileName1=file1.value.toString();
        if(fileName1.split('.').pop().toLowerCase() == "zip" ){

            var uploadUrl = "/users/uploadFile";
            fileUpload.async(file,uploadUrl).then(function(res){

                $scope.uploadDetails = res.data;
                $scope.fckmodel= res.data;

                //  console.log(res.data);
                //document.getElementById("editor").innerHTML(res.data);

                $scope.fckValue = 0;
                var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
                oEditor.SetHTML(res.data);
                $scope.radioModel='create';
                $scope.showUploadNew ="true";

            });


        }else if(typeof file=="undefined"){
            $scope.fileNoZip = false;
            $scope.fileUndefined=true;
            //alert("Please Select the file to be uploaded");
        }else{ $scope.fileNoZip = true;
            $scope.fileUndefined=false;
            //alert("Please Upload Only Zip File");
        }

    }

    $scope.fcmodelSpan = false;


    $http({
        method: 'POST',
        url: "users/getNewsLetter",
        data: {
            'nlId': parseInt($scope.nlmId),
        }
    }).then(function successCallback(response) {


        if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
            window.location.href = "./";
        } else {
            if (response.data.error) {
                console.log(response.data.error)
                alert(response.data.error);
            } else if (response.data.success) {

                $scope.newsletter = response.data.success;

                /*$scope.senders = $scope.newsletter.SN;
                 $scope.subjects = $scope.newsletter.SL;*/
                //$scope.senders.push($scope.newsletter.SN);
                for (sn in $scope.newsletter.SN) {
                    if (typeof $scope.newsletter.SN[sn] != "function") {
                        $scope.senders.push($scope.newsletter.SN[sn]);
                    }
                }

                //$scope.subject = $scope.senders[0];
                for (sl in $scope.newsletter.SL) {
                    if (typeof $scope.newsletter.SL[sl] != "function") {
                        $scope.subjects.push($scope.newsletter.SL[sl]);

                    }

                }
                $scope.sender = $scope.subjects[0];
                //$scope.subjects.push( $scope.newsletter.SL);
                /*            console.log($scope.newsletter)
                 console.log($scope.senders)
                 console.log($scope.subjects)*/

                var myEl = angular.element(document.querySelector('#editor'));
                myEl.html($scope.newsletter.creative);




                $scope.fckValue = 0;

                var oFCKeditor = new FCKeditor('editor');
                //alert("ctrl3 called");
                $scope.fckeditor = function(){
                    //alert("fckeditor  ");
                    if($scope.fckValue<1){

                        oFCKeditor.BasePath = "/FCKeditor_2.0rc3/";
                        oFCKeditor.Width = 700;
                        oFCKeditor.Height = 500;
                        oFCKeditor.ProcessHTMLEntities = false;
                        oFCKeditor.ReplaceTextarea();
                        $scope.fckValue++;

                    }
                    else{
                        var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
                        oEditor.SetHTML($scope.newsletter.creative);
                    }

                }
                $scope.fckeditor();








                $scope.nTags = [];
                $scope.newsTagIds = 0;
                for (i = 0; i < $scope.newsletter.tags.length; i++) {
                    //$scope.newsTagIds.push(res.data.tags[i]);
                    $scope.newsTagIds = $scope.newsletter.tags[i];
                    $http({

                        method: 'GET',
                        url: '/users/getNewsTags1/' + $scope.newsTagIds

                    }).then(
                        function successCallBack(res) {
                            // console.log("response ");
                            // console.log(res);
                            //console.log("response of campaingn7 ctrl" + res);
                            $scope.news1Tags = res.data;

                            //  console.log("res.data.name...." + res.data.id);

                            $scope.nTags.push({"name": res.data.name, "id": res.data.id});
                            /*$scope.tagIn.push({"text":res.data.name, "id":res.data.id});*/

                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });
                }


                $scope.nBrands = [];
                $scope.newsBrandIds = 0;
                if(typeof $scope.newsletter.tBrands != 'undefined'){
                    for (i = 0; i < $scope.newsletter.tBrands.length; i++) {
                        //$scope.newsTagIds.push(res.data.tags[i]);
                        $scope.newsBrandIds = $scope.newsletter.tBrands[i];

                        $http({

                            method: 'GET',
                            url: '/users/getNewsTags1/' + $scope.newsBrandIds


                        }).then(
                            function successCallBack(res) {
                                // console.log("response ");
                                // console.log(res);
                                // console.log("response of campaingn7 ctrl" + res);
                                $scope.brand1Tags = res.data;

                                // console.log("res.data.name...." + res.data.id);

                                $scope.nBrands.push({"name": res.data.name, "id": res.data.id});


                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }}

                $scope.ntPRs = [];
                $scope.newstPrIds = 0;
                if(typeof $scope.newsletter.tPR != 'undefined'){
                    for (i = 0; i < $scope.newsletter.tPR.length; i++) {
                        //$scope.newsTagIds.push(res.data.tags[i]);
                        $scope.newstPrIds = $scope.newsletter.tPR[i];

                        $http({

                            method: 'GET',
                            url: '/users/getNewsTags1/' + $scope.newstPrIds

                        }).then(
                            function successCallBack(res) {
                                // console.log("response ");

                                //  console.log("res.data.name...." + res.data.id);

                                $scope.ntPRs.push({"name": res.data.name, "id": res.data.id});

                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }
                }

                $scope.nCatTags = [];
                $scope.catIds = 0;

                if (typeof $scope.newsletter.reTarget != 'undefined')
                {
                    if (typeof $scope.newsletter.reTarget.catTags != 'undefined')
                    {
                        for (i = 0; i < $scope.newsletter.reTarget.catTags.length; i++) {

                            $scope.catIds = $scope.newsletter.reTarget.catTags[i];

                            $http({

                                method: 'GET',
                                url: '/users/getNewsTags1/' + $scope.catIds


                            }).then(
                                function successCallBack(res) {
                                    // console.log("response ");
                                    // console.log(res);
                                    // console.log("response of campaingn7 ctrl" + res);
                                    //  console.log("res.data.name...." + res.data.id);

                                    $scope.nCatTags.push({"name": res.data.name, "id": res.data.id});

                                },
                                function errorCallBack(res) {
                                    //alert("error");
                                    console.log("error in tags");

                                    return res.data;
                                });
                        }
                    }

                    var idObj = {countryId:$scope.newsletter.reTarget.countries};
                    $http({

                        method: 'POST',
                        url: '/users/getCountriesById/',
                        data:idObj

                    }).then(
                        function successCallBack(res) {

                            //console.log("getCountriesById  res  :  "+JSON.stringify(res.data))
                            if(typeof res.data.data != 'undefined'){
                                console.log("    and  :  ",res.data.data.name);
                            $scope.newsletter.country=res.data.data.name;
                            }

                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });

                    var idObj = {eDomain:$scope.newsletter.reTarget.eDomain};
                    $http({

                        method: 'POST',
                        url: '/users/getEdomainById/',
                        data:idObj

                    }).then(
                        function successCallBack(res) {

                            // console.log("getEdomainById  res  :  "+JSON.stringify(res.data)," and name  :  ",res.data.name);
                            $scope.newsletter.eDomain=res.data.name;
                            //  console.log("$scope.newsletter.eDomain   :  "+$scope.newsletter.eDomain);
                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });
                }

                if(typeof $scope.newsletter.reTarget != 'undefined'){
                    if(typeof $scope.newsletter.reTarget.cities != 'undefined'){
                        var idObj = {cityIds:$scope.newsletter.reTarget.cities};
                        $http({

                            method: 'POST',
                            url: '/users/getCityByIds/',
                            data:idObj

                        }).then(
                            function successCallBack(res) {

                                //console.log("getcityById  res  :  "+JSON.stringify(res.data));
                                $scope.newsletter.city=res.data.data;

                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }}

            } else {

            }

        }
    }, function errorCallback(response) {
        alert('error5' + response);
    });


    $scope.senderData = [];
    $scope.senderData = $scope.senders;
    var i=0;
    $scope.senderSubmit= false;
    $scope.addSender = function(senderName)
    {

        if(senderName!='' && senderName != null && $scope.senderData.length<3){
            $scope.senderData.push(senderName);
            $scope.senderName='';
        }
        if(senderName != null && senderName!='' )
        {    i++;
            if(i>3 && $scope.senderData.length==3){
                $scope.senderSubmit=true;}

        }

    }


    $scope.subjectData = [];
    $scope.subjectData = $scope.subjects;
    $scope.subjectSubmit=false;
    var j=0;
    $scope.addSubject = function(subject)
    {

        if(subject!='' && subject != null && $scope.subjectData.length<3){
            $scope.subjectData.push(subject);
            $scope.subject='';
        }
        if(subject != null && subject!='')
        {    j++;
            if(j>3 && $scope.subjectData.length==3){
                $scope.subjectSubmit=true;}
            //alert("Sender Name limit exceed");
        }
    }
    $scope.removeSender=function(index)
    {
        $scope.senderData.splice(index,1);
        $scope.senderSubmit=false;
    }
    $scope.removeSubject=function(index)
    {
        $scope.subjectData.splice(index,1);
        $scope.subjectSubmit=false;
    }


    $scope.processing=false;
    $scope.saveInnerEdit = function()
    {

        console.log("editor R innerCampEditCtrlR");
        var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
        var cont = oEditor.GetHTML();
        $scope.editorContent=oEditor.GetHTML();


        if(typeof cont == "undefined" || cont==''|| $scope.senderData=='' || $scope.subjectData== '' ||cont=='<br>')
        {
            if($scope.senderData!='' && $scope.subjectData!= ''){
                $scope.fcmodelSpan = true;
            }
            else {
                $scope.fcmodelSpan = false;
            }

            console.log("Incomplete data line no.:1121");
        }
        else{


            $scope.processing=true;
            var obj ={status:'',SN:$scope.senderData,SL:$scope.subjectData,cBy:$scope.userId,newsId:$scope.nlmId, creative:cont};
            console.log("obj : "+obj);

            $http({

                method:'POST',
                url : '/users/getNLIDR',
                data:obj

            }).then(function successCallBack(res){

                    if(res.length<1){
                        $window.location.reload();
                    }
                    else{
                        var obj ={status:'',SN:$scope.senderData,SL:$scope.subjectData,cBy:$scope.userId,newsId:$scope.nlmId, creative:cont};
                        $http({

                            method:'POST',
                            url : '/users/updateStep3R',
                            data:obj

                        }).then(function successCallBack(res){

                                if(res.length<1){
                                    $window.location.reload();
                                }
                                else{
                                    $window.location ="#/users/innerCampaignR";
                                }

                            },
                            function errorCallBack(res){
                                console.log(res.data);
                                $scope.processing=false;
                            })


                    }

                },
                function errorCallBack(res){
                    console.log(res.data);
                    $scope.processing=false;
                })
        }
    }






}])



sampleApp.controller('add_esp_controller', function ($filter, $window, socket, $scope, $cookies, $cookieStore, $http, $routeParams) {
    var loginID = $cookieStore.get("userid");
    $scope.submitted = false;
    $scope.colcor = {

        name: ''
    }
    $scope.rep = 3;
    $scope.rep1 = 2;
    $scope.error4=91;
    $scope.campaignFunc = function (impt) {
        if ($scope.campaign_name.length == 0) {
            $scope.imageName = '';
            $scope.trackName = '';
        }
        var patt = new RegExp("^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\\.[a-zA-Z]{2,}$", "g");
        // alert("--->"+patt.test($scope.campaign_name));
        // var res23 = $scope.campaign_name.match();
        var res23 = patt.test($scope.campaign_name);
        if(res23){

            $scope.imageName = "http://img." + $scope.campaign_name;
            $scope.trackName = "http://t." + $scope.campaign_name;
            $scope.error4=19;
        }else if(!res23){
            $scope.imageName = '';
            $scope.trackName = '';
            if($scope.campaign_name.length!=0){
                $scope.error4=9;
            }
        }

        $scope.camCheck = 9;
        $scope.rep = 4;

    };
    $scope.imageFun=function(){
        $scope.imageName=$scope.imageName;
    }
    $scope.trackFun=function(){
        $scope.trackName = $scope.trackName;
    }
    $scope.msgFunc = function () {
        $scope.alertMsg = '';
        $scope.camCheck1 = 10;
        $scope.rep = 5;
    };
    $scope.regex1 = /^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\\.[a-zA-Z]{2,}$/;
    $scope.services = [
        {esp: 1, ServiceName: 'Gmail'},
        {esp: 2, ServiceName: 'Yahoo'},
        {esp: 3, ServiceName: 'Hotmail'},
        {esp: 4, ServiceName: 'msn'},
        {esp: 5, ServiceName: 'aol'}
    ];
    $scope.etypes = [{eType: "Validation"}, {eType: "Direct"}]
    $scope.cols = {
        nname: ''
    }

    $scope.addesps = function () {

        $scope.test1 = $scope.rep;
        if(typeof $scope.campaign_name == 'undefined') {
            $scope.test1=3;
            $scope.checkValidation1=1;
            $scope.multipleEsps=[];
        }
        else if(typeof $scope.message_id == 'undefined') {
            $scope.camCheck=9;
            $scope.test1=4;
            $scope.checkValidation1=1;
            $scope.multipleEsps=[];

        }
        else if ($scope.colcor.name.length ==0) {
            $scope.camCheck1=10 ;
            $scope.test1=5;
            $scope.checkValidation1=1;
            $scope.multipleEsps=[];
        }
        else if (typeof $scope.window1 == 'undefined') {
            $scope.camCheck1=11;
            $scope.test1=6;
            $scope.checkValidation1=1;
            $scope.multipleEsps=[];
        }
        if (typeof $scope.campaign_name != 'undefined' && $scope.imageName.length != 0 && $scope.trackName.length != 0 && $scope.message_id.length != 0 && $scope.colcor.name.length != 0 && typeof $scope.window1 != 'undefined') {
            $scope.test1 = 8;
        } else {
        }
    }
    $scope.rname = function () {
        $scope.alertMsg = '';

        if ($scope.colcor.name == "Opl") {
            $scope.ETYPE = "PD";
        } else if ($scope.colcor.name == "Ops") {
            $scope.ETYPE = "PL";
        } else if ($scope.colcor.name == "Oml") {
            $scope.ETYPE = "MD";
        } else if ($scope.colcor.name == "Oms") {
            $scope.ETYPE = "ML";
        } else if ($scope.colcor.name == "Otl") {
            $scope.ETYPE = "TD";
        } else {
            $scope.ETYPE = "TL";
        }
        $scope.camCheck1 = 11;
        $scope.rep = 6;

    }
    $scope.rrname = function () {
        if ($scope.cols.nname == "option1") {
            $scope.TYPE = 1;
        } else {
            $scope.TYPE = 0;
        }
        $scope.rep1 = 6;

    }
    $scope.acFunc = function () {
        $scope.ActualP = $scope.AP;
        $scope.CurrentPush = $scope.AP;
        $scope.rep1 = 4;
    }
    $scope.curFunc = function (aaa) {

        if ($scope.aaa != $scope.AP) {
            $scope.CurrentPush = $scope.ActualP;
        }
        $scope.rep1 = 5;
    }

    $scope.editEsp = function (editedEsp) {
        var oType = $scope.TYPE;
        $scope.editedEsp1 = editedEsp;
        $scope.h = 10001;
        $scope.esp = $scope.multipleEsps[editedEsp].esp;
        $scope.AP = $scope.multipleEsps[editedEsp].AP;
        $scope.ActualP = $scope.multipleEsps[editedEsp].CP;

        $scope.share = $scope.multipleEsps[editedEsp].share;
        if ($scope.multipleEsps[editedEsp].type) {
            $scope.cols.nname = "option1";
        } else {
            $scope.cols.nname = "option2";
        }


        $scope.window2 = $scope.multipleEsps[editedEsp].capacity;
    }


    $scope.deleteEsp = function (deletedEsp) {

        $scope.multipleEsps.splice(deletedEsp, deletedEsp + 1);
        if ($scope.multipleEsps.length == 0) {
            $scope.removeSave = 5;
            $scope.espcount = 0;
            $scope.multipleEsps=[];
        }
    }

    $scope.windowFunc = function () {
        // $scope.window2 = parseInt($scope.ActualP * $scope.window1 * 60);
        $scope.camCheck1 = 12;
        $scope.rep = 7;
    }
    $scope.shareFunc = function () {
        $scope.share2 = $scope.share;
        $scope.rep1 = 5;
    }
    $scope.removeSave = 3;
    $scope.multipleEsps = [];
    $scope.espcount = 0;
    $scope.cc = 0;
    $scope.espFunc = function () {
        $scope.rep1 = 3;
    }

    $scope.addingDetails = function () {
        // alert("Dgdfg");
        // alert(typeof $scope.esp+"_"+typeof $scope.share+"_"+$scope.cols.nname.length);

        $scope.checkValidation = $scope.rep1;
        if(typeof $scope.esp == 'undefined') {
            $scope.checkValidation=2;
            $scope.checkValidation1=1;
        }
        else if (!$scope.AP) {
            $scope.checkValidation=3;
            $scope.checkValidation1=1;

        }
        else if ($scope.cols.nname.length ==0) {

            $scope.checkValidation=5;
            $scope.checkValidation1=1;
        }
        // alert("coming");
        if ($scope.esp!= 'undefined'  &&  $scope.AP.length != 0 && $scope.cols.nname.length != 0) {
            $scope.checkValidation1 = 6;
            $scope.ActualPush = $scope.AP;
            $scope.Window = $scope.window1;
            $scope.Share = $scope.share;
            $scope.ESP = $scope.esp;
            $scope.aa = {
                esp: parseInt($scope.esp),
                AP: parseInt($scope.AP),
                CP: parseInt($scope.CurrentPush),
                HS: 0,
                type: $scope.TYPE,
                wp: $scope.share,
                capacity: parseInt($scope.ActualPush * $scope.Window * 60)
            };
            $scope.IDID = $scope.ESP;
            if ($scope.espcount > 0) {
                if (typeof $scope.esp != 'undefined') {
                    if ($scope.esp!= 'undefined' &&  $scope.AP != -1 && $scope.cols.nname.length != 0) {
                        for (var ch = 0; ch < $scope.multipleEsps.length; ch++) {
                            if ($scope.multipleEsps[ch].esp == $scope.ESP) {
                                $scope.cc = $scope.cc + 1;
                            }
                        }
                        if ($scope.cc == 0) {
                            $scope.multipleEsps.push($scope.aa);

                        } else if ($scope.cc > 0) {
                            if ($scope.h == 10001) {
                                // if($scope.multipleEsps[$scope.editedEsp1].esp==parseInt($scope.esp)){
                                //     alert("esp already existed1");
                                // }
                                $scope.multipleEsps[$scope.editedEsp1].esp = parseInt($scope.esp);
                                $scope.multipleEsps[$scope.editedEsp1].AP = parseInt($scope.AP);
                                $scope.multipleEsps[$scope.editedEsp1].CP = parseInt($scope.CurrentPush);
                                $scope.multipleEsps[$scope.editedEsp1].HS = 0;
                                $scope.multipleEsps[$scope.editedEsp1].wp = $scope.share;
                                $scope.multipleEsps[$scope.editedEsp1].type = parseInt($scope.TYPE);
                                $scope.multipleEsps[$scope.editedEsp1].capacity = parseInt($scope.ActualPush * $scope.Window * 60);

                                $scope.cc = 0;

                            } else if ($scope.h != 10001){
                                alert("esp already existed");
                                $scope.h=10;
                                $scope.cc = 0;
                            }

                        }
                    }
                }
            }
            if ($scope.espcount == 0) {
                if ($scope.esp!= 'undefined' && $scope.AP != -1 && $scope.cols.nname.length != 0) {
                    $scope.espcount = $scope.espcount + 1;
                    $scope.multipleEsps.push($scope.aa);
                    $scope.removeSave=4;
                }

            }
            $scope.a = {
                name: $scope.campaign_name,
                imgUrl: $scope.imageName,
                trackUrl: $scope.trackName,
                msgId: $scope.message_id,
                esps: $scope.multipleEsps,
                HS: 0,
                cBy: loginID,
                capacity: 10000,
                eType: $scope.ETYPE

            }
        }
    };

    $scope.sendingEsps = function () {
        var totCapacity = 0;

        for (var ch = 0; ch < $scope.multipleEsps.length; ch++) {
            if ($scope.multipleEsps[ch].capacity) {

                totCapacity = totCapacity + $scope.multipleEsps[ch].capacity;

            }
        }
        $scope.a.capacity = totCapacity;
        // alert(JSON.stringify($scope.a));
        if (typeof $scope.AP.length != 0 && typeof $scope.window1 != 'undefined' && typeof $scope.cols.nname != 'undefined') {

            $scope.saveEsp($scope.a);
        }
    }

    $scope.saveEsp = function (mEsps) {

        var EspName = JSON.stringify(mEsps.name).substr(1, JSON.stringify(mEsps.name).length - 2);
        ;
        $http({
            method: 'POST',
            url: '/users/addesp/',
            data: {"dataEsp": mEsps, "nameCount": EspName}
        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {

                    if (typeof response.data.success != 'undefined') {


                        var mySplitResult = response.data.success;
                        if (mySplitResult > 0) {
                            alert("domain already exist");
                            window.location.href = "#users/adddomain";
                        }
                        var mySplitResults = mySplitResult.split("^");
                        $scope.EspCount = JSON.parse(mySplitResults[0]);
                        $scope.EspResult = mySplitResults[1];
                        if ($scope.EspCount == 0) {
                            alert("Domain added successfully");
                            window.location.href = "#users/adddomain";
                        }
                    }
                    else if (typeof response.data.error != 'undefined') {

                        console.log("eeeeeeeee" + response.data.error)
                    }
                }
            }
            , function errorCallback(response) {
                alert("domain already exist");
            });
    };
    // $http({
    //     method: 'POST',
    //     url: '/users/updateesp/',
    //     data: {"domainId": b, "Name": EspName, "esps": mEsps.esps, "ESPid": mEsps.esps[0].esp}
    // }).then(function successCallback(response) {
    //
    //         if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
    //             window.location.href = "./";
    //         } else {
    //
    //             if (typeof response.data.success != 'undefined') {
    //
    //
    //                 var Result1 = response.data.success;
    //                 alert(JSON.stringify(Result1));
    //
    //
    //
    //             }
    //             else if (typeof response.data.error != 'undefined') {
    //                 alert(response.data.error);
    //             }
    //         }
    //     }
    //     , function errorCallback(response) {
    //         alert('deletenewsleter' + JSON.stringify(response));
    //     });

});


sampleApp.controller('all_domains_controller', ['$rootScope', '$filter', '$window', 'socket', '$scope', '$cookies', '$cookieStore', '$http', function ($rootScope, $filter, $window, socket, $scope, $cookies, $cookieStore, $http) {

    $scope.filterSort1 = ["sortByOwner", "sortByName"]

    $scope.changeFilter = function (filterS) {

        alert(filterS);
        if (filterS == "sortByOwner") {
            $scope.pic = 'name1';
        }
        else if (filterS == "sortByName") {
            $scope.pic = 'name';
        }
    }

    $scope.selected = '';
    $scope.SelectedItem = '';
    $scope.healthcare = '';
    $scope.usersEmail = '';
    $scope.selectedEsp = '';


    $scope.health12 = function (take) {


        if ($scope.healthcare === '') return true;
        var check = take.HS;
        if ($scope.healthcare > 0.75 && $scope.healthcare <= 1.00) {
            if (check > 0.75 && check <= 1) {
                var reg = RegExp("^" + take.name + "$");
                return reg.test(take.name);
            }
        }
        else if ($scope.healthcare > 0.5 && $scope.healthcare <= 0.75) {
            if (check > 0.5 && check <= 0.75) {
                var reg = RegExp("^" + take.name + "$");
                return reg.test(take.name);
            }

        }
        else if ($scope.healthcare > 0.20 && $scope.healthcare <= 0.50) {
            if (check > 0.20 && check <= 0.50) {
                var reg = RegExp("^" + take.name + "$");
                return reg.test(take.name);
            }

        }
        else if ($scope.healthcare >= 0.0 && $scope.healthcare <= 0.20) {
            if (check >= 0.0 && check <= 0.20) {
                var reg = RegExp("^" + take.name + "$");
                return reg.test(take.name);
            }

        }

        // //if ($scope.healthcare === '') return true;
        //
    };
    $scope.statusfilter = function (word) {
        // alert(JSON.stringify(word))
        if ($scope.selected === '') {
            return true;
        }
        var reg = RegExp("^" + $scope.selected + "$");
        return reg.test(word.status);
    };
    $scope.alldomains1 = function (wword) {
        if ($scope.usersEmail === '') return true;
        for (var jj in $scope.AllUSERS) {
            if (JSON.stringify($scope.usersEmail) == JSON.stringify($scope.AllUSERS[jj].email)) {
                if (typeof JSON.stringify($scope.AllUSERS[jj].name) === 'undefined') return "";
                else {
                    $scope.Name = JSON.stringify($scope.AllUSERS[jj].name);
                    $scope.Name = $scope.Name.substr(1, $scope.Name.length - 2);
                    var reg = RegExp("^" + $scope.Name + "$");
                    return reg.test(wword.name1);

                }
            }
        }
    };
    $scope.esp1 = [];
    $scope.alldomains3 = function (wword8) {
        // alert(JSON.stringify(wword8).name);
        if ($scope.selectedEsp === '') return true;
        if ($scope.selectedEsp == 4 || $scope.selectedEsp == 5) return false;
        if ((wword8.esp0 != 0 && $scope.selectedEsp == 1) || (wword8.esp1 != 0 && $scope.selectedEsp == 2) || (wword8.esp2 != 0 && $scope.selectedEsp == 3)) {

            var reg = RegExp("^" + wword8.name + "$");
            return reg.test(wword8.name);
        }
    }

    // alert(JSON.stringify($scope.twoDim.name));
    $scope.secondFilter = [];

    $http({
        method: 'POST',
        url: 'users/AllDomains/',

    }).then(function successCallback(response) {

            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {

                if (typeof response.data.success != 'undefined') {


                    var myString = response.data.success;


                    var mySplitResult = myString.split("-");
                    //alert("mySplitResult length :: "+mySplitResult.length);
                    $scope.AllDOMAINS = JSON.parse(mySplitResult[0]);
                    var just = mySplitResult[0];
                    $scope.AllUSERS = JSON.parse(mySplitResult[1]);

                    var k = JSON.parse(mySplitResult[0]);

                    var kl = JSON.stringify(k);
                    //console.log(JSON.stringify(k));
                    var keys = [];
                    $scope.names = [];
                    for (var domain in $scope.AllDOMAINS) {
                        keys.push($scope.AllDOMAINS[domain].asgnTo)
                    }
                    for (var key in keys) {
                        var ch = keys[key]
                        for (var User in $scope.AllUSERS) {
                            if (ch == $scope.AllUSERS[User].id) {
                                $scope.names.push($scope.AllUSERS[User].name)


                            }
                        }
                    }

                    $scope.twoDim = [];
                    var z = 0;
                    km = z + 1;
                    $scope.all = [];
                    for (var i in k) {
                        // var a = [{}];
                        var a = {};
                        $scope.Name = JSON.stringify(k[i].name);
                        $scope.Name = $scope.Name.substr(1, $scope.Name.length - 2);
                        a.name = $scope.Name;
                        if (typeof k[i].esps != 'undefined') {
                            var mn = JSON.stringify(k[i].esps);
                            var mnn = JSON.parse(mn);
                            var ar = [];
                            for (var m in mnn) {
                                if (JSON.stringify(mnn[m].capacity)) {
                                    if (JSON.stringify(mnn[m].esp) == 1) {
                                        ar[0] = JSON.stringify(mnn[m].capacity);
                                    } else if (JSON.stringify(mnn[m].esp) == 2) {
                                        ar[1] = JSON.stringify(mnn[m].capacity);
                                    } else if (JSON.stringify(mnn[m].esp) == 3) {
                                        ar[2] = JSON.stringify(mnn[m].capacity);
                                    } else if (JSON.stringify(mnn[m].esp) == 4) {
                                        ar[3] = JSON.stringify(mnn[m].capacity);
                                    } else {
                                    }
                                    // alert(JSON.stringify(mnn[m].capacity));
                                }

                            }
                            a.esp0 = ar[0];
                            a.esp1 = ar[1];
                            a.esp2 = ar[2];
                            a.esp3 = ar[3];

                            a.name1 = ($scope.names[z]);
                            a.HS = (JSON.stringify(k[i].HS))
                            a.asgnTo = (JSON.stringify(k[i].asgnTo));
                            a.id = (JSON.stringify(k[i].id))
                            a.status = (JSON.stringify(k[i].status))
                            a.email = (JSON.stringify(k[i].email))

                            z = z + 1;
                            // console.log(JSON.stringify(a), a.name1, "<--------------------------");
                            $scope.twoDim.push(a);
                        }
                    }


                }

                else if (typeof response.data.error != 'undefined') {
                    alert(response.data.error);
                }
            }
        }
        , function errorCallback(response) {
            alert('deletenewsleter' + JSON.stringify(response));
        });

}]);

sampleApp.controller('single_domain_controller', ['$rootScope', '$filter', '$window', 'socket', '$scope', '$cookies', '$cookieStore', '$http', '$routeParams', function ($rootScope, $filter, $window, socket, $scope, $cookies, $cookieStore, $http, $routeParams) {
    //alert($scope.ipip)\
    $scope.status21=71;
    $scope.startOn1 = $filter('date')(Date.now(), "dd-MM-yyyy");
    $scope.endOn1 = $filter('date')(Date.now(), "dd-MM-yyyy");
    var domainId = $routeParams.domainId;
    $scope.domainName = $routeParams.name;
    $scope.hscore = $routeParams.hScore;
    $scope.chechingip='';
    $scope.selectedColumn = null;

    $scope.emailvalid=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    $scope.viewIps=function(){
        $http({
            method: 'POST',
            url: 'users/viewIPS/',
            data: {"domainId": domainId}
        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (typeof response.data.success != 'undefined') {
                        var myStringSSS = response.data.success;
                        $scope.viewips=myStringSSS;
                        $scope.arrayIndex=[$scope.viewips.length];
                    }
                    else if (typeof response.data.error != 'undefined') {
                        alert(response.data.error);
                    }
                }
            }
            , function errorCallback(response) {

            });
    };
    $scope.updateDomain=function() {
        if (typeof $scope.ip1 == 'undefined') {
            $scope.chechingip = 2;
        } else if (typeof $scope.hostname1 == 'undefined') {
            $scope.chechingip = 3;
        } else if (typeof $scope.fromemail == 'undefined') {
            $scope.chechingip = 4;
        } else if (typeof $scope.toemail == 'undefined') {
            $scope.chechingip = 5;
        } else if (typeof $scope.bounceemail == 'undefined') {
            $scope.chechingip = 6;
        } else if (typeof $scope.capacityIp == 'undefined') {
            $scope.chechingip = 7;
        } else if (typeof $scope.currentpush == 'undefined') {
            $scope.chechingip = 8;
        }
        else if (typeof $scope.dbip == 'undefined') {
            $scope.chechingip = 9;
        }
        if(typeof $scope.ip1 != 'undefined'&&typeof $scope.hostname1 != 'undefined'&&typeof $scope.fromemail != 'undefined'
            &&typeof $scope.toemail != 'undefined'&&typeof $scope.bounceemail != 'undefined'&&typeof $scope.capacityIp != 'undefined'
            &&typeof $scope.currentpush != 'undefined' && typeof $scope.dbip!='undefined'){
            var addIp = {
                "ip": ($scope.ip1).toString(),
                "hostName": $scope.hostname1,
                "fromMail": $scope.fromemail,
                "replyMail": $scope.toemail,
                "bounceMail": $scope.bounceemail,
                "dId": parseInt(domainId),
                "capacity": parseInt($scope.capacityIp),
                "curPush": parseInt($scope.currentpush),
                "cOn": parseInt(JSON.stringify($scope.SINGLEDOMAIN.cOn)),
                "status": 1,
                "dbip": $scope.dbip
            };
            $http({
                method: 'POST',
                url: 'users/updateDomain/',
                data: {"addIP": addIp}

            }).then(function successCallback(response) {

                    if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                        window.location.href = "./";
                    } else {
                        if (typeof response.data.success != 'undefined') {
                            var myStringSSS = response.data.success;
                            if(myStringSSS.length==47){
                                alert("Domain existed with this ip and hostName");
                                $('#myModal').modal('hide');
                            }else{
                                alert("successfully added");
                                $('#myModal').modal('hide');
                            }
                        }
                        else if (typeof response.data.error != 'undefined') {
                            alert(response.data.error);

                        }
                    }

                }
                , function errorCallback(response) {

                });
        }
    }
    $scope.setClickedRow = function (espCP, Push, name) {  //function that sets the value of selectedRow to current index
        $http({
            method: 'POST',
            url: 'users/updateCP/',
            data: {"did": domainId, "espId": parseInt(espCP), "CP": Push}

        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (typeof response.data.success != 'undefined') {
                        var myStringSS = response.data.success;
                    }
                    else if (typeof response.data.error != 'undefined') {
                        alert(response.data.error);

                    }
                }

            }
            , function errorCallback(response) {

            });
    }

    $scope.setClickedRow19=function(data9,IPid){
        $scope.heading1=41;
        // alert("fsdgdf"+data9+"-"+IPid)
        $http({
            method: 'POST',
            url: 'users/saveIP/',
            data: {"ip":data9.name90 , "hostName": data9.name1, "fromMail": data9.name2, "replyMail": data9.name3, "bounceMail": data9.name4, "capacity": data9.name5,"curPush": data9.name6,"dbip": data9.name7,"ID":IPid}

        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (typeof response.data.success != 'undefined') {
                        var myStringSS1 = response.data.success;
                        alert("updated successfully");
                    }
                    else if (typeof response.data.error != 'undefined') {
                        alert(response.data.error);

                    }
                }

            }
            , function errorCallback(response) {

            });

    }

    $scope.editfunc=function(){
        $scope.heading1=4;
    }
    $scope.changeStatus1=1;
    $scope.changeStatus='active';
    $scope.myOptions = ['active','inactive'];
    $scope.setClickedRow91=function(IPid,Ultra){

        // alert(document.getElementById("Ultra").value);
        $scope.arrayIndex[IPid] = 'false';
        $scope.status21=7;
        $scope.removeId=IPid;
        $scope.changeStatus="inactive";
        $scope.changeStatus1=0;
        $http({
            method: 'POST',
            url: 'users/removeIP/',
            data: {"ID":IPid,"stat":Ultra}

        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (typeof response.data.success != 'undefined') {
                        // var myStringSS1 = response.data.success;
                        alert("status changed");
                    }
                    else if (typeof response.data.error != 'undefined') {
                        alert(response.data.error);

                    }
                }

            }
            , function errorCallback(response) {

            });

    }

    $scope.startToday = function (startOn) {
        console.log("starton--" + startOn);

        $scope.itIs();
        $scope.getDidDetails();
    }
    $scope.endToday = function (endOn) {
        console.log("endon--" + endOn);
        $scope.itIs();
        $scope.getDidDetails();
    }
    $scope.selectedIP = function (selectedip) {
        $scope.ipip = $scope.selectedip;

        $scope.itIs();
        $scope.getDidDetails();

    }
    $scope.selectedESP = function (selectedesp) {

        $scope.itIs();
        $scope.getDidDetails();

    }
    $scope.ffff = [2, 5, 6, 2];
    $scope.ssss = [1, 2, 8, 6]

    $scope.health = function (HealthScore, RepScore, DATE) {
        $scope.activefun="active";
        $scope.activefun1="inactive";
        $scope.activefun2="inactive";
        $scope.activefun3="inactive";
        $scope.activefun4="inactive";

        Highcharts.chart('container', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Health Score and RepScore chart'
            },
            legend: {
                align: 'right',
                verticalAlign: 'middle',
                layout: 'vertical'
            },

            xAxis: {
                categories: $scope.DATE,
                labels: {
                    x: -10
                }
            },

            yAxis: {
                allowDecimals: false,
                title: {
                    text: 'Amount'
                }
            },

            series: [{
                name: 'HScore',
                data: $scope.HealthScore
            }, {
                name: 'RScore',
                data: $scope.RepScore
            }],

            responsive: {
                rules: [{
                    condition: {
                        maxWidth: 500
                    },
                    chartOptions: {
                        legend: {
                            align: 'center',
                            verticalAlign: 'bottom',
                            layout: 'horizontal'
                        },
                        yAxis: {
                            labels: {
                                align: 'left',
                                x: 0,
                                y: -5
                            },
                            title: {
                                text: null
                            }
                        },
                        subtitle: {
                            text: null
                        },
                        credits: {
                            enabled: false
                        }
                    }
                }]
            }
        });

    }
    $scope.volume = function (v) {
        $scope.activefun="inactive";
        $scope.activefun1="active";
        $scope.activefun2="inactive";
        $scope.activefun3="inactive";
        $scope.activefun4="inactive";
        // alert($scope.DATE+"--"+$scope.Volume);
        Highcharts.chart('container', {

            xAxis: {
                categories: $scope.DATE
            }, title: {
                text: 'Volume responsive chart'
            },
            size: {
                width: 400,
                height: 300
            },
            series: [{
                type: 'column',
                colorByPoint: true,
                data: $scope.Volume,
                showInLegend: false
            }]

        });

    }
    $scope.noGraphFun=function(){
        $scope.activefun="active";
        $scope.activefun1="inactive";
        $scope.activefun2="inactive";
        $scope.activefun3="inactive";
        $scope.activefun4="inactive";
        // alert($scope.DATE+"--"+$scope.Volume);
        Highcharts.chart('container', {

            xAxis: {
                categories: ''
            }, title: {
                text: 'No Graph'
            },
            size: {
                width: 400,
                height: 300
            },
            series: [{
                type: 'column',
                colorByPoint: true,
                data: '',
                showInLegend: false
            }]

        });

    }
    $scope.push = function (p) {
        $scope.activefun="inactive";
        $scope.activefun1="inactive";
        $scope.activefun2="active";
        $scope.activefun3="inactive";
        $scope.activefun4="inactive";
        Highcharts.chart('container', {

            xAxis: {
                categories: $scope.DATE
            }, title: {
                text: 'Push responsive chart'
            },
            size: {
                width: 400,
                height: 300
            },
            series: [{

                data: $scope.currentPush,
                type: 'line'
            }]

        });
    }
    $scope.reports = function (a, b, c, d,e) {
        $scope.activefun="inactive";
        $scope.activefun1="inactive";
        $scope.activefun2="inactive";
        $scope.activefun3="active";
        $scope.activefun4="inactive";
        // alert($scope.opens+"--"+$scope.clicks+"--"+$scope.delivered+"--"+$scope.Spam);
        var reportsVar=[];
        reportsVar[0]=0;

        Highcharts.chart('container', {

            xAxis: {
                categories: $scope.DATE,
                type: 'column'
            }, title: {

                text: 'Reports responsive chart'
            },
            series: [{
                name: 'Opens',
                data: $scope.opens
            }, {
                name: 'Clicks',
                data: $scope.clicks
            }, {
                name: 'Dlvrd',
                data: $scope.delivered
            }, {
                name: 'Unsyb',
                data: $scope.unSubs
            }, {
                name: 'Spam',
                data: $scope.Spam
            }]

        });

    }
    $scope.error_codes = function () {
        $scope.activefun="inactive";
        $scope.activefun1="inactive";
        $scope.activefun2="inactive";
        $scope.activefun3="inactive";
        $scope.activefun4="active";
        Highcharts.chart('container', {
            chart: {
                type: 'column'
            },

            title: {
                text: 'Errorcodes responsive chart'
            },
            legend: {
                align: 'right',
                verticalAlign: 'middle',
                layout: 'vertical'
            },

            xAxis: {
                categories: $scope.DATE,
                labels: {
                    x: -10
                }
            },

            yAxis: {
                allowDecimals: false,
                title: {
                    text: 'Amount'
                }
            },

            series: [{
                name: 'bounce',
                data: $scope.Bounce
            }, {
                name: 'defer',
                data: $scope.Defer
            }],

            responsive: {
                rules: [{
                    condition: {
                        maxWidth: 500
                    },
                    chartOptions: {
                        legend: {
                            align: 'center',
                            verticalAlign: 'bottom',
                            layout: 'horizontal'
                        },
                        yAxis: {
                            labels: {
                                align: 'left',
                                x: 0,
                                y: -5
                            },
                            title: {
                                text: null
                            }
                        },
                        subtitle: {
                            text: null
                        },
                        credits: {
                            enabled: false
                        }
                    }
                }]
            }
        });

    }

    $scope.singleDomain = function () {
        $http({
            method: 'POST',
            url: 'users/SingleDomain/',
            data: {"domainId": domainId}
        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (typeof response.data.success != 'undefined') {
                        var myString1 = response.data.success;
                        var mySplitResult = myString1.split("^");
                        // alert("mySplitResult length :: "+mySplitResult.length);

                        $scope.SINGLEDOMAIN = JSON.parse(mySplitResult[0]);
                        //alert("hello" + JSON.stringify($scope.SINGLEDOMAIN))
                        $scope.stre = mySplitResult[0];
                        $scope.ips = JSON.parse(mySplitResult[1]);
                        var second = [];
                        var first = [];
                        $scope.thousand= [0,0,0,0];
                        $scope.CurPush = [];
                        $scope.pushArray=[-1,-1,-1,-1];
                        for (var ids in  $scope.SINGLEDOMAIN.esps) {
                            // if(typeof JSON.stringify($scope.SINGLEDOMAIN.esps[ids].CP)!='undefined'){
                            //     $scope.CurPush.push(JSON.stringify($scope.SINGLEDOMAIN.esps[ids].CP));
                            // }
                            second.push(JSON.stringify($scope.SINGLEDOMAIN.esps[ids].esp));
                            var sr = JSON.stringify($scope.SINGLEDOMAIN.esps[ids].capacity);
                            if (!isNaN(sr)) {
                                if($scope.SINGLEDOMAIN.esps[ids].esp==1){
                                    $scope.thousand[0]=(sr / 1000);
                                    $scope.pushArray[0]=$scope.SINGLEDOMAIN.esps[ids].CP;
                                }else  if($scope.SINGLEDOMAIN.esps[ids].esp==2){
                                    $scope.thousand[1]=(sr / 1000);
                                    $scope.pushArray[1]=$scope.SINGLEDOMAIN.esps[ids].CP;
                                }else  if($scope.SINGLEDOMAIN.esps[ids].esp==3){
                                    $scope.thousand[2]=(sr / 1000);
                                    $scope.pushArray[2]=$scope.SINGLEDOMAIN.esps[ids].CP;
                                }else  if($scope.SINGLEDOMAIN.esps[ids].esp==4){
                                    $scope.thousand[3]=(sr / 1000);
                                    $scope.pushArray[3]=$scope.SINGLEDOMAIN.esps[ids].CP;
                                }

                            }

                        }


                        for (var chng in  $scope.ips) {

                            first.push($scope.ips[chng].ip)

                        }
                        $scope.itIs = function () {


                            for (var chh in $scope.ips) {
                                if (typeof $scope.ipip != 'undefined' && typeof $scope.ips[chh].ip != 'undefined')
                                    if (($scope.ipip).trim() == ($scope.ips[chh].ip).trim()) {
                                        $scope.IpId = JSON.stringify($scope.ips[chh].id)
                                    }
                            }
                        };
                        var store = $scope.ips.map(function (obj) {
                            return obj.ip;
                        });
                        store = store.filter(function (v, i) {
                            return store.indexOf(v) == i;
                        });
                        $scope.important = [];
                        $scope.strg = store;
                        for (var imp in second) {
                            if (second[imp] == 1) {
                                $scope.important.push("Gmail")
                            }
                            else if (second[imp] == 2) {
                                $scope.important.push("Yahoo")
                            }
                            else if (second[imp] == 3) {
                                $scope.important.push("Hotmail")
                            }
                        }


                    }
                    else if (typeof response.data.error != 'undefined') {
                        alert(response.data.error);

                    }
                }

            }
            , function errorCallback(response) {
                alert('deletenewsleter' + JSON.stringify(response));
            });
    }
    $scope.singleDomain();


    $scope.getDidDetails = function () {
        // alert($scope.IpId);
        var date = new Date();
        if ($scope.startOn) {
            var d1 = new Date($scope.startOn);
        }else{
            $scope.startOn = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate();
            var d1 = new Date($scope.startOn);
        }
        if ($scope.endOn) {
            var d2 = new Date($scope.endOn);
        }else{
            $scope.endOn = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate();
            var d2 = new Date($scope.endOn);

        }

        var date1 = d1.setHours(0, 0, 0, 0);
        var from = date1 / 1000;
        var date2 = d2.setHours(0, 0, 0, 0);
        var to = date2 / 1000;
        $scope.HealthScore = [];
        $scope.RepScore = [];
        $scope.opens = [];
        $scope.clicks = [];
        $scope.delivered = [];
        $scope.currentPush = [];
        $scope.Spam = [];
        $scope.Bounce = [];
        $scope.Defer = [];
        $scope.Volume = [];
        $scope.DATE = [];
        $scope.unSubs = [];

        if ($scope.IpId != 'undefined') {
            var graphData = {
                "from": from,
                "to": to,
                "did": domainId,
                "IpId": $scope.IpId,
                "espId": $scope.selectedesp
            };
        } else if ($scope.IpId == 'undefined') {
            var graphData = {
                "from": from,
                "to": to,
                "did": domainId,
                "espId": $scope.selectedesp
            };
        }
        if(graphData.espId!=undefined) {
            if(graphData.from<=graphData.to) {
                $http({
                    method: 'POST',
                    url: 'users/startEND/',
                    data: {"withIp": graphData}

                }).then(function successCallback(response) {

                        if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                            window.location.href = "./";
                        } else {
                            if (typeof response.data.success != 'undefined') {
                                var myStringS = response.data.success;
                                if(myStringS.length==0){
                                    $scope.noGraphFun();
                                }
                                // alert(JSON.stringify(myStringS));
                                for (var a in myStringS) {
                                    $scope.defer_data = 0;
                                    for (var aa in myStringS[a].defer) {
                                        $scope.defer_data = $scope.defer_data + myStringS[a].defer[aa];
                                    }
                                    $scope.Defer.push($scope.defer_data);
                                }
                                for (var b in myStringS) {
                                    $scope.bounce_data = 0;
                                    for (var bb in myStringS[b].bounce) {
                                        $scope.bounce_data = $scope.bounce_data + myStringS[b].bounce[bb];
                                    }
                                    $scope.Bounce.push($scope.bounce_data);
                                }
                                // $scope.DATE.push('');
                                for (var HScore=0; HScore<myStringS.length;HScore++) {
                                    if (typeof myStringS[HScore].HS != 'undefined' || typeof myStringS[HScore].open != 'undefined' || typeof myStringS[HScore].click != 'undefined' ||
                                        typeof myStringS[HScore].dlvrd != 'undefined' || typeof myStringS[HScore].RS != 'undefined' || typeof myStringS[HScore].spam != 'undefined' ||
                                        typeof myStringS[HScore].CP != 'undefined' || typeof myStringS[HScore].vol != 'undefined' || typeof myStringS[HScore].unSub != 'undefined') {
                                        $scope.HealthScore.push(myStringS[HScore].HS);
                                        $scope.opens.push(myStringS[HScore].open);
                                        $scope.clicks.push(myStringS[HScore].click);
                                        $scope.delivered.push(myStringS[HScore].dlvrd);
                                        $scope.RepScore.push(myStringS[HScore].RS);
                                        $scope.Spam.push(myStringS[HScore].spam);
                                        $scope.currentPush.push(myStringS[HScore].CP);
                                        $scope.Volume.push(myStringS[HScore].vol);

                                        $scope.unSubs.push(myStringS[HScore].unSub);
                                        var dd = $filter('date')((myStringS[HScore].date) * 1000, 'yyyy-MM-dd');
                                        $scope.DATE.push(dd);

                                        // $scope.Defer.push(0);
                                    }
                                    else {

                                        $scope.HealthScore.push(0);
                                        $scope.opens.push(0);
                                        $scope.clicks.push(0);
                                        $scope.delivered.push(0);
                                        $scope.RepScore.push(0);
                                        $scope.Spam.push(0);
                                        $scope.currentPush.push(0);
                                        $scope.Volume.push(0);
                                        $scope.unSubs.push(0);


                                    }

                                }
                                if(myStringS.length!=0){
                                    if(typeof $scope.activefun=='undefined'||typeof $scope.activefun1=='undefined'||typeof $scope.activefun2=='undefined'||
                                        typeof $scope.activefun3=='undefined'||typeof $scope.activefun4=='undefined'){
                                        $scope.health($scope.HealthScore, $scope.RepScore, $scope.DATE);
                                    }else{
                                        if($scope.activefun=='active'){

                                            $scope.health($scope.HealthScore, $scope.RepScore, $scope.DATE);
                                        }else  if($scope.activefun1=='active'){
                                            $scope.volume($scope.Volume);
                                        }else  if($scope.activefun2=='active'){
                                            $scope.push($scope.currentPush)
                                        }else  if($scope.activefun3=='active'){

                                            $scope.reports($scope.opens,$scope.clicks,$scope.delivered,$scope.unSubs,$scope.Spam);
                                        }else  if( $scope.activefun4=='active'){
                                            $scope.error_codes();
                                        }
                                    }

                                }

                            }
                            else if (typeof response.data.error != 'undefined') {
                                alert(response.data.error);
                            }
                        }
                    }
                    , function errorCallback(response) {
                        alert('deletenewsleter' + JSON.stringify(response));
                    });
            }else{

                alert("startingDate must be lessthan endingDate");
            }
        }
        else{
            alert("You should select Esp");
        }
    }
}]);

sampleApp.controller('domaincontroller', function ($filter, $window, socket, $scope, $cookies, $cookieStore, $http, $routeParams) {


    var domainID = $routeParams.domainId;
    $http({
        method: 'POST',
        url: '/users/domainName/'
    }).then(function successCallback(response) {

            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {

                if (typeof response.data.success != 'undefined') {


                    var myString = response.data.success;
                    $scope.ALLDOMAINS = myString;

                    for (var name in $scope.ALLDOMAINS) {
                        if (JSON.stringify($scope.ALLDOMAINS[name].id) == domainID) {
                            $scope.RESULT = $scope.ALLDOMAINS[name];
                        }

                    }

                }
                else if (typeof response.data.error != 'undefined') {
                    alert(response.data.error);
                }
            }
        }
        , function errorCallback(response) {
            alert('deletenewsleter' + JSON.stringify(response));
        });

});

sampleApp.controller('draftsCtrl', ['$rootScope','$filter','$window','socket','$scope', '$cookies', '$cookieStore', '$http', function ($rootScope,$filter,$window,socket,$scope, $cookies, $cookieStore, $http)
{

    $scope.iconClick = function () {
        var element = document.getElementById("datePicker1");
        element.focus();
    }



    $scope.typeColor = {open:'fa rate-icon blue-1',click:'fa rate-icon green-1',lead:'fa rate-icon orrange-1',push:'fa rate-icon pink-1'};
    $scope.startOn = $filter('date')(new Date(), 'yyyy-MM-dd');
    //alert("outer campaign ");
    $scope.sortByVar = '-ctdOn';

    if(typeof $rootScope.campDate != 'undefined'){
        $scope.startOn = $filter('date')($rootScope.campDate*1000, 'yyyy-MM-dd');
        $rootScope.campDate=new Date()/1000;
    }

    $scope.changeFilter = function(type)
    {
        $scope.sortByVar = type;
    }

    $scope.filterSort = [{type:'title',show:'Sort by NewsletterTitle'},
        {type:'createdBy',show:'Sort by CreatedBy'}];


    var loginId = $cookieStore.get("userid");
    $scope.loginId = loginId;
    $scope.preload = true;
    $scope.campaigns = [];
    $scope.pickedvolumes = [];
    $scope.selected = -1;
    $scope.viewing = null;
    $scope.subjects = [];
    $scope.senders = [];
    $scope.volume = 0;


    function calculateCamp(campaigns)
    {

        var tempCamp = [];
        var pushCamp = [];

        for (var j=0;j<campaigns.length;j++)
        {
            var i = 0;
            pushCamp=[];
            //alert("j in "+$scope.campNames[j]);
            while(i<campaigns.length)
            {
                if(campaigns[j].title==$scope.campNames[i])
                {
                    tempCamp.push({title:campaigns[j].title,ctdOn:campaigns[j].ctdOn,campId:campaigns[j].campId,
                        createdBy:campaigns[j].userRel.name,cBy:campaigns[j].cBy})
                }
                i++;
            }


        }


        $scope.resultCamp = tempCamp;

    }

    $scope.getCampaigns = function()
    {
        //alert("getCampaigns called");
        $scope.campaigns=[];
        var date = new Date($scope.startOn);
        var date2Day = date.setHours(0, 0, 0,0)/1000;
        var draftObj = {"where":{"cType":"direct","ctdOn":date2Day}}
        console.log(JSON.stringify(draftObj)+"  draftObj");
        $http({
            method: 'POST',
            url: 'users/getCampaigns',
            data:{draftObj:draftObj}
        }).then(function successCallback(response) {
            //console.log("response : ",response);
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {
                $scope.preload = false;
                $scope.campNames=[];
                //console.log("getCampaigns  res  :  ",JSON.stringify(response.data))
                $scope.campaigns=response.data;

                //console.log("length  :  "+response.data.length);
                $scope.campIn=[[]];
                for(var i=0;i<response.data.length;i++)
                {

                    var campId = response.data[i].campId;
                    var ctdOn = response.data[i].ctdOn;
                    var newsLetter = response.data[i].title;

                    $http({
                        method: 'POST',
                        url: 'users/getStep1/'+campId
                    }).then(function successCallback(response) {
                            // console.log("response : ",response);
                            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1)
                            {
                                window.location.href = "./";

                            } else
                            {
                                // console.log("response in getCamapaings campaign :  "+JSON.stringify(response.data));
                                $scope.campNames.push(response.data.name);
                            }
                        }
                        , function errorCallback(response) {
                            alert('getCampaigns' + JSON.stringify(response));
                        });
                }
                calculateCamp($scope.campaigns);
            }
        }, function errorCallback(response) {
            alert('getCampaigns' + JSON.stringify(response));
        });

    }

    $scope.getCampaigns();


    $scope.deleteNewsletter = function (id) {

        $http({
            method: 'POST',
            url: 'users/deleteNewsletter/',
            data:{newsId : id}
        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {

                    if(typeof response.data.success != 'undefined'){
                        alert(response.data.success);
                        window.location.href = "#users/drafts";
                    }
                    else if(typeof response.data.error != 'undefined')
                    {
                        alert(response.data.error);
                        window.location.href = "#users/drafts";
                    }
                }
            }
            , function errorCallback(response) {
                alert('deletenewsleter' + JSON.stringify(response));
            });


    }


}]);



sampleApp.controller('outer-campaigns-controller', ['campaignData0','$rootScope','$filter','$window','socket','$scope', '$cookies', '$cookieStore', '$http', function (campaignData0,$rootScope,$filter,$window,socket,$scope, $cookies, $cookieStore, $http)
{


    $scope.iconClick = function () {
        var element = document.getElementById("datePicker1");
        element.focus();
    }


    $scope.viewNlCampaign = function(campId)
    {
        var date = new Date($scope.startOn);
        var date2Day = date.setHours(0, 0, 0,0);
        var currentDate = (new Date()).setHours(0, 0, 0,0);

        if(currentDate==date2Day){
            campaignData0.setShow(true)
        }
        else{
            campaignData0.setShow(false)
        }
        campaignData0.setDate($scope.startOn);
        campaignData0.setCampId(campId);
        window.location.href = "#users/innerCampaigns";
    }

    $scope.typeColor = {open:'fa rate-icon blue-1',click:'fa rate-icon green-1',lead:'fa rate-icon orrange-1',push:'fa rate-icon pink-1'};
    $scope.startOn = $filter('date')(new Date(), 'yyyy-MM-dd');
    //alert("outer campaign ");
    $scope.sortByVar = '-ctdOn';

    /*if(typeof $rootScope.campDate != 'undefined'){
     $scope.startOn = $filter('date')($rootScope.campDate*1000, 'yyyy-MM-dd');
     $rootScope.campDate=new Date()/1000;
     }*/

    $scope.changeFilter = function(type)
    {
        $scope.sortByVar = type;
    }

    $scope.filterSort = [{type:'title',show:'Sort by NewsletterTitle'},
        {type:'createdBy',show:'Sort by CreatedBy'}];


    var loginId = $cookieStore.get("userid");
    $scope.loginId = loginId;
    $scope.preload = true;
    $scope.campaigns = [];
    $scope.pickedvolumes = [];
    $scope.selected = -1;
    $scope.viewing = null;
    $scope.subjects = [];
    $scope.senders = [];
    $scope.volume = 0;

    $scope.vol = 0;

    $scope.disableAdding = true;


    function calculateCamp(campaigns)
    {
        //alert("calculateCamp "+campaigns.length);
        var campIds = [];
        var tempCamp = [];
        var pushCamp = [];
        var temp='';
        for (var j=0;j<campaigns.length;j++)
        {
            var i = 0;
            pushCamp=[];
            var count=0;
            campIds.push(campaigns[j].campId);
            while(i<campaigns.length)
            {

                // alert("campaigns  :   "+JSON.stringify(campaigns))
                if(campaigns[j].campId==campaigns[i].campId && campaigns[j].ctdOn == campaigns[i].ctdOn)
                {
                    count++;

                    pushCamp.push(campaigns[j]);
                    if(count>1){
                        tempCamp[tempCamp.length-1].count=count;
                    }
                    else{
                        tempCamp.push({count:count,title:campaigns[j].title,ctdOn:campaigns[j].ctdOn,campId:campaigns[j].campId,
                            createdBy:campaigns[j].userRel.name,cBy:campaigns[j].cBy})

                    }

                }
                i++;
            }

        }


        $scope.resultCamp = tempCamp;

    }



    $scope.getNlmByDt = function (dt) {

        //alert("dt  : "+dt);
        var date = new Date(dt);
        var date2Day = date.setHours(0,0,0,0);
        var id = $cookieStore.get("userid");

        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {
            $scope.preload = true;
            $scope.resultCamp=[];
            $scope.campaigns=[];
            var obj={"where":{"ctdOn":date2Day/1000,"or":[{"status":-1},{"status":-2},{"status":1}],"cType":"direct"}};
            $http({
                method: 'POST',
                url: 'users/getNlmByDt',
                data:{url:"api/nlm/query?filter="+JSON.stringify(obj)}
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1)
                {
                    window.location.href = "./";
                } else
                {
                    $scope.campaigns = response.data;
                    $scope.aggCamp = [];
                    //console.log("$scope.campaigns  getNlmByDt : "+JSON.stringify($scope.campaigns));
                    $scope.preload = false;
                    //console.log('check');
                    calculateCamp($scope.campaigns);

                }
            }, function errorCallback(response) {
                //alert('error' + response);
                console.log(response);
            });

        }

    }

    if(campaignData0.getDate()!='' && campaignData0.getBack() !='')
    {
        if(campaignData0.getBack()){
            $scope.startOn = $filter('date')(new Date(campaignData0.getDate()), 'yyyy-MM-dd');
            $scope.getNlmByDt(campaignData0.getDate());
            campaignData0.setBack(false);
        }
        else
        {
            $scope.getNlmByDt($scope.startOn);
        }
    }
    else
    {
        $scope.getNlmByDt($scope.startOn);
    }



    /*$scope.loadToday = function () {

     var id = $cookieStore.get("userid");
     if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
     window.location.href = "./";
     } else {
     var obj={"where":{"cBy": id}};
     $http({
     method: 'POST',
     url: 'users/getInnerCampaigns',
     data:{url:"api/nlm"}
     }).then(function successCallback(response) {
     if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1)
     {
     window.location.href = "./";
     } else
     {
     $scope.campaigns = response.data;
     $scope.aggCamp = [];
     //console.log("$scope.campaigns  : "+JSON.stringify($scope.campaigns));
     $scope.preload = false;
     console.log('check');
     calculateCamp($scope.campaigns);

     }
     }, function errorCallback(response) {
     //alert('error' + response);
     console.log(response);
     });

     }

     }*/


    $scope.selecteddvol=0;
    $scope.selectedpvol=0;
    // $scope.loadToday();

    $scope.getUserDomain = function(){

        $http({
            method: 'POST',
            url: 'users/getUserDomain'
        }).then(function successCallback(response) {
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {

                var obj=response.data;
                $scope.userDomains=obj.data;
                //console.log("getUserDomain:   ",$scope.userDomains);
                if($scope.userDomains == '' || $scope.userDomains == null)
                {
                    alert("No Domains alloted to you please contact admin");
                    $("#myModal").modal('hide');
                }
                else {
                    $("#myModal").modal('show');
                }
            }

        }, function errorCallback(response) {
            console.log('error');
            console.log(response);
        });

    }


    $scope.addToMineShow = function (x, dvol, pvol) {

        //$("#myModal").modal('hide');

        $scope.remaining = dvol - pvol;
        //alert(pvol+" and remaining is  :  "+$scope.remaining);
        if($scope.remaining<=0){
            alert("No remaining vol to sent campaign");
            //$("#myModal").modal('hide');
        }else{

            console.log(dvol);
            console.log(pvol);
            $scope.selecteddvol=dvol;
            $scope.selectedpvol=pvol;
            console.log(dvol - pvol);
            $scope.selected = parseInt(x);

            if (!isNaN($scope.remaining) && $scope.remaining > 0) {
                $scope.disableAdding = false;
            } else {
                console.log('cannot enable add button');
            }
        }

        $scope.getUserDomain();
    };

    $scope.addToMineClose = function () {
        $scope.disableAdding = false;
        $scope.selected = -1;
        /* $scope.volume = 0;
         $scope.selecteddvol=0;
         $scope.selectedpvol=0;*/
    };

    $scope.addToMine = function (vol, campid) {

        var id = $cookieStore.get("userid");
        //alert("addToMine userid  "+id);
        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {
            var obj = {
                "userId": parseInt(id),
                "nlmId": parseInt($scope.selected),
                'pickVol': parseInt($scope.volume)
            }
            //console.log(obj);
            $http({
                method: 'POST',
                url: 'users/allotToMe',
                data: obj
            }).then(function successCallback(response) {
                //console.log(response);
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    $scope.volume = 0;
                    if (response.data.error) {
                        //console.log(response.data.error)
                        alert(response.data.error);
                    } else if (response.data.success) {
                        //console.log(response.data.success)
                        alert("Campaign added Successfully");
                        $scope.loadToday();
                    } else {

                    }
                }
            },function errorCallback(response) {
                window.location.href = "./";
                /*alert('error1' + response);*/
            });
        }
    };

    $scope.updateNewsLetter = function(camp)
    {
        var obj = {cBy:loginId,newsId:camp.id,dVol:camp.altPush};
        console.log("obj : "+obj);
        alert(JSON.stringify(obj));
        $http({

            method:'POST',
            url : '/users/updateNews',
            data:obj
        }).then(function successCallBack(res) {

                //alert("res   :  "+JSON.stringify(res));
                if(res.data.statusCode == 200){

                    alert("Campaign Started Successfully");
                    $window.location = "#/users/campaigns"
                }
                else {
                    alert("something went wrong");
                }

            },
            function errorCallBack(res){
                alert("error updateNEws");
                console.log(res.data);
            })
    }


}]);




sampleApp.controller('inner-campaigns-controller', ['innerCampEdit0','campaignData0','$rootScope','$routeParams','$window','socket','$scope', '$cookies', '$cookieStore', '$http', function (innerCampEdit0,campaignData0,$rootScope,$routeParams,$window,socket,$scope, $cookies, $cookieStore, $http) {

    //alert("inner campaigns");
    $scope.typeColor = {open:'fa rate-icon blue-1',click:'fa rate-icon green-1',lead:'fa rate-icon orrange-1',push:'fa rate-icon pink-1'};


    var reportId = campaignData0.getCampId();
    var d1 = new Date(campaignData0.getDate());
    $scope.todaysDate=campaignData0.getShow();
    var date1 = d1.setHours(0, 0, 0,0);
    var newDate =  date1/ 1000;
    var ctdOn = newDate;

    // alert("$rootScope.campId  :  "+reportId);

    var loginId = $cookieStore.get("userid");


    $scope.preload = true;
    $scope.campaigns = [];
    $scope.pickedvolumes = [];
    $scope.selected = -1;
    $scope.viewing = null;
    $scope.subjects = [];
    $scope.senders = [];
    $scope.volume = 0;
    $scope.vol = 0;

    $scope.disableAdding = true;



    $scope.editInnerCamp = function(camp)
    {
        innerCampEdit0.setNlmId(camp.id);
        innerCampEdit0.setUserId(camp.userRel.id);
        window.location.href = "#/users/innerCamp";
    }

    $scope.backFunction = function()
    {
        campaignData0.setBack(true);
        window.location.href = "#/users/campaigns";
    }


    $scope.loadToday = function () {

        var id = $cookieStore.get("userid");
        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {
            var obj = {"where":{ "campId":reportId,"ctdOn":ctdOn }};
            console.log("obj loadToday : "+JSON.stringify(obj));
            $http({
                method: 'POST',
                url: 'users/getInnerCampaigns',
                data:{url:"api/nlm/query?filter="+JSON.stringify(obj)}
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1)
                {
                    window.location.href = "./";
                } else
                {
                    $scope.campaigns = response.data;
                    //console.log("$scope.campaigns  : "+JSON.stringify($scope.campaigns));
                    $scope.preload = false;
                    //console.log('check');
                    //console.log($scope.pickedvolumes);
                    // console.log('check');
                    for (cmp in $scope.campaigns) {
                        // alert($scope.campaigns[cmp].id);
                        var idstring=''+$scope.campaigns[cmp].id;
                        if ($scope.pickedvolumes[idstring] == undefined || $scope.pickedvolumes[idstring] == null) {
                            $scope.pickedvolumes[$scope.campaigns[cmp].id] = 0;
                        }
                        /*if ($scope.pickedvolumes[cmp.id] == undefined || $scope.pickedvolumes[cmp.id] == null) {
                         $scope.pickedvolumes[$scope.campaigns[cmp].id] = 0;
                         }*/
                    }
                    //console.log($scope.pickedvolumes);
                    //console.log('check');
                }

            }, function errorCallback(response) {
                //alert('error' + response);
                console.log(response);
            });
        }
    }

    $scope.selecteddvol=0;
    $scope.selectedpvol=0;
    $scope.loadToday();
    $scope.getUserDomain = function(){

        $http({
            method: 'POST',
            url: 'users/getUserDomain'
        }).then(function successCallback(response) {
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {

                var obj=response.data;
                $scope.userDomains=obj.data;
                //console.log("getUserDomain:   ",$scope.userDomains);
                if($scope.userDomains == '' || $scope.userDomains == null)
                {
                    alert("No Domains alloted to you please contact admin");
                    $("#myModal").modal('hide');
                }
                else {
                    $("#myModal").modal('show');
                }
            }

        }, function errorCallback(response) {
            console.log('error');
            console.log(response);
        });

    }





    $scope.addToMineShow = function (x, dvol, pvol) {

        //$("#myModal").modal('hide');

        $scope.remaining = dvol - pvol;
        //alert(pvol+" and remaining is  :  "+$scope.remaining);
        if($scope.remaining<=0){

            alert("No remaining vol to sent campaign");
            //$("#myModal").modal('hide');

        }else{

            console.log(dvol);
            console.log(pvol);
            $scope.selecteddvol=dvol;
            $scope.selectedpvol=pvol;
            console.log(dvol - pvol);
            $scope.selected = parseInt(x);

            if (!isNaN($scope.remaining) && $scope.remaining > 0) {
                $scope.disableAdding = false;
            } else {
                console.log('cannot enable add button');
            }
        }

        $scope.getUserDomain();
    };
    $scope.addToMineClose = function () {
        $scope.disableAdding = false;
        $scope.selected = -1;
        /* $scope.volume = 0;
         $scope.selecteddvol=0;
         $scope.selectedpvol=0;*/
    };
    $scope.addToMine = function (vol, campid) {

        var id = $cookieStore.get("userid");
        //alert("addToMine userid  "+id);
        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {
            var obj = {
                "userId": parseInt(id),
                "nlmId": parseInt($scope.selected),
                'pickVol': parseInt($scope.volume)
            }
            console.log(obj);
            $http({
                method: 'POST',
                url: 'users/allotToMe',
                data: obj
            }).then(function successCallback(response) {
                console.log(response);
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    $scope.volume = 0;
                    if (response.data.error) {
                        console.log(response.data.error)
                        alert(response.data.error);
                    } else if (response.data.success) {
                        console.log(response.data.success)
                        alert("Campaign added Successfully");
                        $scope.loadToday();
                    } else {
                    }
                }
            }, function errorCallback(response) {
                window.location.href = "./";
                /*   alert('error1' + response);*/
            });
        }


    };

    $scope.updateNewsLetter = function(camp)
    {

        if(parseInt(camp.altPush) != 0){

            var obj = {cBy:loginId,newsId:camp.id,dVol:camp.altPush};
            console.log("obj : "+obj);
            //alert(JSON.stringify(obj));
            $http({

                method:'POST',
                url : '/users/updateNews',
                data:obj
            }).then(function successCallBack(res) {

                    //alert("res   :  "+JSON.stringify(res));
                    if(res.data.statusCode == 200){

                        alert("Campaign Started Successfully");
                        $window.location = "#/users/campaigns"
                    }
                    else {
                        alert("something went wrong");
                    }

                },
                function errorCallBack(res){
                    alert("error updateNEws");
                    console.log(res.data);
                })
        }
        else {
            alert("No Data Found");
        }

    }

}])
;




sampleApp.controller('viewdomain-controller', ['$scope', '$cookies', '$cookieStore', '$http', function ($scope, $cookies, $cookieStore, $http) {



    $http({

        method:'POST',
        url:'/users/getDomain/'

    }).then(
        function successCallBack(res){

            var obj = res.data;
            var data = obj.data;
            //console.log("data  :",data);
            //console.log("obj  :",JSON.stringify(obj));
            $scope.domainDetail = obj;
            /*$scope.domainName = obj.name;
             $scope.imageUrl = obj.imgUrl;
             $scope.trackUrl = obj.trackUrl;
             $scope.mesgId = obj.mesgId;*/
            console.log("domain start");

        },
        function errorCallBack(res){
            console.log("error domain");
        }
    );


    $scope.createIf=false;
    $scope.alertIf = function()
    {
        $scope.createIf=true;
    }
    $scope.createDomain = function(domain)
    {
        var id = $cookieStore.get("userid");
        var obj ={
            "name": domain.name,
            "imgUrl": domain.imgUrl,
            "trackUrl": domain.trackUrl,
            "capacity": domain.capacity,
            "curPush": domain.curPush,
            "msgId":domain.msgId,
            "cBy":id
        }
        console.log("create obj  :  ",obj);
        $http({

            method:'POST',
            url:'/users/createDomain/',
            data:obj
        }).then(
            function successCallBack(res){

                var obj = res.data;
                var data = obj.data;
                //console.log("data  :",data);
                //console.log("obj  :",JSON.stringify(obj));
                /*$scope.domainName = obj.name;
                 $scope.imageUrl = obj.imgUrl;
                 $scope.trackUrl = obj.trackUrl;
                 $scope.mesgId = obj.mesgId;*/
                console.log("domain start");
                $scope.createIf=false;

            },
            function errorCallBack(res){

                console.log("error domain");

            }
        );


    }

    $scope.showDomain = function(domain)
    {
        $scope.domain=domain;
    }

    $scope.updateDomain = function(domain)
    {
        var id = $cookieStore.get("userid");
        console.log(domain);
        var obj ={
            "id":domain.id,
            "name": domain.name,
            "imgUrl": domain.imgUrl,
            "trackUrl": domain.trackUrl,
            "capacity": domain.capacity,
            "curPush": domain.curPush,
            "msgId":domain.msgId,
            "status":domain.status,
            "cBy":id
        }

        //console.log("create obj  :  ",obj);
        $http({

            method:'POST',
            url:'/users/editDomain/',
            data:obj
        }).then(
            function successCallBack(res){

                var obj = res.data;
                var data = obj.data;
                console.log("data  :",data);
                console.log("obj  :",JSON.stringify(obj));
                /*$scope.domainName = obj.name;
                 $scope.imageUrl = obj.imgUrl;
                 $scope.trackUrl = obj.trackUrl;
                 $scope.mesgId = obj.mesgId;*/
                console.log("domain start");
                $scope.createIf=false;
            },
            function errorCallBack(res){

                console.log("error domain");
            }
        );


    }




}]);

sampleApp.controller('viewusers-controller', ['$scope', '$cookies', '$cookieStore', '$http', function ($scope, $cookies, $cookieStore, $http) {

    $scope.defaultnames = ["--Loading--"];
    $scope.mainPermissionNames = [];
    $scope.defaultmenu = $scope.defaultnames[0];
    $http({
        method: 'POST',
        url: 'users/getMainPermissions',
    }).then(function successCallback(response) {
        if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
            window.location.href = "./";
        } else {
            //console.log(response.data);
            $scope.defaultnames = response.data[0];
            //console.log($scope.users)
            $scope.mainPermissionNames = response.data[1];
            $scope.defaultmenu = $scope.defaultnames[0];
        }

    }, function errorCallback(response) {
        console.log(response);
        alert('error123');
        console.log('respons123')

    });

    $scope.users = [];
    $scope.selected = 0;
    $scope.selectedUser = null;
    $scope.isEditing = false;
    $scope.usersCopy = null;
    $scope.editingUser = null;
    $scope.editObj = {
        id: -1,
        name: '',
        email: '',
        pwd: '',
        status: -1,
        maincount: 0
    }
    $scope.showAdduser = 0;
    $scope.name = '';
    $scope.mailid = '';
    $scope.password = '';

    $scope.loadUsers = function () {
        var id = $cookieStore.get("userid");

        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {
            $http({
                method: 'POST',
                url: 'users/getUsers',
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (response.data.error) {
                        console.log(response.data.error);
                        alert(response.data.error);
                    } else if (response.data.success) {
                        //console.log(response.data.success)
                        $scope.users = response.data.success;
                        //console.log($scope.users);
                        $scope.usersCopy = $scope.users;
                    } else {
                        alert('Error :')
                    }

                }

            }, function errorCallback(response) {
                alert('error');
                console.log(response);
            });
        }
    }
    $scope.loadUsers();
    $scope.default = 1;
    $scope.showSub = 0;
    $scope.allottingUser = -1;
    $scope.mainpermissions = [];
    $scope.subpermissions = [];
    $scope.subpermissions = [];
    $scope.tasks = [];

    $scope.taskselection = [];
    $scope.subselection = [];
    $scope.mainselection = [];
    $scope.permissionNames = [];
    $scope.mainids = [];
    $scope.subids = [];
    $scope.mainselectednames = "";


    /*  $scope.$watch('subpermissions|filter:{selected:true}', function (nv) {
     $scope.subselection = nv.map(function (permission) {
     return permission.name;
     });
     }, true);
     */
    $scope.main_sub = {};
    $scope.sub_task = {};

    $scope.changed = function (x, y) {
        //alert(x);
        if (x == true) {
            $http({
                method: 'POST',
                url: 'users/getSubPermissions',
                data: {
                    'mainId': parseInt($scope.permissionNames[y])
                }
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    //console.log(response.data)
                    if (response.data.error) {
                        console.log(response.data.error)
                        alert(response.data.error);
                    } else if (response.data.success) {
                        //console.log(response)
                        //console.log(response.data.success);
                        if (response.data.success.length > 1) {
                            $scope.subpermissions = response.data.success[0];
                            //console.log('check here');
                            //console.log($scope.permissionNames);
                            //console.log();
                            for (var attrname in response.data.success[1]) {
                                $scope.permissionNames [attrname] = response.data.success[1][attrname];
                            }
                            $scope.mainselection.push(y);
                            $scope.main_sub[y] = $scope.subpermissions;
                        }
                        else {
                            alert('failed to load main permissons')
                        }
                    } else {

                    }
                }
            }, function errorCallback(response) {
                alert('error');
                alert('error');
            });

        } else {
            console.log($scope.main_sub[y])
            //alert(y)
            //console.log($scope.sub_task);
            for (var ii in $scope.main_sub[y]) {
                //alert($scope.main_sub[y][ii].name);
                //$scope.subselection.splice($scope.subselection.indexOf($scope.main_sub[y][ii].name), 1);
                delete $scope.sub_task[$scope.main_sub[y][ii].name];
            }
            $scope.mainselection.splice($scope.mainselection.indexOf(y), 1);
            delete $scope.main_sub[y];
        }
    };

    $scope.changedTask = function (x, y) {
        if (x == 1) {
            $scope.taskselection.push(y);
        } else {
            $scope.taskselection.splice($scope.taskselection.indexOf(y), 1);
        }
    }

    $scope.changedSub = function (x, y) {

        if (x == 1) {
            $http({
                method: 'POST',
                url: 'users/getTasks',
                data: {
                    'subId': parseInt($scope.permissionNames[y])
                }
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    //console.log(response.data)
                    if (response.data.error) {
                        console.log(response.data.error)
                        alert(response.data.error);
                    } else if (response.data.success) {
                        //console.log(response)
                        //console.log(response.data.success);
                        if (response.data.success.length > 1) {
                            $scope.tasks = response.data.success[0];
                            //console.log('check here');
                            //console.log($scope.permissionNames);
                            console.log();
                            for (var attrname in response.data.success[1]) {
                                $scope.permissionNames [attrname] = response.data.success[1][attrname];
                            }
                            $scope.subselection.push(y);
                            $scope.sub_task[y] = $scope.tasks;
                        }
                        else {
                            alert('failed to load main permissons')
                        }
                    } else {

                    }
                }
            }, function errorCallback(response) {
                alert('error');
            });

        } else {
            $scope.subselection.splice($scope.subselection.indexOf(y), 1);
            delete $scope.sub_task[y];
        }
    };
    $scope.$watch('mainpermissions|filter:{selected:true}', function (nv) {
        $scope.mainselection = nv.map(function (permission) {
            /*if ($scope.mainselectednames.indexOf(permission.name) > -1) {

             console.log('here will call for---- :: ' + permission.name)
             } else {
             //alert('here will call for :: ' + permission.name)
             console.log('here will call for :: ' + permission.name)
             $scope.mainselectednames += permission.name + ",";
             }*/
            return permission.name;
        });
    }, true);



    $scope.allot = function (x) {
        $scope.allottingUser = x;
        $scope.showAdduser = 0;
        $scope.isEditing = false;
        $scope.selectedUser = null;

        var id = $cookieStore.get("userid");
        console.log('cookie ::: ' + id)
        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {
            /*if ($scope.mainpermissions.length === 0 || $scope.subpermissions.length == 0) {*/
            $http({
                method: 'POST',
                url: 'users/getPermissions',
                data: {
                    'id': $scope.allottingUser
                }
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (response.data.error) {
                        console.log(response.data.error)
                        //alert(response.data.error);
                        if(response.data.error="The user has no assigned Main Features")
                        {
                            $http({
                                method: 'POST',
                                url: 'users/getPermissions',
                                data: {
                                    'id': id
                                }
                            }).then(function successCallback(response) {
                                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                                    window.location.href = "./";
                                } else {
                                    if (response.data.error) {}
                                    else if(response.data.success){
                                        // console.log(response);
                                        //console.log(response.data.success);
                                        $scope.mainpermissions = response.data.success[0];
                                        $scope.permissionNames = response.data.success[1];
                                        //console.log(response.data[2]);
                                    }
                                }})

                        }
                    } else if (response.data.success) {
                        //console.log("response success");
                        // console.log(response);
                        //console.log(response.data.success);
                        $scope.mainpermissions = response.data.success[0];
                        $scope.permissionNames = response.data.success[1];
                        //$scope.permissionNames = response.data[2];
                        /*console.log($scope.mainpermissions);
                         console.log($scope.subpermissions);*/
                        // console.log(response.data[2]);
                    }
                }
            }, function errorCallback(response) {
                //alert('error');
            });
            /* } else {
             console.log('not loading permissions as already loaded')
             }*/

        }

        $http({
            method: 'POST',
            url: 'users/getDomain'
        }).then(function successCallback(response) {
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {
                $scope.domainResponse=response.data;
                console.log("getDomain:   ",response.data);
            }

        }, function errorCallback(response) {
            //alert('error');
            console.log(response);
        });


        //getDomain using userId
        $scope.getUserDomain();


    }
    $scope.getUserDomain = function(){

        $http({
            method: 'POST',
            url: 'users/getUserDomain',
            data: {
                "userId": $scope.allottingUser
            }
        }).then(function successCallback(response) {
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {
                var obj=response.data;
                $scope.userDomains=obj.data;
                //console.log("getUserDomain:   ",$scope.userDomains);
            }

        }, function errorCallback(response) {
            console.log('error');
            console.log(response);
        });
    }

    $scope.allotUpdate = function () {

        console.log('allotting');
        $scope.mainids = [];
        $scope.subids = [];
        for (i = 0; i < $scope.mainselection.length; i++) {
            $scope.mainids.push($scope.permissionNames[$scope.mainselection[i]]);
        }
        for (i = 0; i < $scope.subselection.length; i++) {
            $scope.subids.push($scope.permissionNames[$scope.subselection[i]]);
        }
        //console.log($scope.mainids);
        //console.log($scope.subids);

        var obj = {
            "id": $scope.allottingUser,
            "main": $scope.mainids,
            "subTask": $scope.subids,
        }
        console.log(obj);
        $http({
            method: 'POST',
            url: 'users/updateUser',
            data: obj,
        }).then(function successCallback(response) {
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {
                console.log(response.data)
            }
        });
    }

    $scope.assignDomain=function () {

        //console.log("$scope.allottingUser   :"+$scope.allottingUser);
        //console.log("domainOpt     "+JSON.stringify($scope.domainOpt));

        $http({
            method: 'POST',
            url: 'users/postDomain',
            data: {"domainOpt":$scope.domainOpt,"userId":$scope.allottingUser}
        }).then(function successCallback(response) {
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {
                //console.log(response.data);
                $scope.getUserDomain();
            }
        }, function errorCallback(response) {
            alert('error');
            console.log(response);
        });



    }

    $scope.editUser = function (x) {
        $scope.allottingUser = -1;
        for (u in $scope.usersCopy) {
            if ($scope.usersCopy[u].id == x) {
                $scope.editingUser = $scope.usersCopy[u];
                $scope.editObj.id = parseInt($scope.editingUser.id);
                $scope.editObj.name = $scope.editingUser.name;
                $scope.editObj.email = $scope.editingUser.email;
                $scope.editObj.status = $scope.editingUser.status;
                $scope.editObj.pwd = $scope.editingUser.noHash;
                $scope.selectedUser = null;
                $scope.showAdduser = 0
                console.log($scope.editObj);

            }
        }
        console.log($scope.editingUser);
        $scope.isEditing = true;

    };
    $scope.editUpdate = function () {
        console.log('will be updated now ');
        console.log($scope.editObj);
        var id = $cookieStore.get("userid");

        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {
            //console.log($scope.editObj);
            //console.log($scope.editObj.pwd);
            var obj = $scope.editObj;
            if ($scope.editObj.pwd.length <= 1) {
                // console.log('removing password');
                delete obj.pwd;
                // console.log(obj)
                // console.log(obj.pwd)
            }
            $http({
                method: 'POST',
                url: 'users/updateUser',
                data: $scope.editObj,
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (response.data.error) {
                        console.log(response.data.error)
                        alert(response.data.error);
                    } else if (response.data.success) {
                        // alert(response.data.success)
                        // console.log(response.data.success)
                        $scope.isEditing = false;
                        $scope.loadUsers();
                    } else {

                    }
                }

            }, function errorCallback(response) {
                alert('error');
                console.log(response);
            });

        }
    }
    $scope.viewUser = function (x) {
        $scope.allottingUser = -1;
        $scope.selected = parseInt(x);
        var id = $cookieStore.get("userid");
        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {
            $http({
                method: 'POST',
                url: 'users/getUser',
                data: {
                    'id': $scope.selected
                }
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {

                    if (response.data.error) {
                        console.log(response.data.error)
                        alert(response.data.error);
                    } else if (response.data.success) {
                        //console.log(response.data.success);
                        $scope.selectedUser = response.data.success
                        $scope.isEditing = false;
                        $scope.showAdduser = 0

                    } else {

                    }
                }
            }, function errorCallback(response) {
                alert('error');
            });
        }

    };
    $scope.submit = function () { //add user
        var id = $cookieStore.get("userid");
        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {
            /*if ($scope.defaultmenu == "mail") {
             $scope.default = 1;
             }
             else if ($scope.defaultmenu == "data") {
             $scope.default = 2;
             }
             else if ($scope.defaultmenu == "domain") {
             $scope.default = 3;
             }*/
            $scope.default = $scope.mainPermissionNames[$scope.defaultmenu];
            var obj = {
                "name": $scope.name,
                "email": $scope.mailid,
                "pwd": $scope.password,
                "default": $scope.default,
                "cBy": parseInt($cookieStore.get("userid"))
            };
            //console.log('add user');
            // console.log(obj)
            $http({
                method: 'POST',
                url: 'users/addUser',
                data: obj,
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (response.data.error) {
                        console.log(response.data.error)
                        alert(response.data.error);
                    } else if (response.data.success) {
                        //console.log(response)
                        //console.log(response.data.success)
                        alert(response.data.success);
                        $scope.loadUsers();
                    } else {

                    }

                }

            }, function errorCallback(response) {
                alert('error');
                console.log(response);
            });

        }

    };


}]);


/*
 sampleApp.controller('viewusers-controller', ['$scope', '$cookies', '$cookieStore', '$http', function ($scope, $cookies, $cookieStore, $http) {

 $scope.defaultnames = ["--Loading--"];
 $scope.mainPermissionNames = [];
 $scope.defaultmenu = $scope.defaultnames[0];


 $http({
 method: 'POST',
 url: 'users/getMainPermissions',
 }).then(function successCallback(response) {
 if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
 window.location.href = "./";
 } else {
 console.log(response.data);
 $scope.defaultnames = response.data[0];
 console.log($scope.users)
 $scope.mainPermissionNames = response.data[1];
 $scope.defaultmenu = $scope.defaultnames[0];
 }

 }, function errorCallback(response) {
 console.log(response);
 alert('error123');
 console.log('respons123')

 });



 $scope.users = [];
 $scope.selected = 0;
 $scope.selectedUser = null;
 $scope.isEditing = false;
 $scope.usersCopy = null;
 $scope.editingUser = null;
 $scope.editObj = {
 id: -1,
 name: '',
 email: '',
 pwd: '',
 status: -1,
 maincount: 0
 }
 $scope.showAdduser = 0;
 $scope.name = '';
 $scope.mailid = '';
 $scope.password = '';

 $scope.loadUsers = function () {
 var id = $cookieStore.get("userid");

 if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
 window.location.href = "./";
 } else {
 $http({
 method: 'POST',
 url: 'users/getUsers',
 }).then(function successCallback(response) {
 if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
 window.location.href = "./";
 } else {
 if (response.data.error) {
 console.log(response.data.error)
 alert(response.data.error);
 } else if (response.data.success) {
 console.log(response.data.success)
 $scope.users = response.data.success;
 console.log($scope.users)
 $scope.usersCopy = $scope.users;
 } else {
 alert('Error :')
 }

 }

 }, function errorCallback(response) {
 alert('error');
 console.log(response);
 });
 }
 }
 $scope.loadUsers();
 $scope.default = 1;
 $scope.showSub = 0;
 $scope.allottingUser = -1;
 $scope.mainpermissions = [];
 $scope.subpermissions = [];
 $scope.subpermissions = [];
 $scope.tasks = [];

 $scope.taskselection = [];
 $scope.subselection = [];
 $scope.mainselection = [];
 $scope.permissionNames = [];
 $scope.mainids = [];
 $scope.subids = [];
 $scope.mainselectednames = "";


 /!*  $scope.$watch('subpermissions|filter:{selected:true}', function (nv) {
 $scope.subselection = nv.map(function (permission) {
 return permission.name;
 });
 }, true);
 *!/
 $scope.main_sub = {};
 $scope.sub_task = {};
 $scope.switchMain=false;
 $scope.loadPermissions = function (y) {


 $http({
 method: 'POST',
 url: 'users/getSubPermissions',
 data: {
 'mainId': parseInt($scope.permissionNames[y]),
 'allotId':$scope.allottingUser
 }
 }).then(function successCallback(response) {
 if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
 window.location.href = "./";
 } else {
 console.log(response.data)
 if (response.data.error) {
 console.log(response.data.error)
 alert(response.data.error);
 $scope.loadPermissions();
 } else if (response.data.success) {

 console.log("response.data.success   :   ",response.data.success[0]);
 if (response.data.success.length > 1) {
 $scope.subpermissions = response.data.success[0];
 console.log('check here');
 console.log($scope.permissionNames);
 console.log();
 for (var attrname in response.data.success[1]) {
 $scope.permissionNames [attrname] = response.data.success[1][attrname];
 }

 $scope.mainselection.push(y);
 $scope.newSubMenu=$scope.subpermissions;
 $scope.main_sub[y] = $scope.subpermissions;
 console.log("newSubMenu   :  ",$scope.newSubMenu);
 console.log("mainselection   ",JSON.stringify($scope.main_sub));
 }
 else {
 alert('failed to load main permissons')
 }
 }
 }
 }, function errorCallback(response) {
 alert('error');

 });

 }
 $scope.changed = function (x, y) {
 //alert(x);
 $scope.switchMain=!$scope.switchMain;
 $scope.main=x;
 if (x == true) {
 $http({
 method: 'POST',
 url: 'users/getAllotPermissions',
 data: {
 'mainId': parseInt($scope.permissionNames[y]),
 'allotId':$scope.allottingUser
 }
 }).then(function successCallback(response) {
 if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
 window.location.href = "./";
 } else {
 console.log(response.data)
 if (response.data.error) {
 console.log(response.data.error)
 alert(response.data.error);
 $scope.loadPermissions(y);
 } else if (response.data.success) {
 console.log("response.data.success2    :  ",response.data.success2[0]);
 console.log("response.data.success   :   ",response.data.success[0]);
 if (response.data.success.length > 1) {
 $scope.subpermissions = response.data.success[0];
 console.log('check here');
 console.log($scope.permissionNames);
 console.log();
 for (var attrname in response.data.success[1]) {
 $scope.permissionNames [attrname] = response.data.success[1][attrname];
 }
 $scope.newSubMenu=response.data.success2[0];
 for(var i=0;i<response.data.success2[0].length;i++)
 {
 $scope.newSubMenu[i].selected=false;
 for(var j=0;j<response.data.success[0].length;j++){

 if(response.data.success2[0][i].id == response.data.success[0][j].id){
 console.log(response.data.success2[0][i].id +"  and   "+response.data.success[0][j].id);

 $scope.newSubMenu[i].selected=true;
 console.log($scope.newSubMenu)}
 }
 }

 $scope.mainselection.push(y);
 $scope.main_sub[y] = $scope.subpermissions;
 console.log("newSubMenu   :  ",$scope.newSubMenu);
 console.log("mainselection   ",JSON.stringify($scope.main_sub));
 }
 else {
 alert('failed to load main permissons')
 }
 } else {

 }
 }
 }, function errorCallback(response) {
 alert('error');

 });


 } else {
 console.log($scope.main_sub[y])
 //alert(y)
 //console.log($scope.sub_task);
 for (var ii in $scope.main_sub[y]) {
 //alert($scope.main_sub[y][ii].name);
 //$scope.subselection.splice($scope.subselection.indexOf($scope.main_sub[y][ii].name), 1);
 delete $scope.sub_task[$scope.main_sub[y][ii].name];
 }
 $scope.mainselection.splice($scope.mainselection.indexOf(y), 1);
 delete $scope.main_sub[y];
 }
 };

 $scope.changedTask = function (x, y) {
 if (x == 1) {
 $scope.taskselection.push(y);
 } else {
 $scope.taskselection.splice($scope.taskselection.indexOf(y), 1);
 }

 }
 $scope.changedSub = function (x, y) {

 if (x == 1) {
 $http({
 method: 'POST',
 url: 'users/getTasks',
 data: {
 'subId': parseInt(y)
 }
 }).then(function successCallback(response) {
 if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
 window.location.href = "./";
 } else {
 console.log(response.data)
 if (response.data.error) {
 console.log(response.data.error)
 alert(response.data.error);
 } else if (response.data.success) {
 console.log(response)
 console.log(response.data.success);
 if (response.data.success.length > 1) {
 $scope.tasks = response.data.success[0];
 console.log('check here');
 console.log($scope.permissionNames);
 console.log();
 for (var attrname in response.data.success[1]) {
 $scope.permissionNames [attrname] = response.data.success[1][attrname];
 }
 $scope.subselection.push(y);
 $scope.sub_task[y] = $scope.tasks;
 }
 else {
 alert('failed to load main permissons')
 }
 } else {

 }
 }
 }, function errorCallback(response) {
 alert('error');
 alert('error');
 });


 } else {
 $scope.subselection.splice($scope.subselection.indexOf(y), 1);
 delete $scope.sub_task[y];
 }
 };
 $scope.$watch('mainpermissions|filter:{selected:true}', function (nv) {
 $scope.mainselection = nv.map(function (permission) {

 return permission.name;
 });
 }, true);


 $scope.allotBool = false;

 $scope.allot = function (x) {
 $scope.switchMain=false;
 $scope.allottingUser = x;
 $scope.showAdduser = 0;
 $scope.isEditing = false;
 $scope.selectedUser = null;
 $scope.allotBool=!$scope.allotBool;

 var id = $cookieStore.get("userid");
 console.log('cookie ::: ' + id);
 if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
 window.location.href = "./";
 } else {
 /!*if ($scope.mainpermissions.length === 0 || $scope.subpermissions.length == 0) {*!/
 $http({
 method: 'POST',
 url: 'users/getPermissions',
 data: {
 'id': $scope.allottingUser
 }
 }).then(function successCallback(response) {
 if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
 window.location.href = "./";
 } else {
 if (response.data.error) {
 console.log(response.data.error)
 //alert(response.data.error);
 if(response.data.error="The user has no assigned Main Features")
 {
 $http({
 method: 'POST',
 url: 'users/getPermissions',
 data: {
 'id': id
 }
 }).then(function successCallback(response) {
 if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
 window.location.href = "./";
 } else {
 if (response.data.error) {}
 else if(response.data.success){
 console.log(response);
 console.log(response.data.success);
 $scope.mainpermissions = response.data.success[0];
 $scope.permissionNames = response.data.success[1];
 console.log(response.data[2]);
 }
 }})

 }
 } else if (response.data.success) {
 console.log("response success");
 console.log(response);
 console.log(response.data.success);
 $scope.mainpermissions = response.data.success[0];
 $scope.permissionNames = response.data.success[1];
 //$scope.permissionNames = response.data[2];
 /!*console.log($scope.mainpermissions);
 console.log($scope.subpermissions);*!/
 console.log(response.data[2]);
 }
 }
 }, function errorCallback(response) {
 //alert('error');
 });
 /!* } else {
 console.log('not loading permissions as already loaded')
 }*!/

 }

 $http({
 method: 'POST',
 url: 'users/getDomain'
 }).then(function successCallback(response) {
 if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
 window.location.href = "./";
 } else {
 $scope.domainResponse=response.data;
 console.log("getDomain:   ",response.data);
 }

 }, function errorCallback(response) {
 //alert('error');
 console.log(response);
 });


 //getDomain using userId
 $scope.getUserDomain();

 }
 $scope.getUserDomain = function(){

 $http({
 method: 'POST',
 url: 'users/getUserDomain',
 data: {
 "userId": $scope.allottingUser
 }
 }).then(function successCallback(response) {
 if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
 window.location.href = "./";
 } else {
 var obj=response.data;
 $scope.userDomains=obj.data;
 console.log("getUserDomain:   ",$scope.userDomains);
 }

 }, function errorCallback(response) {
 console.log('error');
 console.log(response);
 });
 }

 $scope.allotUpdate = function () {
 console.log('allotting');
 $scope.mainids = [];
 $scope.subids = [];
 for (i = 0; i < $scope.mainselection.length; i++) {
 $scope.mainids.push($scope.permissionNames[$scope.mainselection[i]]);
 }
 for (i = 0; i < $scope.subselection.length; i++) {
 $scope.subids.push($scope.permissionNames[$scope.subselection[i]]);
 }
 console.log($scope.mainids);
 console.log($scope.subids);

 var obj = {
 "id": $scope.allottingUser,
 "main": $scope.mainids,
 "subTask": $scope.subids,
 }
 console.log(obj);
 $http({
 method: 'POST',
 url: 'users/updateUser',
 data: obj,
 }).then(function successCallback(response) {
 if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
 window.location.href = "./";
 } else {
 console.log(response.data)
 }
 });
 }

 $scope.assignDomain=function () {

 console.log("$scope.allottingUser   :"+$scope.allottingUser);
 console.log("domainOpt     "+JSON.stringify($scope.domainOpt));

 $http({
 method: 'POST',
 url: 'users/postDomain',
 data: {"domainOpt":$scope.domainOpt,"userId":$scope.allottingUser}
 }).then(function successCallback(response) {
 if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
 window.location.href = "./";
 } else {
 console.log(response.data);
 $scope.getUserDomain();
 }
 }, function errorCallback(response) {
 alert('error');
 console.log(response);
 });



 }

 $scope.editUser = function (x) {
 $scope.allottingUser = -1;
 for (u in $scope.usersCopy) {
 if ($scope.usersCopy[u].id == x) {
 $scope.editingUser = $scope.usersCopy[u];
 $scope.editObj.id = parseInt($scope.editingUser.id);
 $scope.editObj.name = $scope.editingUser.name;
 $scope.editObj.email = $scope.editingUser.email;
 $scope.editObj.status = $scope.editingUser.status;
 $scope.editObj.pwd = $scope.editingUser.noHash;
 $scope.selectedUser = null;
 $scope.showAdduser = 0
 console.log($scope.editObj);

 }
 }
 console.log($scope.editingUser);
 $scope.isEditing = true;

 };
 $scope.editUpdate = function () {
 console.log('will be updated now ');
 console.log($scope.editObj);
 var id = $cookieStore.get("userid");

 if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
 window.location.href = "./";
 } else {
 console.log($scope.editObj);
 console.log($scope.editObj.pwd);
 var obj = $scope.editObj;
 if ($scope.editObj.pwd.length <= 1) {
 console.log('removing password');
 delete obj.pwd;
 console.log(obj)
 console.log(obj.pwd)
 }
 $http({
 method: 'POST',
 url: 'users/updateUser',
 data: $scope.editObj,
 }).then(function successCallback(response) {
 if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
 window.location.href = "./";
 } else {
 if (response.data.error) {
 console.log(response.data.error)
 alert(response.data.error);
 } else if (response.data.success) {
 alert(response.data.success)
 console.log(response.data.success)
 $scope.isEditing = false;
 $scope.loadUsers();
 } else {

 }
 }

 }, function errorCallback(response) {
 alert('error');
 console.log(response);
 });

 }
 }
 $scope.viewUser = function (x) {
 $scope.allottingUser = -1;
 $scope.selected = parseInt(x);
 var id = $cookieStore.get("userid");
 if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
 window.location.href = "./";

 } else {
 $http({
 method: 'POST',
 url: 'users/getUser',
 data: {
 'id': $scope.selected
 }
 }).then(function successCallback(response) {
 if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
 window.location.href = "./";
 } else {

 if (response.data.error) {
 console.log(response.data.error)
 alert(response.data.error);
 } else if (response.data.success) {
 console.log(response.data.success);
 $scope.selectedUser = response.data.success
 $scope.isEditing = false;
 $scope.showAdduser = 0

 } else {

 }
 }
 }, function errorCallback(response) {
 alert('error');
 });
 }

 };
 $scope.submit = function () { //add user
 var id = $cookieStore.get("userid");
 if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
 window.location.href = "./";
 } else {
 /!*if ($scope.defaultmenu == "mail") {
 $scope.default = 1;
 }
 else if ($scope.defaultmenu == "data") {
 $scope.default = 2;
 }
 else if ($scope.defaultmenu == "domain") {
 $scope.default = 3;
 }*!/
 $scope.default = $scope.mainPermissionNames[$scope.defaultmenu];
 var obj = {
 "name": $scope.name,
 "email": $scope.mailid,
 "pwd": $scope.password,
 "default": $scope.default,
 "cBy": parseInt($cookieStore.get("userid"))
 };
 console.log('add user');
 console.log(obj)
 $http({
 method: 'POST',
 url: 'users/addUser',
 data: obj,
 }).then(function successCallback(response) {
 if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
 window.location.href = "./";
 } else {
 if (response.data.error) {
 console.log(response.data.error)
 alert(response.data.error);
 } else if (response.data.success) {
 console.log(response)
 console.log(response.data.success)
 alert(response.data.success);
 $scope.loadUsers();
 } else {

 }

 }

 }, function errorCallback(response) {
 alert('error');
 console.log(response);
 });

 }

 };


 }]);*/


sampleApp.controller('campaignsCtrl', ['$scope', '$cookies', '$cookieStore', '$http', function ($scope, $cookies, $cookieStore, $http) {




    $scope.getCampaigns = function()
    {
        $scope.campaigns=[];
        $http({
            method: 'GET',
            url: 'users/getCampaigns'
        }).then(function successCallback(response) {
            //console.log("response : ",response);
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {
                $scope.campNames=[];
                //console.log("getCampaigns  res  :  ",JSON.stringify(response.data))
                $scope.campaigns=response.data;
                //console.log("length  :  "+response.data.length);
                $scope.campIn=[[]];
                for(var i=0;i<response.data.length;i++)
                {

                    var campId = response.data[i].campId;
                    var ctdOn = response.data[i].ctdOn;
                    var newsLetter = response.data[i].title;

                    $http({
                        method: 'POST',
                        url: 'users/getStep1/'+campId
                    }).then(function successCallback(response) {
                            // console.log("response : ",response);
                            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                                window.location.href = "./";

                            } else {
                                // console.log("response in getCamapaings campaign :  "+JSON.stringify(response.data));
                                $scope.campNames.push(response.data.name);
                            }
                        }
                        , function errorCallback(response) {
                            alert('getCampaigns' + JSON.stringify(response));
                        });


                }

            }
        }, function errorCallback(response) {
            alert('getCampaigns' + JSON.stringify(response));
        });

    }

    $scope.getCampaigns();

    $scope.newCamp=[];
    $scope.calculate = function()
    {
        var obj = [{saab:[1,2,3]},{Volvo:[4,5,6]}]
        for(var i=0;i<obj.length;i++)
        {
            for (var prop in obj) {

            }

            console.log("obj with key"+obj[i]);

        }


    }
    $scope.calculate();


}]);

sampleApp.controller('campaignMonitorDivCtrl', ['$interval','$scope', '$cookies', '$cookieStore', '$http', function ($interval,$scope, $cookies, $cookieStore, $http)
{



    $scope.monitoringDetails = [];
    $scope.tempResponse=[];

    $scope.flagNL = true;

    function getCurrentNl()
    {

        $scope.flagNL = false;
        $http({
            method: 'POST',
            url: 'users/getCurrentNl'

        }).then(function successCallback(response) {

            $scope.flagNL = true;
            //console.log("response : ",response);
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {

                window.location.href = "./";
            }
            else {
                var tempvaraible=[];


                $scope.tempResponse = response.data;
                $scope.tempVar = 0;
                // console.log("response.data.length :  "+response.data.length);

                var i=0;

                function inserttempd() {
                    if (i < response.data.length) {
                        // console.log("response.data.length inside forloop  :  ", response.data.length);
                        var dataObj = {"nlId": response.data[i].id}
                        $http({

                            method: 'post',
                            url: 'users/getNlDetail',
                            data: dataObj

                        }).then(function successCallback(res) {

                            $scope.loadingImg = -1;

                            //console.log("getNlDetail response : ", res);
                            if (res.data === 'logout' || JSON.stringify(res.data).indexOf('logout') > -1) {
                                window.location.href = "./";
                            } else {
                                var j = $scope.tempVar++;
                                // console.log(" $scope.tempResponse inside :  " + j + "  SN " + $scope.tempResponse[j].SN);
                                //console.log("getNlDetail.data.length :  " + res.data.length);
                                console.log("getNlDetail     ", JSON.stringify(res.data));

                                tempvaraible[j]=
                                    {
                                        "status": $scope.tempResponse[j].status,
                                        "SN": $scope.tempResponse[j].SN,
                                        "SL": $scope.tempResponse[j].SL,
                                        "totalVol": $scope.tempResponse[j].totalVol,
                                        "sent": res.data[0].sent,
                                        "dlvrd": res.data[0].dlvrd,
                                        "uOpen": res.data[0].uOpen,
                                        "uClick": res.data[0].uClick,
                                        "bounce": res.data[0].bounce,
                                        "unSub": res.data[0].unSub,
                                        "nlId": res.data[0].nlId
                                    };
                                i++;
                                inserttempd();
                            }
                            $scope.flag = true;
                        }, function errorCallback(res) {
                            window.location.href = "./";

                        });


                    }
                    else {

                        $scope.monitoringDetails=tempvaraible;
                    }
                }
                inserttempd();
            }

        }, function errorCallback(response) {
            window.location.href = "./";
            $scope.flagNL = true;
            /*
             alert('error1' + JSON.stringify(response));*/
        });


    }


    $scope.flagAllot = true;

    $scope.allotPush = function()
    {
        // alert("allotPUsh");
        //getNlmAlloted Push
        $scope.flagAllot = false;
        $http({

            method: 'POST',
            url: '/users/getNlmAlloted'

        }).then(
            function successCallBack(res) {

                $scope.flagAllot = true;
                // console.log("response getNlmAlloted "+JSON.stringify(res.data));

                return;
            },
            function errorCallBack(res) {

                $scope.flagAllot = true;
                // console.log("error in getNlmAlloted");
                return;

            });

    }
    //$scope.allotPush();


    var currenttimout=1000;
    var stopcurrentNl=$interval(function ()
    {

        if($scope.flagNL) {
            getCurrentNl();

        }
        if(currenttimout==1000)
        {
            $interval.cancel(stopcurrentNl);
            currenttimout=20000;
            stopcurrentNl=$interval(function () {
                if($scope.flagNL) {
                    getCurrentNl();

                }
            }, currenttimout);
        }

    }, currenttimout);

    var stopAllotPush=$interval(function () {
        if($scope.flagAllot){
            $scope.allotPush();
        }
    }, 20000);

    $scope.loadingImg = -1;
    var obj;

    $scope.startMonitor = function(nlId,status)
    {
        $interval.cancel(stopcurrentNl);
        currenttimout=1000;
        $scope.loadingImg = nlId;
        // alert("startMonitor  id "+nlId);
        if(status==4){
            obj = {"status":0,"nlId":nlId}
        }
        else if(status == 3)
        {
            obj = {"status":1,"nlId":nlId}
        }

        $http({
            method: 'POST',
            url: 'users/nlUpdate',
            data:obj
        }).then(function successCallback(response) {

            // console.log("response : ",response);
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1)
            {
                window.location.href = "./";
            } else
            {
                stopcurrentNl=$interval(function () {

                    if($scope.flagNL) {
                        getCurrentNl();

                    }
                    if(currenttimout==1000)
                    {
                        $interval.cancel(stopcurrentNl);
                        currenttimout=20000;
                        stopcurrentNl=$interval(function () {
                            if($scope.flagNL) {
                                getCurrentNl();

                            }
                        }, currenttimout);
                    }

                }, currenttimout);
                // $scope.getCurrentNl();
                // console.log("start  res  :  ",JSON.stringify(response.data))
            }
        }, function errorCallback(response) {
            console.log("startMOnitor error");
            /*alert('startMonitor' + JSON.stringify(response));*/
        });

    }

    $scope.stopMonitor = function(nlId)
    {
        $interval.cancel(stopcurrentNl);
        currenttimout=1000;
        $scope.loadingImg = nlId;
        //alert("stopMonitor  id  :  "+nlId);
        var obj = {"status":3,"nlId":nlId}
        $http({
            method: 'POST',
            url: 'users/nlUpdate',
            data:obj
        }).then(function successCallback(response) {
            //console.log("response : ",response);
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {

                stopcurrentNl=$interval(function () {

                    if($scope.flagNL) {
                        getCurrentNl();
                    }
                    if(currenttimout==1000)
                    {
                        $interval.cancel(stopcurrentNl);
                        currenttimout=20000;
                        stopcurrentNl=$interval(function () {
                            if($scope.flagNL) {
                                getCurrentNl();
                            }
                        }, currenttimout);
                    }

                }, currenttimout);
                //  $scope.getCurrentNl();
                //console.log("stopMontor  res  :  ",JSON.stringify(response.data))
            }
        }, function errorCallback(response) {
            console.log("stopMontor res error : ")
            //alert('stopMonitor' + JSON.stringify(response));
        });

    }

}]);

sampleApp.controller('today-campaigns-controller', ['todayData0','$rootScope','$log','$notification','$filter','socket','$scope', '$cookies', '$cookieStore', '$http', function (todayData0,$rootScope,$log,$notification,$filter,socket,$scope, $cookies, $cookieStore, $http) {

    //console.log("todayData b4 :  "+todayData0.getDate());

    $scope.iconClick = function () {
        var element = document.getElementById("datePicker1");
        element.focus();
    }


    $scope.viewNl = function(campId)
    {
        todayData0.setDate($scope.startOn);
        todayData0.setCampId(campId);
        window.location.href = "#users/viewNL";
    }


    $scope.notify = function notify() {
        createNotification();
    };

    $scope.askPermision = function() {
        $notification.requestPermission()
            .then(function success(value) {
                new Notification('Notification allowed', {
                    body : value,
                    delay: 5000
                });
            }, function error() {
                $log.error("Can't request for notification");
            })
    };




    function createNotification() {
        var notification = $notification('New message', {
            body: 'You have a new message.',
            delay: 2000
        });

        notification.$on('show', function () {
            $log.debug('My notification is displayed.');
        });

        notification.$on('click', function () {
            $log.debug('The user has clicked in my notification.');
        });

        notification.$on('close', function () {
            $log.debug('The user has closed my notification.');
        });

        notification.$on('error', function () {
            $log.debug('The notification encounters an error.');
        });
    }



    $scope.sortByVar = '-ctdOn';
    $scope.changeFilter = function(type)
    {
        $scope.sortByVar = type;
    }
    $scope.filterSort = [{type:'createdBy',show:'Sort by CreatedBy'},
        {type:'title',show:'Sort by NewsletterTitle'}];

    $scope.currentDate = $filter('date')(new Date(), 'yyyy-MM-dd');
    $scope.startOn = $filter('date')(new Date(), 'yyyy-MM-dd');



    $scope.preload = true;
    $scope.campaigns = [];
    $scope.pickedvolumes = [];
    $scope.selected = -1;
    $scope.viewing = null;
    $scope.subjects = [];
    $scope.senders = [];
    $scope.volume = 0;

    $scope.vol = 0;

    $scope.disableAdding = true;

    $scope.typeColor = {open:'fa rate-icon blue-1',click:'fa rate-icon green-1',lead:'fa rate-icon orrange-1',push:'fa rate-icon pink-1'};

    $scope.getNlmByDt = function (dt) {
        //alert("dt  : "+dt);
        var date = new Date(dt);
        var date2Day = date.setHours(0,0,0,0);
        var id = $cookieStore.get("userid");

        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {

            $scope.preload = true;
            $scope.campaigns=[];
            var obj={"where":{"ctdOn":date2Day/1000,"status":1,"cType":"direct"}};
            console.log("obj : "+JSON.stringify(obj));
            $http({
                method: 'POST',
                url: 'users/getNlmByDt',
                data:{url:"api/nlm/query?filter="+JSON.stringify(obj)}
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1)
                {
                    window.location.href = "./";
                } else
                {
                    $scope.campaigns = response.data.success[0];
                    $scope.preload = false;
                    $scope.pickedvolumes = response.data.success[1];
                    //console.log('check');
                    //console.log($scope.pickedvolumes);
                    // console.log('check');
                    for (cmp in $scope.campaigns) {
                        // alert($scope.campaigns[cmp].id);
                        var idstring = '' + $scope.campaigns[cmp].id;
                        if ($scope.pickedvolumes[idstring] == undefined || $scope.pickedvolumes[idstring] == null) {
                            $scope.pickedvolumes[$scope.campaigns[cmp].id] = 0;
                        }


                    }}
            }, function errorCallback(response) {
                //alert('error' + response);
                console.log(response);
            });
        }
    }


    // $scope.getNlmByDt($scope.startOn);



    $scope.loadToday = function (dt) {
        var date = new Date(dt);
        var date2Day = date.setHours(0,0,0,0);
        var id = $cookieStore.get("userid");
       // console.log("date2Day : "+date2Day);
       // console.log("dt : "+dt);
        var obj={"where":{"ctdOn":date2Day/1000,"status":1,"cType":"direct"}};
        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {

            $scope.preload = true;
            $scope.campaigns=[];

            $http({
                method: 'POST',
                url: 'users/getTodaysCampaigns',
                data:{url:"api/nlm/query?filter="+JSON.stringify(obj)}
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1)
                {
                    window.location.href = "./";
                } else
                {
                    if(typeof response.data.success != 'undefined'){
                        $scope.campaigns = response.data.success[0];
                        $scope.preload = false;
                        $scope.pickedvolumes = response.data.success[1];
                        // console.log('check');
                        //  console.log($scope.pickedvolumes);
                        //  console.log('check');
                        for (cmp in $scope.campaigns) {
                            // alert($scope.campaigns[cmp].id);
                            var idstring=''+$scope.campaigns[cmp].id;
                            if ($scope.pickedvolumes[idstring] == undefined || $scope.pickedvolumes[idstring] == null) {
                                $scope.pickedvolumes[$scope.campaigns[cmp].id] = 0;
                            }
                            /*if ($scope.pickedvolumes[cmp.id] == undefined || $scope.pickedvolumes[cmp.id] == null) {
                             $scope.pickedvolumes[$scope.campaigns[cmp].id] = 0;
                             }*/
                        }
                        //console.log($scope.pickedvolumes);
                        //console.log('check');
                    }

                }
            }, function errorCallback(response) {
                //alert('error' + response);
                console.log(response);
            });
        }
    }


    $scope.selecteddvol=0;
    $scope.selectedpvol=0;


    if(todayData0.getDate()!='')
    {
        $scope.startOn = $filter('date')(new Date(todayData0.getDate()), 'yyyy-MM-dd');
        $scope.loadToday(todayData0.getDate());
    }
    else
    {
        $scope.loadToday($scope.startOn);
    }




    $rootScope.$on("CallParentMethod", function(){

        $scope.startOn =   $filter('date')(new Date($rootScope.date2Day), 'yyyy-MM-dd');
        $scope.loadToday($rootScope.date2Day);
    });


    $scope.getUserDomain = function(){

        $http({
            method: 'POST',
            url: 'users/getUserDomain'
        }).then(function successCallback(response) {
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {

                var obj=response.data;
                $scope.userDomains=obj.data;
                // console.log("getUserDomain:   ",$scope.userDomains);

                if($scope.userDomains == '' || $scope.userDomains == null)
                {
                    alert("No Domains alloted to you please contact admin");
                    $("#myModal").modal('hide');
                }
                else {
                    $("#myModal").modal('show');
                }
            }

        }, function errorCallback(response) {
            console.log('error');
            console.log(response);
        });

    }



    $scope.addToMineShow = function (x, dvol, pvol,userRel,campRel) {

        //$("#myModal").modal('hide');
        $scope.userRelId = userRel;
        $scope.remaining = dvol - pvol;
        $scope.campRelName = campRel;
        //alert(pvol+" and remaining is  :  "+$scope.remaining);
        if($scope.remaining<=0){

            alert("No remaining vol to sent campaign");
            $("#myModal").modal('hide');

        }else{

            console.log(dvol);
            console.log(pvol);
            $scope.selecteddvol=dvol;
            $scope.selectedpvol=pvol;
            console.log(dvol - pvol);
            $scope.selected = parseInt(x);

            if (!isNaN($scope.remaining) && $scope.remaining > 0) {
                $scope.disableAdding = false;
            } else {
                console.log('cannot enable add button');
            }
            $scope.getUserDomain();
        }

    };


    $scope.addToMineClose = function () {
        $scope.disableAdding = false;
        $scope.selected = -1;
        /* $scope.volume = 0;
         $scope.selecteddvol=0;
         $scope.selectedpvol=0;*/
    };


    $scope.addToMine = function (vol, campid) {

        var id = $cookieStore.get("userid");
        //alert("addToMine userid  "+id);
        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1))
        {
            window.location.href = "./";
        } else {
            var obj = {
                "userId": parseInt(id),
                "nlmId": parseInt($scope.selected),
                'pickVol': parseInt($scope.volume),
                "userRelId":$scope.userRelId,
                "campRelName": $scope.campRelName,
                "agentName": $cookieStore.get('userName')
            }
            //console.log(obj);
            $http({
                method: 'POST',
                url: 'users/allotToMe',
                data: obj
            }).then(function successCallback(response) {
                //console.log(response);
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    $scope.volume = 0;
                    if (response.data.error) {
                        console.log(response.data.error)
                        alert(response.data.error);
                    } else if (response.data.success) {
                        // console.log(response.data.success)
                        alert("Campaign added Successfully");
                        $scope.loadToday($scope.startOn);
                    } else {
                    }
                }
            }, function errorCallback(response) {
                window.location.href = "./";

            });
        }

    };

}])
;
sampleApp.controller('view-newsletter-controller', ['todayData0','$scope', '$cookies', '$cookieStore', '$window', '$http', function (todayData0,$scope, $cookies, $cookieStore, $window,$http)
{

    $scope.campId = todayData0.getCampId();
    $scope.newsletter = null;


    var id = $cookieStore.get("userid");

    if (id === undefined || ( JSON.stringify(id).indexOf('null') > -1)) {
        window.location.href = "./";
    } else {
        $http({
            method: 'POST',
            url: "users/getNewsLetter",
            data: {
                'nlId': parseInt($scope.campId),
            }
        }).then(function successCallback(response) {
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {
                if (response.data.error) {
                    console.log(response.data.error)
                    alert(response.data.error);
                } else if (response.data.success) {
                    //console.log(response.data.success)
                    $scope.newsletter = response.data.success;
                    //console.log($scope.newsletter);
                    var myEl = angular.element(document.querySelector('#creative'));
                    myEl.html($scope.newsletter.creative);


                    $scope.nTags=[];
                    $scope.newsTagIds = 0;
                    for(i=0;i<$scope.newsletter.tags.length; i++){
                        //$scope.newsTagIds.push(res.data.tags[i]);
                        $scope.newsTagIds=$scope.newsletter.tags[i] ;
                        $http({

                            method: 'GET',
                            url: '/users/getNewsTags1/'+$scope.newsTagIds

                        }).then(
                            function successCallBack(res) {
                                // console.log("response ");
                                // console.log(res);
                                // console.log("response of campaingn7 ctrl"+res);
                                $scope.news1Tags = res.data;

                                //console.log("res.data.name...."+res.data.id);

                                $scope.nTags.push({"name":res.data.name, "id":res.data.id});
                                /*$scope.tagIn.push({"text":res.data.name, "id":res.data.id});*/

                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }



                    $scope.nBrands=[];
                    $scope.newsBrandIds = 0;
                    if(typeof $scope.newsletter.tBrands != 'undefined'){
                        for(i=0;i<$scope.newsletter.tBrands.length; i++){
                            //$scope.newsTagIds.push(res.data.tags[i]);
                            $scope.newsBrandIds=$scope.newsletter.tBrands[i] ;

                            $http({

                                method: 'GET',
                                url: '/users/getNewsTags1/'+$scope.newsBrandIds


                            }).then(
                                function successCallBack(res) {
                                    // console.log("response ");
                                    // console.log(res);
                                    //console.log("response of campaingn7 ctrl"+res);
                                    $scope.brand1Tags = res.data;

                                    console.log("res.data.name...."+res.data.id);

                                    $scope.nBrands.push({"name":res.data.name, "id":res.data.id});


                                },
                                function errorCallBack(res) {

                                    //alert("error");
                                    console.log("error in tags");

                                    return res.data;
                                });
                        }
                    }

                    $scope.ntPRs=[];
                    $scope.newstPrIds = 0;
                    if(typeof $scope.newsletter.tPR != 'undefined'){
                        for(i=0;i<$scope.newsletter.tPR.length; i++) {
                            //$scope.newsTagIds.push(res.data.tags[i]);
                            $scope.newstPrIds = $scope.newsletter.tPR[i];

                            $http({

                                method: 'GET',
                                url: '/users/getNewsTags1/' + $scope.newstPrIds

                            }).then(
                                function successCallBack(res) {
                                    //console.log("response ");

                                    // console.log("res.data.name...." + res.data.id);

                                    $scope.ntPRs.push({"name": res.data.name, "id": res.data.id});

                                },
                                function errorCallBack(res) {

                                    //alert("error");
                                    console.log("error in tags");

                                    return res.data;
                                });
                        }
                    }


                    $scope.nCatTags=[];
                    $scope.catIds = 0;
                    if (typeof $scope.newsletter.targets.catTags != 'undefined') {

                        for (i = 0; i < $scope.newsletter.targets.catTags.length; i++) {

                            $scope.catIds = $scope.newsletter.targets.catTags[i];

                            $http({

                                method: 'GET',
                                url: '/users/getNewsTags1/' + $scope.catIds


                            }).then(
                                function successCallBack(res) {
                                    //  console.log("response ");
                                    //  console.log(res);
                                    //  console.log("response of campaingn7 ctrl" + res);
                                    //  console.log("res.data.name...." + res.data.id);

                                    $scope.nCatTags.push({"name": res.data.name, "id": res.data.id});

                                },
                                function errorCallBack(res) {
                                    //alert("error");
                                    console.log("error in tags");

                                    return res.data;
                                });
                        }

                    }

                    var idObj = {countryId:$scope.newsletter.targets.country};
                    console.log("idObj  :  "+JSON.stringify(idObj));
                    $http({

                        method: 'POST',
                        url: '/users/getCountriesById/',
                        data:idObj

                    }).then(
                        function successCallBack(res) {

                            console.log("getCountriesById  res  :  "+JSON.stringify(res.data),"    and  :  ");
                            $scope.newsletter.country=res.data.data.name;

                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });
                    var idObj = {eDomain:$scope.newsletter.targets.eDomain};
                    $http({

                        method: 'POST',
                        url: '/users/getEdomainById/',
                        data:idObj

                    }).then(
                        function successCallBack(res) {

                            //console.log("getEdomainById  res  :  "+JSON.stringify(res.data)," and name  :  ",res.data.name);
                            $scope.newsletter.eDomain=res.data.name;
                            // console.log("$scope.newsletter.eDomain   :  "+$scope.newsletter.eDomain);
                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });

                    if(typeof $scope.newsletter.targets.city != 'undefined'){
                        var idObj = {cityIds:$scope.newsletter.targets.country};
                        $http({

                            method: 'POST',
                            url: '/users/getCityByIds/',
                            data:idObj

                        }).then(
                            function successCallBack(res) {

                                // console.log("getcityById  res  :  "+JSON.stringify(res.data));
                                $scope.newsletter.city=res.data.data;

                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }

                } else {

                }
            }
        }, function errorCallback(response) {
            alert('error2' + response);
        })
    }

}]);


Array.prototype.insert = function (index, item) {
    this.splice(index, 0, item);
};

sampleApp.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function(){
                scope.$apply(function(){
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);
sampleApp.factory('fileUpload', ['$http', function ($http) {
    var promise;
    var fileUpload1 = {

        async: function (file, uploadUrl) {
            if (true) {

                var fd = new FormData();
                fd.append('file', file);

                promise = $http.post(uploadUrl, fd, {
                    transformRequest: angular.identity,
                    headers: {'Content-Type': undefined}
                })

                    .success(function (response) {
                        //alert("success " + JSON.stringify(response));
                        return response.data;
                    })

                    .error(function (response) {
                        alert("error : " + JSON.stringify(response));
                        return response.data;
                    });

            }
            return promise;
        }
    };
    return fileUpload1;
}]);



sampleApp.controller('mycampaigns-controller', ['mycampaignData0','$log','$notification','$filter','$scope', '$cookies', '$cookieStore', '$window', '$http', function (mycampaignData0,$log,$notification,$filter,$scope, $cookies, $cookieStore, $window, $http) {


    $scope.notify = function notify() {
        createNotification();
    };


    $scope.viewNlMyCampaigns = function(camp)
    {

        mycampaignData0.setDate($scope.startOn);
        mycampaignData0.setNlmId(camp.nlmId);
        mycampaignData0.setPickVol(camp.pickVol);
        mycampaignData0.setPushVol(camp.pushVol);
        mycampaignData0.setUserId(camp.userId);
        mycampaignData0.setCampDate(camp.date);

        window.location.href = "#/campaigns/startCampaign";
    }

    $scope.askPermision = function() {
        $notification.requestPermission()
            .then(function success(value) {
                new Notification('Notification allowed', {
                    body : value,
                    delay: 5000
                });
            }, function error() {
                $log.error("Can't request for notification");
            })
    };




    function createNotification() {
        var notification = $notification('New message', {
            body: 'You have a new message.',
            delay: 2000
        });

        notification.$on('show', function () {
            $log.debug('My notification is displayed.');
        });

        notification.$on('click', function () {
            $log.debug('The user has clicked in my notification.');
        });

        notification.$on('close', function () {
            $log.debug('The user has closed my notification.');
        });

        notification.$on('error', function () {
            $log.debug('The notification encounters an error.');
        });
    }

    $scope.notify = function notify() {
        createNotification();
    };


    $scope.createdSuccessfully = function()
    {
        var notification = $notification('New message', {
            body: 'TestMail Created Successfully',
            delay: 2000
        });
    }
    $scope.campaignSuccess = function()
    {
        var notification = $notification('New message', {
            body: 'TestMail Created Successfully',
            delay: 2000
        });
    }


    $scope.var = 1;
    $scope.showingTest = 0;
    $scope.campId = 1;
    $scope.campaigns = null;
    $scope.testMailInput = "";
    $scope.testSender = "";
    $scope.testSubject = "";
    $scope.preload = true;
    $scope.typeColor = {open:'fa rate-icon blue-1',click:'fa rate-icon green-1',lead:'fa rate-icon orrange-1',push:'fa rate-icon pink-1'};

    $scope.sortByVar = '-ctdOn';
    $scope.changeFilter = function(type)
    {
        $scope.sortByVar = type;
    }
    $scope.filterSort = [{type:'createdBy',show:'Sort by CreatedBy'},
        {type:'title',show:'Sort by NewsletterTitle'}];

    $scope.currentDate = $filter('date')(new Date(), 'yyyy-MM-dd');
    $scope.startOn = $filter('date')(new Date(), 'yyyy-MM-dd');

    $scope.getNlmByDt = function (dt) {

        var id = $cookieStore.get("userid");
        //alert(id);
        var date = new Date(dt);
        var date2Day = date.setHours(0,0,0,0);

        if (id === undefined || ( JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {

            $scope.campaigns = '';
            $scope.preload = true;

            $http({
                method: 'POST',
                url: "users/getMyCampaigns",
                data: {
                    'id': parseInt(id),
                    'dt': date2Day/1000
                }
            }).then(
                function successCallBack(res){
                    //console.log("response   :  ",res);
                    var obj = res.data;
                    $scope.campaigns = obj;
                    $scope.preload = false;
                },
                function errorCallBack(res){
                    $scope.preload = false;
                    console.log("error getStep1  ",res);
                });

        }

    }


    if(mycampaignData0.getDate()!='')
    {
        //alert("mycampaignData0.getDate()  : "+mycampaignData0.getDate());
        $scope.startOn = $filter('date')(new Date(mycampaignData0.getDate()), 'yyyy-MM-dd');
        $scope.getNlmByDt(mycampaignData0.getDate());
    }
    else
    {
        //alert("else date  "+$scope.startOn);
        $scope.getNlmByDt($scope.startOn);
    }




    $scope.showTestMail = function (camp) {

        $scope.showingTest=camp.id;
        $scope.testCamp = camp;
        $scope.getNewsLetter(camp.nlmId);
        $scope.getUserDomain();

    }

    $scope.getUserDomain = function(){
        var id = $cookieStore.get("userid");
        $http({
            method: 'POST',
            url: 'users/getUserDomain',
            data: {
                "userId": id
            }
        }).then(function successCallback(response) {
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {
                var obj=response.data;
                $scope.userDomains=obj.data;
                // console.log("getUserDomain:   ",$scope.userDomains);

            }

        }, function errorCallback(response) {
            console.log('error');
            console.log(response);
        });
    }

    $scope.closeTestMail = function () {
        $scope.showingTest = 0;
        //alert('hi');
    }


    $scope.selection = [];

    $scope.getNewsLetter = function(nlmId)
    {
        $http({
            method: 'POST',
            url: "users/getNewsLetter",
            data: {
                'nlId': parseInt(nlmId),
            }
        }).then(function successCallback(response) {

            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {
                if (response.data.error) {
                    console.log(response.data.error)
                    alert(response.data.error);
                } else if (response.data.success) {

                    $scope.newsletter = response.data.success;
                    // console.log("newsLetter  ",$scope.newsletter);
                }

            }

        }, function errorCallback(response) {
            alert('error3' + response);
        });

    }


    $scope.toggleSelection = function toggleSelection(userD) {

        var idx = $scope.selection.indexOf(userD);

        // is currently selected
        if (idx > -1) {
            $scope.selection.splice(idx, 1);
        }

        // is newly selected
        else {
            $scope.selection.push(userD);
        }
        //alert($scope.selection);
    };

    $scope.showLoading = false;

    $scope.sendTestMail = function () {

        $scope.showLoading = true;
        $scope.domainObj=[];
        //alert("inside testmail");
        var flag=false;

        //var value = document.getElementById('sendtestemailid').value;
        var value = $scope.testMailInput;
        //alert(value);
        var duplicatesArray = new Array();
        var uniqueArray = new Array();
        value = value.replace(/ /g, "");
        if (value.indexOf(",") !== -1) {
            var result = value.split(",");
            $scope.emailIdLength = result.length;
            //alert("result  :  "+result);
            if (result.length <= 1000) {
                for (var i = 0; i < result.length; i++) {
                    var actualEmail = result[i];
                    actualEmail = $.trim(actualEmail);
                    if (actualEmail != "") {
                        if (!validateEmail(actualEmail)) {
                            alert(actualEmail + " is invalid email Id.Please enter valid email Id");
                            flag = false;
                            break;
                        } else {
                            duplicatesArray.push(actualEmail.toLowerCase());
                            flag = true;
                        }
                    } else {
                        alert("Invalid email Id.Please remove comma at the end");
                        flag = false;
                        break;
                    }

                }

            } else {
                alert("Only 10 email Id's seperated by comma are allowed");
            }

        } else {
            $scope.emailIdLength=1;
            if (!validateEmail(value)) {
                alert(value + " is invalid email Id.Please enter valid email Id");
                flag = false;
            } else {
                flag = true;
            }

        }

        function validateEmail(sEmail) {
            var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (filter.test(sEmail)) {
                return true;
            }
            else {
                return false;
            }
        }

        if (flag == true) {


            var ids = "";
            var c = document.getElementsByName('listgroup');

            var totd=0;
            for (var i = 0; i < c.length; i++)
            {
                //alert("c[i].id  : "+c[i].id);
                if (c[i].checked) {
                    $scope.domainObj.push({id:c[i].id,vol:$scope.emailIdLength})
                    ids = ids + c[i].id + ",";
                    totd++;
                }
                else
                {
                }
            }


            var d1 = new Date();
            var date1 = d1.setHours(0, 0, 0,0);
            var startOn =  date1/ 1000;

            var id = $cookieStore.get("userid");

            var obj = {
                "nlmId": $scope.testCamp.nlmId,
                "campId": $scope.newsletter.campId,
                "userId": $scope.testCamp.userId,
                "SN": $scope.testCamp.SN,
                "SL": $scope.testCamp.SL,
                "creative": $scope.newsletter.creative,
                "domains": $scope.selection,
                "emails": [$scope.testMailInput],
                "startAt": $scope.newsletter.startOn ,
                "totalVol": parseInt($scope.emailIdLength)*parseInt(totd),
                "domainWise": $scope.domainObj,
                "tempVol": $scope.emailIdLength,
                "dateStamp":startOn
            }



            $scope.testMailInput = "";
            console.log('test mail will be sent')

            var id = $cookieStore.get("userid");
            if (id === undefined || ( JSON.stringify(id).indexOf('null') > -1)) {
                window.location.href = "./";
            } else {

                 $http({
                    method: 'POST',
                    url: "users/createTestNews",
                    data: obj
                }).then(function successCallback(response) {


                    if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1)
                    {
                        window.location.href = "./";
                    }
                    else {


                        if(response.data.error == "campaign sent successfully !")
                        {
                            alert("Test Mail Sent Successfully");
                            $scope.createdSuccessfully();
                        }
                        else{
                            alert(response.data.error);
                        }


                        $scope.showLoading = false;
                        $scope.selection=[];
                        $('#myModal').modal('hide');

                    }
                }, function errorCallback(response) {

                    $scope.showLoading = false;
                    $scope.selection=[];
                    $('#myModal').modal('hide');


                })



            }

        }
        else {
            //alert(" improper data");
            $('#myModal').modal('show');
            // $scope.showingTest = 0;
        }
    }

}]);

sampleApp.controller('start-campaign-controller', [ 'mycampaignData0','$cookieStore','$rootScope','$timeout','$scope', '$cookies', '$cookieStore', '$window', '$routeParams', '$http', function (mycampaignData0,$cookieStore,$rootScope,$timeout,$scope, $cookies, $cookieStore, $window, $routeParams, $http) {

    $scope.valideVal = 'hello';

    $scope.sentVol= mycampaignData0.getPushVol();
    $scope.userId = mycampaignData0.getUserId();
    $scope.nlmId = mycampaignData0.getNlmId();
    $scope.pickVol = mycampaignData0.getPickVol();
    $scope.dateStamp = mycampaignData0.getCampDate();



    $scope.newsletter = null;
    $scope.senders = [];
    $scope.subjects = [];
    $scope.showingTest = 0;



    $http({
        method: 'POST',
        url: "users/getNewsLetter",
        data: {
            'nlId': parseInt($scope.nlmId),
        }
    }).then(function successCallback(response) {

        if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
            window.location.href = "./";
        } else {
            if (response.data.error) {
                console.log(response.data.error)
                alert(response.data.error);
            } else if (response.data.success) {

                $scope.newsletter = response.data.success;


                for (sn in $scope.newsletter.SN) {
                    if (typeof $scope.newsletter.SN[sn] != "function") {
                        $scope.senders.push($scope.newsletter.SN[sn]);
                    }
                }

                $scope.sender = $scope.senders[0];

                for (sl in $scope.newsletter.SL) {
                    if (typeof $scope.newsletter.SL[sl] != "function") {
                        $scope.subjects.push($scope.newsletter.SL[sl]);
                    }
                }


                $scope.subject = $scope.subjects[0];


                var myEl = angular.element(document.querySelector('#creative'));
                myEl.html($scope.newsletter.creative);


                $scope.fckValue = 0;

                var oFCKeditor = new FCKeditor('creative');
                //alert("ctrl3 called");
                $scope.fckeditor = function(){
                    //alert("fckeditor  ");
                    if($scope.fckValue<1){

                        oFCKeditor.BasePath = "/FCKeditor_2.0rc3/";
                        oFCKeditor.Width = 700;
                        oFCKeditor.Height = 500;
                        oFCKeditor.ProcessHTMLEntities = false;
                        oFCKeditor.ReplaceTextarea();
                        $scope.fckValue++;

                    }
                    else{
                        var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
                        oEditor.SetHTML($scope.newsletter.creative);
                    }

                }
                $scope.fckeditor();




                $scope.nTags = [];
                $scope.newsTagIds = 0;
                for (i = 0; i < $scope.newsletter.tags.length; i++) {
                    //$scope.newsTagIds.push(res.data.tags[i]);
                    $scope.newsTagIds = $scope.newsletter.tags[i];
                    $http({

                        method: 'GET',
                        url: '/users/getNewsTags1/' + $scope.newsTagIds

                    }).then(
                        function successCallBack(res) {
                            // console.log("response ");
                            // console.log(res);
                            //console.log("response of campaingn7 ctrl" + res);
                            $scope.news1Tags = res.data;

                            //  console.log("res.data.name...." + res.data.id);

                            $scope.nTags.push({"name": res.data.name, "id": res.data.id});
                            /*$scope.tagIn.push({"text":res.data.name, "id":res.data.id});*/

                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });
                }


                $scope.nBrands = [];
                $scope.newsBrandIds = 0;
                if(typeof $scope.newsletter.tBrands != 'undefined'){
                    for (i = 0; i < $scope.newsletter.tBrands.length; i++) {
                        //$scope.newsTagIds.push(res.data.tags[i]);
                        $scope.newsBrandIds = $scope.newsletter.tBrands[i];

                        $http({

                            method: 'GET',
                            url: '/users/getNewsTags1/' + $scope.newsBrandIds


                        }).then(
                            function successCallBack(res) {
                                // console.log("response ");
                                // console.log(res);
                                // console.log("response of campaingn7 ctrl" + res);
                                $scope.brand1Tags = res.data;

                                // console.log("res.data.name...." + res.data.id);

                                $scope.nBrands.push({"name": res.data.name, "id": res.data.id});


                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }}

                $scope.ntPRs = [];
                $scope.newstPrIds = 0;
                if(typeof $scope.newsletter.tPR != 'undefined'){
                    for (i = 0; i < $scope.newsletter.tPR.length; i++) {
                        //$scope.newsTagIds.push(res.data.tags[i]);
                        $scope.newstPrIds = $scope.newsletter.tPR[i];

                        $http({

                            method: 'GET',
                            url: '/users/getNewsTags1/' + $scope.newstPrIds

                        }).then(
                            function successCallBack(res) {
                                // console.log("response ");

                                //  console.log("res.data.name...." + res.data.id);

                                $scope.ntPRs.push({"name": res.data.name, "id": res.data.id});

                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }
                }

                $scope.nCatTags = [];
                $scope.catIds = 0;
                if (typeof $scope.newsletter.targets.catTags != 'undefined')
                {
                    for (i = 0; i < $scope.newsletter.targets.catTags.length; i++) {

                        $scope.catIds = $scope.newsletter.targets.catTags[i];

                        $http({

                            method: 'GET',
                            url: '/users/getNewsTags1/' + $scope.catIds


                        }).then(
                            function successCallBack(res) {

                                $scope.nCatTags.push({"name": res.data.name, "id": res.data.id});

                            },
                            function errorCallBack(res) {
                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }
                }

                var idObj = {countryId:$scope.newsletter.targets.country};
                $http({

                    method: 'POST',
                    url: '/users/getCountriesById/',
                    data:idObj

                }).then(
                    function successCallBack(res) {

                        //  console.log("getCountriesById  res  :  "+JSON.stringify(res.data),"    and  :  ",res.data.data.name);
                        $scope.newsletter.country=res.data.data.name;

                    },
                    function errorCallBack(res) {

                        //alert("error");
                        console.log("error in tags");
                        return res.data;

                    });
                var idObj = {eDomain:$scope.newsletter.targets.eDomain};
                $http({

                    method: 'POST',
                    url: '/users/getEdomainById/',
                    data:idObj

                }).then(
                    function successCallBack(res) {

                        // console.log("getEdomainById  res  :  "+JSON.stringify(res.data)," and name  :  ",res.data.name);
                        $scope.newsletter.eDomain=res.data.name;
                        //  console.log("$scope.newsletter.eDomain   :  "+$scope.newsletter.eDomain);
                    },
                    function errorCallBack(res) {

                        //alert("error");
                        console.log("error in tags");

                        return res.data;
                    });

                if(typeof $scope.newsletter.targets.city != 'undefined'){
                    var idObj = {cityIds:$scope.newsletter.targets.country};
                    $http({

                        method: 'POST',
                        url: '/users/getCityByIds/',
                        data:idObj

                    }).then(
                        function successCallBack(res) {

                            //  console.log("getcityById  res  :  "+JSON.stringify(res.data));
                            $scope.newsletter.city=res.data.data;

                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });
                }

            } else {

            }

        }
    }, function errorCallback(response) {
        alert('error5' + response);
    });

    $scope.showSubjects = false;
    $scope.selectSubject = function (bool,v) {
        //alert(bool);
        $scope.showSubjects = bool;
        $scope.subject=v;
    }


    $scope.showSender = false;
    $scope.selectSender = function (bool,v) {
      // alert(bool);
        $scope.showSender = bool;
        $scope.sender=v;
    }

    $scope.showLoading = false;

    $scope.sendTestMailIn = function () {

        $scope.showLoading = true;

        $scope.domainObj = [];

        //alert("Testmail in STARTCAMPAIGN");

        $scope.showingTest = 1;

        var flag=false;
        //var value = document.getElementById('sendtestemailid').value;
        var value = $scope.testMailInput;
        //alert(value);
        var duplicatesArray = new Array();
        var uniqueArray = new Array();
        value = value.replace(/ /g, "");
        if (value.indexOf(",") !== -1) {
            var result = value.split(",");
            $scope.emailIdLength = result.length;
            //alert("result  :  "+result);
            if (result.length <= 1000) {
                for (var i = 0; i < result.length; i++) {
                    var actualEmail = result[i];
                    actualEmail = $.trim(actualEmail);
                    if (actualEmail != "") {
                        if (!validateEmail(actualEmail)) {
                            alert(actualEmail + " is invalid email Id.Please enter valid email Id");
                            flag = false;
                            break;
                        } else {
                            duplicatesArray.push(actualEmail.toLowerCase());
                            flag = true;
                        }
                    } else {
                        alert("Invalid email Id.Please remove comma at the end");
                        flag = false;
                        break;
                    }

                }

            } else {
                alert("Only 10 email Id's seperated by comma are allowed");
            }

        } else {
            $scope.emailIdLength = 1;
            if (!validateEmail(value)) {
                alert(value + " is invalid email Id.Please enter valid email Id");
                flag = false;
            } else {
                flag = true;
            }

        }

        function validateEmail(sEmail) {
            var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (filter.test(sEmail)) {
                return true;
            }
            else {
                return false;
            }
        }

        if (flag == true) {

            var ids = "";
            var c = document.getElementsByName('listgroup');
            var totd=0;
            for (var i = 0; i < c.length; i++)
            {
                // alert("c[i].id  : "+c[i].id);
                if (c[i].checked) {
                    $scope.domainObj.push({id:c[i].id,vol:$scope.emailIdLength})
                    ids = ids + c[i].id + ",";
                    totd++;
                }
                else
                {
                }
            }


            var d1 = new Date();
            var date1 = d1.setHours(0, 0, 0,0);
            var startOn =  date1/ 1000;

            var id = $cookieStore.get("userid");

            var oFCKeditor = new FCKeditor('creative');
            var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
            var cont = oEditor.GetHTML();


            var obj = {

                "nlmId": $scope.nlmId,
                "campId": $scope.newsletter.campId,
                "userId": $scope.userId,
                "SN": $scope.sender,
                "SL": $scope.subject,
                "creative": cont,
                "domains": $scope.selection,
                "emails": [$scope.testMailInput],
                "startAt": $scope.newsletter.startOn,
                "totalVol": parseInt($scope.emailIdLength)*parseInt(totd),
                "domainWise": $scope.domainObj,
                "tempVol": $scope.emailIdLength,
                "dateStamp": startOn

            };


            //console.log("sendTestMailIn  : "+JSON.stringify(obj));

            $scope.testMailInput = "";
            console.log('test mail will be sent')

            var id = $cookieStore.get("userid");
            if (id === undefined || ( JSON.stringify(id).indexOf('null') > -1)) {
                window.location.href = "./";
            } else {

                //alert("calling testmail:  " + JSON.stringify(obj));
                $http({
                    method: 'POST',
                    url: "users/createTestNews",
                    data: obj
                }).then(function successCallback(response) {
                    //alert(JSON.stringify(response));

                    if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1)
                    {
                        window.location.href = "./";
                    } else {

                        if(response.data.error == "campaign sent successfully !")
                        {
                            alert("Test Mail Sent Successfully");
                        }
                        else{
                            alert(response.data.error);
                        }
                        $scope.showLoading = false;

                        //$scope.selection=[];

                        $('#myModal1').modal('hide');


                    }
                }, function errorCallback(response) {
                    $scope.selection=[];
                    alert('error4' + response);
                })

            }
        }
        else {
            //alert(" improper data");
            $('#myModal1').modal('show');
            // $scope.showingTest = 0;
        }

        //alert($scope.showingTest)
    }

    $scope.exceedPick = false;
    $scope.pushUp =$scope.pickVol-$scope.sentVol;
    $scope.exceedIndex=-1;
    $scope.closeExceed = function()
    {
        //alert("closeExceed");
        $scope.pushUp =$scope.pickVol-$scope.sentVol;
        $scope.exceedPick = false;
    }


    $scope.takeVol = [];
    $scope.checkBoxes = [{id:'',vol:''}];

    $scope.pushUp = $scope.pickVol-$scope.sentVol;
    $scope.exceedVol = [];
    $scope.negVol = [];

    $scope.checkPickVol=function(ipVal,y,index,x)
    {


        /* alert("ipVal  : "+ipVal+" y: "+y+" index : "+index);
         alert($scope.taskselection.indexOf(y));
         alert($scope.taskselection.indexOf(y) != -1);
         alert(typeof ipVal != 'undefined');*/


/*
        if($scope.taskselection.indexOf(y) != -1 && typeof ipVal != 'undefined'){
            $scope.takeVol.push({id:y,vol:ipVal});
        }else {
        }*/

        if(ipVal==null || ipVal <0 || ipVal > $scope.pushUp || ipVal == ''){
            $scope.emptyVol=true;

            if(ipVal < 0)
            {
                $scope.negVol[index] = true;
            }
            else {
                $scope.negVol[index] = false;
            }
            if(ipVal > $scope.pushUp)
            {
                $scope.exceedVol[index] = true;

            }
            else {
                $scope.exceedVol[index] = false;
            }
        }
        else {
            $scope.emptyVol=false;
        }


        if(x){
            if(typeof $scope.checkBoxes[index].vol!="undefined")
            $scope.validIp.push(x);
        }
        else if($scope.validIp!=[]){

            $scope.validIp.pop(x);
        }


    }



    $scope.taskselection = [];
    $scope.validIp = [];

    $scope.changedTask = function (x, y,index) {
         /*alert(x+" and y is  "+y+" takeSEl  "+$scope.taskselection.indexOf(y));
*/
        $scope.exceedIndex = index;

        if($scope.pushUp<0){$scope.exceedPick = true;}
        else{
            $scope.exceedPick = false;}

        if(!x)
        {
            $scope.checkBoxes[index] = "";
            $scope.emptyVol[index]=false;
        }

        if(x){
            if(typeof $scope.checkBoxes[index].vol != "undefined"){

            $scope.validIp.push(x);

            }
        }
        else if($scope.validIp!=[]){

            $scope.validIp.pop(x);
        }

        if(x){

            if($scope.taskselection.indexOf(y)==-1)
            {
                $scope.taskselection.push(y);
            }

            var obj = {userId:$scope.userId,nlmId:$scope.nlmId,sentOn:$scope.newsletter.startOn}

            $http({
                method: 'POST',
                url: 'users/checkDomain',
                data: obj
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    var obj=response.data;
                    // console.log("obj checkDomain  :  ",obj,"  obj.length   :  ",obj.length);
                    if(obj.length != 0)
                    {
                        alert("domain already exist");
                    }
                }

            }, function errorCallback(response) {
                console.log('error');
                console.log(response);
            });


        }


    }

    $scope.emptyVol = false;
    $scope.showLoading = false;


    $scope.volBoxes = [];

    function removeNull(ele) {
        if(ele != "")
        if (typeof ele.vol != "undefined")
        {
            if(ele.vol != 0)
            {
                return ele;
            }
        }
    }


    $scope.startMailing = function() {

        /*alert("$scope.checkBoxes :  "+JSON.stringify($scope.checkBoxes));*/
        $scope.takeVol = $scope.checkBoxes.filter(removeNull);

        //alert("takeVol   :  " + JSON.stringify($scope.takeVol));
        checkDomVol($scope.takeVol)

    }


    function checkDomVol(vol)
    {
        /*alert("json.vol : "+JSON.stringify(vol));*/
        $scope.temp1=0;
       vol.forEach(function (obj) {
           if(obj.vol>=0){
            $scope.temp1 = $scope.temp1 + obj.vol;}
            else {$scope.temp1 = $scope.pushUp ;
           }
        });

       startMailing1(vol)
    }

    function startMailing1(takeVol)
    {


        if($scope.temp1<=$scope.pushUp && $scope.temp1>0){

            $scope.showLoading = true;
        if (takeVol.length !=0) {

            $scope.temp = 0;
            $scope.tempTake = takeVol;
            $scope.tempTake.forEach(function (obj) {
                $scope.temp = $scope.temp + obj.vol;
            });
            //!************* TestNews Create **********************



            //console.log("JSON.stringify(newsletter)  :  "+JSON.stringify($scope.newsletter));

            var oFCKeditor = new FCKeditor('creative');
            var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
            var cont = oEditor.GetHTML();



            var objTest = {
                newsName:$scope.newsletter.title,
                agentName: $cookieStore.get('userName'),
                userRelId:$scope.newsletter.userRel.id,
                campId: $scope.newsletter.campId,
                nlmId: $scope.nlmId,
                SN: $scope.sender,
                SL: $scope.subject,
                creative: cont,
                startAt: $scope.newsletter.startOn,
                userId: $scope.userId,
                totalVol: $scope.temp,
                domainWise: takeVol,
                tempVol: $scope.temp,
                dateStamp: $scope.dateStamp
            }



            //console.log("objTest  : "+JSON.stringify(objTest));

            //alert("OBJECT Of STARTMAIL  :  "+JSON.stringify(objTest.domainWise));
            $http({
             method: 'POST',
             url: 'users/createTestNews',
             data: objTest
             }).then(function successCallback(response) {
             if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
             window.location.href = "./";
             } else {

             var obj=response.data;
             alert(response.data.error);

             $scope.showLoading = false;

             $scope.pushUp = $scope.pickVol - $scope.sentVol;
             $scope.exceedPick = false;
             $("#myModal").modal('hide');

             window.location.href = "#users/mycampaigns";

             }

             },function errorCallback(response){
             $scope.showLoading = false;
             console.log('error');
             console.log(response);

             $("#myModal").modal('hide');
             });


        }
        else {

            $scope.emptyVol = true;
            $("#myModal").modal('show');
        }

        }
        else
        {
            alert("Volume is greater than Push Volume or invalid volume");
            $scope.checkBoxes = [];
        }
    }


    $scope.startTest = false;

    $scope.getUserDomain = function(){

        $http({
            method: 'POST',
            url: 'users/getUserDomain',
            data: {
                "userId": $scope.userId
            }
        }).then(function successCallback(response) {
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {
                var obj=response.data;
                $scope.userDomains=obj.data;
                // console.log("getUserDomain:   ",$scope.userDomains);
            }

        }, function errorCallback(response) {
            console.log('error');
            console.log(response);
        });
    }

    $scope.getUserDomain();

    $scope.startCampaign = function () {

        $scope.showLoading = false;
        //alert("startCampaign 1111");
        $scope.getUserDomain();
        $scope.startTest = true;
        var obj = {
            "id": parseInt(id),
            "nlmId": $scope.nlmId,
            "SN": $scope.sender,
            "SL": $scope.subject
        }
        // console.log('will start the campaign');
        // console.log(obj);
        var id = $cookieStore.get("userid");
        if (id === undefined || ( JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {

        }

    }

}]);

sampleApp.controller('campaigns-controller', ['$scope', '$cookies', '$cookieStore', '$window', '$http', function ($scope, $cookies, $cookieStore, $window, $http)
{

    $scope.var = 1;
    $scope.showingTest = 0;
    $scope.campId = 1;
    $scope.campaigns = null;
    $scope.testMailInput = "";
    $scope.testSender = "";
    $scope.testSubject = "";
    var id = $cookieStore.get("userid");

    if (id === undefined || ( JSON.stringify(id).indexOf('null') > -1)) {
        window.location.href = "./";
    } else {
        $http({
            method: 'POST',
            url: "users/getMyCampaigns",
            data: {
                'id': parseInt(id),
            }
        }).then(function successCallback(response) {
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {
                if (response.data.error) {
                    console.log(response.data.error)
                    alert(response.data.error);
                } else if (response.data.success) {
                    //console.log(response)
                    $scope.campaigns = response.data.success;

                } else {
                }
            }
        }, function errorCallback(response) {
            alert('error6' + response);
        })

    }

    $scope.showTestMail = function (campid, sender, subject) {
        $scope.showingTest = campid;
        $scope.testSender = sender;
        $scope.testSubject = subject;
        //alert('showing :: ' + $scope.showingTest)
    }

    $scope.closeTestMail = function () {
        $scope.showingTest = 0;
        //alert('hi')
    }

    $scope.sendTestMail = function () {
        alert("111111");

        var id = $cookieStore.get("userid");
        var obj = {
            "email": $scope.testMailInput,
            "subject": $scope.testSubject,
            "sender": $scope.testSender,
            "campId": parseInt($scope.showingTest),
            "id": parseInt(id)
        }
        $scope.testMailInput = "";
        console.log('test mail will be sent')
        // console.log(obj);
        var id = $cookieStore.get("userid");
        if (id === undefined || ( JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {
            $http({
                method: 'POST',
                url: "users/sendTestMail",
                data: obj
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (response.data.error) {
                        console.log(response.data.error)
                        alert(response.data.error);
                    } else if (response.data.success) {
                        //console.log('success @sendTestMail')
                        // console.log(response.data.success);
                        //return true;
                        $scope.closeTestMail();
                    } else {

                    }

                }
            }, function errorCallback(response) {
                alert('error7' + response);
            })

        }

    }

}]);


sampleApp.directive('myLink', function () {
    return {
        restrict: 'A',
        scope: {
            enabled: '=myLink'
        },
        link: function (scope, element, attrs) {
            element.bind('click', function (event) {
                if (!scope.enabled) {
                    event.preventDefault();
                }
            });
        }
    };
});





sampleApp.controller('home-controller', ['$cookieStore','$rootScope','$notification','$log','$location','socket','$interval','$scope', '$http','$q', '$cookies', '$cookieStore', '$window','$timeout' ,function ($cookieStore,$rootScope,$notification,$log,$location,socket,$interval,$scope, $http,$q,$cookies, $cookieStore, $window, $timeout)
{

    $scope.iconClick = function () {
        //alert("iconClick home");
        var element = document.getElementById("datePicker5");
        element.focus();
    }

    $scope.childmethod = function(now) {
        var date = new Date(now);
        $rootScope.date2Day = date.setHours(0,0,0,0);
        $rootScope.$emit("CallParentMethod");
    }

    socket.on('notification', function(data) {
        alert("notify");
        $scope.$apply(function () {

            alert("notification data "+JSON.stringify(data));

        });
    });





    $http({
        method: 'POST',
        url: 'users/getUser',
        data: {
            'id': $cookieStore.get("userid")
        }
    }).then(function successCallback(response) {
        if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
            window.location.href = "./";
        } else {

            if (response.data.error) {
                console.log("reports getUSER erro : ",response.data.error)
                //alert(response.data.error);
            } else if (response.data.success) {

                //console.log("reports res success :  ",response.data.success);
                $scope.userName  =  response.data.success.name;
                $cookieStore.put('userName',response.data.success.name);
            }
        }
    }, function errorCallback(response) {
        alert('error');
    });




    $scope.getCount = function () {

        $http({
            method: 'POST',
            url: 'users/getUser',
            data: {
                'id': $cookieStore.get("userid")
            }
        }).then(function successCallback(response) {
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {

                if (response.data.error) {
                    console.log("reports getUSER erro : ",response.data.error)
                    //alert(response.data.error);
                } else if (response.data.success) {

                    //console.log("reports res success :  ",response.data.success);
                    $scope.userName  =  response.data.success.name;
                    $cookieStore.put('userName',response.data.success.name);
                }
            }
        }, function errorCallback(response) {
            alert('error');
        });


    }



    /*$scope.infoNotification = function() {
     alert("infoNotification called");
     var obj= {type:"info"};

     $http({

     method: 'POST',
     url: '/users/alertNotification',
     data:obj

     }).then(
     function successCallBack(res) {

     console.log("response alertNotification "+JSON.stringify(res));
     console.log("response alertNotification "+JSON.stringify(res.data.data));
     $timeout(function(){
     $scope.flagAlert = true;},5000);

     },
     function errorCallBack(res) {

     console.log("error in tags");
     return res.error;

     });
     }
     $scope.infoNotification();
     */

    $scope.delay = 2000;
    $scope.campaignSuccess = function(desc)
    {
        var notification = $notification('New message', {
            body: desc,
            icon: 'http://trueapp.in/img/logo.png',
            delay: $scope.delay
        });
        $scope.delay = $scope.delay + 1000;

    }


    $scope.alertData=[];
    //$scope.campaignSuccess();
    $scope.alertNotification = function() {

        var obj= {type:"alert"};

        $http({

            method: 'POST',
            url: '/users/alertNotification',
            data:obj

        }).then(
            function successCallBack(res) {

                $scope.alertData = res.data;
                //console.log("JSON.stringify($scope.alertData) :  " + JSON.stringify($scope.alertData));

                if($scope.alertData != ''){
                    console.log("alertData not null");
                for (var t = 0; t < $scope.alertData.length; t++) {
                    var i = 0;
                    while ($scope.alertData[t].users.length > i) {
                        if ($scope.alertData[t].users[i]._id == $cookieStore.get("userid")) {
                            if ($scope.alertData[t].users[i].readOn == 0) {
                                $scope.campaignSuccess($scope.alertData[t].desc);
                                $scope.updateDesktopNotify($scope.alertData[t].id);
                            }
                        }
                        i++;
                    }
                }
            }

            },
            function errorCallBack(res) {

                console.log("error in tags");

            });
    }

    $scope.updateDesktopNotify = function (notifId) {

        $http({

            method: 'POST',
            url: '/users/updateDesktopNotify',
            data:{notifId:notifId}

        }).then(
            function successCallBack(res) {

                console.log("updateNotification updated successfully");
            },
            function errorCallBack(res) {

                console.log("error in tags");

            });

    }




    $scope.updateNotification = function(id) {

        //alert("alert called");
        var obj= {notifId:id};

        $http({

            method: 'POST',
            url: '/users/updateNotification',
            data:obj

        }).then(
            function successCallBack(res) {

                /* console.log("response updateNotification "+JSON.stringify(res));
                 console.log("response updateNotification "+JSON.stringify(res.data));*/
                $scope.alertNotification();
            },
            function errorCallBack(res) {

                console.log("error in tags");
                return res.error;

            });
    }
    $interval(function () {
        $scope.alertNotification();
    }, 15000);



    /*     $scope.activityLog = function() {

     alert("activity log called");
     $scope.limit=11;

     $http({

     method: 'GET',
     url: '/users/activityLog/'+$scope.limit

     }).then(
     function successCallBack(res) {

     console.log("response activityLog "+JSON.stringify(res));
     console.log("response activityLog "+JSON.stringify(res.data.data));
     $timeout(function(){
     $scope.flagActivity = true;},5000);

     },
     function errorCallBack(res) {

     console.log("error in tags");
     return res.error;

     });

     }
     $scope.activityLog();*/

    //alert("home-controller");

    //$window.location ='#/users/dashboard';

    (function() {
        var docElem = window.document.documentElement, didScroll, scrollPosition;

        // trick to prevent scrolling when opening/closing button
        function noScrollFn() {
            window.scrollTo( scrollPosition ? scrollPosition.x : 0, scrollPosition ? scrollPosition.y : 0 );
        }

        function noScroll() {
            window.removeEventListener( 'scroll', scrollHandler );
            window.addEventListener( 'scroll', noScrollFn );
        }

        function scrollFn() {
            window.addEventListener( 'scroll', scrollHandler );
        }

        function canScroll() {
            window.removeEventListener( 'scroll', noScrollFn );
            scrollFn();
        }

        function scrollHandler() {
            if( !didScroll ) {
                didScroll = true;
                setTimeout( function() { scrollPage(); }, 60 );
            }
        };

        function scrollPage() {
            scrollPosition = { x : window.pageXOffset || docElem.scrollLeft, y : window.pageYOffset || docElem.scrollTop };
            didScroll = false;
        };

        scrollFn();

        [].slice.call( document.querySelectorAll( '.morph-button' ) ).forEach( function( bttn ) {
            new UIMorphingButton( bttn, {
                closeEl : '.icon-close',
                onBeforeOpen : function() {
                    // don't allow to scroll
                    noScroll();
                },
                onAfterOpen : function() {
                    // can scroll again
                    canScroll();
                },
                onBeforeClose : function() {
                    // don't allow to scroll
                    noScroll();
                },
                onAfterClose : function() {
                    // can scroll again
                    canScroll();
                }
            } );
        } );

        // for demo purposes only
        [].slice.call( document.querySelectorAll( 'form button' ) ).forEach( function( bttn ) {
            bttn.addEventListener( 'click', function( ev ) { ev.preventDefault(); } );
        } );
    })();

    var loginId = $cookieStore.get("userid");

    if(typeof(loginId) == "undefined"){
        //alert(loginId);
        //alert("loginid");
        $window.location = '/';
    }
//code to get the data for left and main menu

    $scope.loadHttp = function(){
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: 'users/getMenu'
        }).then(function successCallback(response) {
            //alert(JSON.stringify(response));
            if (response) {
                deferred.resolve(JSON.stringify(response.data));
            } else {
                deferred.reject(JSON.stringify(response.data));
            }

        }, function errorCallback(response) {

        });

        return deferred.promise;

    }
    var promise = $scope.loadHttp();
    promise.then(function(res) {
        $scope.options = JSON.parse(res);
        $scope.selectedOption = $scope.options[2];
        $scope.selectedName=$scope.options[0];
        $scope.changeSelect($scope.selectedName)
        // console.log("options : 8126 "+JSON.stringify($scope.options));
        $scope.monitoringDiv = false;
        $scope.options.forEach(function (obj) {
            if(obj.name=='Monitor')
            {
                $scope.monitoringDiv = false;
            }
        });


        var leftPage = $scope.loadLeft();
        leftPage.then(function(res) {
            $scope.leftMenu = JSON.parse(res);
            //alert("leftMenu "+JSON.stringify($scope.leftMenu));

        }, function(reason) {
            //alert('Failed: ' + reason);
        });

    }, function(reason) {
        // alert('Failed: ' + reason);
    });

    $scope.tempPath='';



    $scope.reloadLocation = function(path,index)
    {
        $scope.activeClass = [];
        $scope.activeClass[index]="active";
        //alert("reloadLocation  "+path+" index "+index);
        var path = '#users/'+path;
        //console.log(path);
        window.location.href=path;

    }

    $scope.loadLeft = function(){
        var menuType=$scope.selectedOption;
        //alert("menutype : "+menuType.name);
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: 'users/leftMenu/'+menuType.id
        }).then(function successCallback(response) {
            //alert(JSON.stringify(response));
            if (response) {
                //alert("success "+JSON.stringify(response.data));
                deferred.resolve(JSON.stringify(response.data));
                // $scope.loadRight(1);
            } else {
                //alert("error "+JSON.stringify(response.data));
                deferred.reject(JSON.stringify(response.data));
            }

        }, function errorCallback(response) {
        });
        return deferred.promise;
    }

//code to get dashboard

    /*$scope.loadRight = function(index){
     // alert("loadRIght : "+index);
     var deferred = $q.defer();
     $http({
     method: 'POST',
     url: '/campaignDiv/:'+index
     }).then(function successCallback(response) {
     //alert(JSON.stringify(response));
     if (response) {

     deferred.resolve(JSON.stringify(response.data));
     } else {

     deferred.reject(JSON.stringify(response.data));
     }

     }, function errorCallback(response) {
     //alert("error : "+JSON.stringify(response));
     });

     return deferred.promise;

     }
     var index=1;
     var promise = $scope.loadRight(index);
     promise.then(function(res) {
     //alert("promise successful : "+res);
     $scope.campaignList = JSON.parse(res);
     }, function(reason) {
     //alert('Failed: ' + reason);
     });
     */

    $scope.disOptDiv = false;
    $scope.disOptDivFun = function () {


        $scope.disOptDiv = true;
    }

    $scope.changeSelect = function(menuType)
    {
        // alert("menutype "+JSON.stringify(menuType));
        if(menuType.name=='Mailing')
        {
            window.location.href = "#users/today";
        }
        if(menuType.name=='Domain')
        {
            window.location.href="#users/alldomains";
        }
        if(menuType.name=="Retarget")
        {
            window.location.href="#users/CreateCampaignR";
        }
        if(menuType.name=="Data")
        {
            window.location.href="#users/datastats";
        }


        $scope.disOptDiv = false;
        $scope.selectedOption = menuType;
        $scope.selectedName = menuType;
        //alert(menuType);
        $timeout(function(){

            var leftPage = $scope.loadLeft();
            leftPage.then(function(res) {
                $scope.leftMenu = JSON.parse(res);
                //alert("leftMenu "+JSON.stringify($scope.leftMenu));

            }, function(reason) {
                //alert('Failed: ' + reason);
            });

        },50)

    }


    //code for viewMain
    $scope.addMenu = function(newMenu)
    {
        alert("newMenu : "+newMenu);
        $http({
            method: 'POST',
            url: 'users/addMenu/'+newMenu
        }).then(function successCallback(response) {

            // console.log("success : ",JSON.stringify(response.data));
            $scope.options = response.data;
            $window.location.reload();
            //$scope.newMenu="";


        }, function errorCallback(response) {

            console.log("error ",response);

        });
    }



    //code for viewMain

    $scope.pageSet = 0;
    $scope.changeSub = function(newMenu)
    {

        alert("newMenu : "+newMenu);
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: 'users/leftMenu/'+newMenu
        }).then(function successCallback(response) {
            //alert(JSON.stringify(response));
            if (response) {

                $scope.subMenu = response.data;
                alert("$scope.subMenu  ; "+$scope.subMenu);
                //console.log(JSON.stringify($scope.subMenu));
                $scope.max = $scope.subMenu[0].order;

                for(var i=0;i<$scope.subMenu.length;i++)
                {
                    if($scope.subMenu[i].order>$scope.max)
                    {
                        $scope.max = $scope.subMenu[i].order;
                    }
                }

            } else {

                $scope.subMenu = JSON.stringify(response.data);
                alert("err submenu :  "+JSON.stringify(response.data));
                $scope.max = -1;
            }

        }, function errorCallback(response) {

        });

        return deferred.promise;


    }

    $scope.editMenu = function(menuId)
    {
        var obj={"menuId":menuId};
        alert(obj);
        $http({
            method: 'POST',
            url: 'users/editMenu/',
            data:obj
        }).then(function successCallback(response) {

            //console.log("success : ",JSON.stringify(response.data));

            $window.location.reload();

        }, function errorCallback(response) {
            console.log("error ",response);
        });

    }

    $scope.deleteMenu = function(menuId)
    {

        $http({
            method: 'POST',
            url: 'users/deleteMenu/'+menuId
        }).then(function successCallback(response) {

            $window.location.reload();
            //console.log("success : ",JSON.stringify(response.data));



        }, function errorCallback(response) {
            console.log("error ",response);
        });


    }



    $scope.addSub = function(newSub,pageSet)
    {

        alert("newSub : "+newSub+"   "+pageSet);
        var obj ={"newSub":newSub,"menuId":pageSet,"order":$scope.max+1};
        console.log("object  :   ",obj);
        $http({
            method: 'POST',
            url: 'users/addSub/',
            data:obj
        }).then(function successCallback(response) {

            //console.log("success : ",JSON.stringify(response.data));
            $scope.subMenu = response.data;

            $window.location.reload();
            //$scope.newMenu="";


        }, function errorCallback(response) {

            console.log("error ",response);

        });


    }

    $scope.editSub = function(subObj)
    {
        var obj={"subObj":subObj};
        alert(JSON.stringify(obj));
        $http({
            method: 'POST',
            url: 'users/editSub/',
            data:obj
        }).then(function successCallback(response) {

            // console.log("success : ",JSON.stringify(response.data));

            $window.location.reload();

        }, function errorCallback(response) {
            console.log("error ",response);
        });

    }

    $scope.deleteSub = function(subId)
    {
        var obj={"subId":subId};
        alert(JSON.stringify(obj));
        $http({
            method: 'POST',
            url: 'users/deleteSub',
            data:obj
        }).then(function successCallback(response) {

            // console.log("success : ",JSON.stringify(response.data));
            $window.location.reload();

        }, function errorCallback(response) {
            console.log("error ",response);
        });

    }


}]);

sampleApp.controller('campaign-view-controller', ['$scope', '$routeParams','$http','$q', '$cookies', '$cookieStore', '$window','$timeout' ,function ($scope,$routeParams, $http,$q,$cookies, $cookieStore, $window, $timeout) {


    $scope.recordExist = false;
    $scope.processing = false;

    if(typeof($routeParams.campName) != 'undefined')
    {
        alert("campName : "+$routeParams.campName);
        $scope.campName = $routeParams.campName;
        $scope.campId = $routeParams.campId;
        //$window.location ='#/users/step2/'+$scope.campName+'/'+$scope.campId;
    }
    $scope.regex ='^[a-zA-Z0-9_ !@$%&-.]*$';
    $scope.maxlength=100;


    var loginId = $cookieStore.get("userid");

    if(typeof(loginId)=="undefined")
    {
        $window.location=('#/');
    }


    $scope.createCampaign = function()
    {

        var obj={camp:$scope.campTitle
            ,userId:loginId}


        $scope.processing=true;

        $http({
            method: 'POST',
            url: 'users/createCamp/',
            data:obj
        }).then(function successCallback(response) {

            // console.log("success : ",response.data);
            if(response.data.length != 0 && typeof response.data.data != 'undefined')
            {
                var obj = response.data;
                var data = obj.data;
                var campId = data.id;
                //console.log("success : ",$scope.campName);

                $window.location ='#/users/step2/'+campId;
            }
            else if(response.data.message == "Record exists")
            {
                alert("Continuing with old Campaign");
                var obj = response.data;
                var data = obj.details;
                var campId = data.id;
                $window.location ='#/users/step2/'+campId;

            }
            else {
                $scope.processing=false;
                $scope.recordExist = true;
                // alert("record exist");
            }

        }, function errorCallback(response) {

            console.log("error ",response);

        });

    }


}]);

/*sampleApp.directive('datepicker', function() {
 return {
 link: function(scope, el, attr) {

 $(el).datepicker({

 dateFormat : 'yy-mm-dd',
 onSelect: function(dateText) {
 console.log(dateText);
 var expression = attr.ngModel + " = " + "'" + dateText + "'";
 scope.$apply(expression);
 console.log(scope.startDate);
 // how do i set this elements model property ?
 }

 });
 }
 };

 });*/


sampleApp.directive("datepicker", function () {
    return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, elem, attrs, ngModelCtrl) {
            var updateModel = function (dateText) {
                scope.$apply(function () {
                    ngModelCtrl.$setViewValue(dateText);
                });
            };
            var options = {
                dateFormat: "yy-mm-dd",
                onSelect: function (dateText) {
                    updateModel(dateText);
                }
            };
            $(elem).datepicker(options);
        }
    }
});

sampleApp.controller('campaignStep2Ctrl', ['$scope','$filter', '$routeParams','$http','$q', '$cookies', '$cookieStore', '$window','$timeout',function ($scope,$filter,$routeParams, $http,$q,$cookies, $cookieStore, $window, $timeout) {



    var campId = $routeParams.campId;
    /* $scope.regex ='^[a-zA-Z0-9_ ]*$';*/
    $scope.regex ='^[a-zA-Z0-9_ !@$%&-.]*$';
    $scope.maxlength=100;
    $scope.processing=false;

    var loginId = $cookieStore.get("userid");

    $http({

        method:'POST',
        url:'/users/getStep1/'+campId


    }).then(
        function successCallBack(res){
            //console.log("res  getStep1: ",JSON.stringify(res));
            var obj = res.data;
            var data = obj.data;
            $scope.campId = data.id;
            $scope.campName = data.name;
            // console.log($scope.campName);
            //console.log("res start");

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );




    $scope.showCamp = true;
    $scope.alterEdit = function()
    {
        $scope.showCamp = false;
    }
    $scope.editCampaign = function(camp)
    {
        var obj = {campName : $scope.campName,userId:loginId, campId : $scope.campId};
        $http({

            method:'POST',
            url : '/users/editCamp',
            data:obj
        }).then(function successCallBack(res){

                var obj = res.data;
                //console.log("obj");
                //  console.log(obj);
                var data = obj.data;
                var campName = data.$set.name;
                var campId = data.id;

                //   console.log(campName);
                //  $routeParams.campName =campName;
                // $routeParams.campId = campId;
                $window.location ='#/users/step2/'+campId;

            },
            function errorCallBack(res){
                console.log(res.data);
            })

        $scope.showCamp = true;

    }


    $scope.news={};
    $scope.news.scd = {};
    $scope.news.scd.d1 = $filter('date')(new Date(), "yyyy-MM-dd");
    $scope.news.scd.d2 = $filter('date')(new Date(), "yyyy-MM-dd");


    $scope.changeEndOn = function()
    {
        $scope.news.scd.d2 = $scope.news.scd.d1;
        //alert($scope.news.scd.d2);
    }

    $scope.addNews = function(news)
    {

        console.log("addNews1 for step2");

        var d1 = new Date(news.scd.d1);
        var date1 = d1.setHours(0, 0, 0,0);
        var startOn =  date1/ 1000;


        var d2 = new Date(news.scd.d2);
        var date2 = d2.setHours(0, 0, 0,0);
        var endOn =  date2/ 1000;


        //alert(endOn);
        if(parseInt(startOn)<=parseInt(endOn)){

            $scope.processing=true;

            var obj = {news:$scope.news,campId:$scope.campId,cBy:loginId,startOn:startOn,endOn:endOn};
            //alert(JSON.stringify(obj));
            $http({

                method:'POST',
                url : '/users/createNews',
                data:obj
            }).then(function successCallBack(res){

                    if(res.length<1){

                        $window.location.reload();
                    }
                    else{

                        var obj = res.data;

                        console.log("obj   ",JSON.stringify(obj));
                        if(obj.data != "Record exists") {
                            var news = obj.data;
                            // console.log(obj);

                            var newsId = news.id;
                            // console.log("newsId :  "+newsId);

                            $window.location = "#/users/step3/" + $scope.campId + '/' + newsId;
                        }
                        else{
                            alert("Newsletter name already exist");
                            $scope.processing=false;
                        }
                    }

                },
                function errorCallBack(res){
                    console.log("Error  :  ",JSON.strigify(res));
                    //console.log(res.data);
                })

        }
        else {
            $scope.processing=false ;
            console.log("error in createNews line:2368");
            //alert("EndOn Date must be greater than StartOn Date");
        }
        $scope.showCamp = true;
    }



}]);

sampleApp.controller('campaignStep3Ctrl', ['$filter','fileUpload','$scope', '$routeParams','$http','$q', '$cookies', '$cookieStore', '$window','$timeout' ,function ($filter,fileUpload,$scope,$routeParams, $http,$q,$cookies, $cookieStore, $window, $timeout) {


    $scope.myHtml = "<h1>Hello World</h1>";
    $scope.froalaOptions = {
        toolbarButtons : ["bold", "italic", "underline", "|", "align", "formatOL", "formatUL"]
    }

    $scope.radioModel = "upload";
    var campId = $routeParams.campId;
    $scope.campId = $routeParams.campId;
    $scope.processing=false;
    $scope.processEditCamp=false;
    $scope.processEditNews=false;


    /*    $scope.regex ='^[a-zA-Z0-9_ ]*$';*/
    $scope.regex ='^[a-zA-Z0-9_ !@$%&-.]*$';
    $scope.maxlength=100;
    var newsId = $routeParams.newsId;

    var loginId = $cookieStore.get("userid");




    $http({

        method:'POST',
        url:'/users/getStep1/'+$routeParams.campId


    }).then(
        function successCallBack(res){
            console.log(campId);
            var obj = res.data;
            //  console.log(obj);
            var data = obj.data;
            $scope.campName = data.name;
            //console.log($scope.campName);
            // console.log("NEWS STEP1 start");

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );


    $http({

        method:'POST',
        url:'/users/getStep2/'+newsId


    }).then(
        function successCallBack(res){

            var obj = res.data;
            var data = obj.data;
            console.log("news start : 1");
            console.log(new Date(data.startOn*1000));

            $scope.news={newsTitle:data.title,type:data.type,startOn:$filter('date')(new Date(data.startOn*1000),'yyyy-MM-dd')
                ,endOn:$filter('date')(new Date(data.endOn*1000),'yyyy-MM-dd'),roi:data.roi};

            //console.log($scope.news);
            console.log("news start");

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );


    $scope.showCamp = true;
    $scope.alterEdit = function()
    {
        $scope.showCamp = false;
    }

    $scope.showNews = true;
    $scope.alterNews = function()
    {
        $scope.showNews = false;
    }

    $scope.editCamp = function(){

        $scope.processEditCamp=true;

        var obj = {campName : $scope.campName,userId:loginId, campId : campId};
        $http({

            method:'POST',
            url : '/users/editCamp',
            data:obj
        }).then(function successCallBack(res){

                var obj = res.data;
                // console.log("obj");
                // console.log(obj);
                var data = obj.data;
                var campName = data.$set.name;
                var campId = data.id;

                // console.log(campName);
                //  $routeParams.campName =campName;
                // $routeParams.campId = campId;
                $window.location ='     #/users/step3/'+campId+'/'+newsId;
                $scope.showCamp = true;
            },
            function errorCallBack(res){
                console.log(res.data);
            })

    }


    $scope.editNews = function(news){

        $scope.processEditNews=true;
        var d1 = new Date(news.startOn);
        var date1 = d1.setHours(0, 0, 0,0);
        var startOn =  date1/ 1000;

        var d2 = new Date(news.endOn);
        var date2 = d2.setHours(0, 0, 0,0);
        var endOn =  date2/ 1000;



        if(startOn<=endOn){


            var obj = {title:news.newsTitle,campId:campId,type:news.type,roi:news.roi,cBy:loginId,startOn:startOn,endOn:endOn,newsId:newsId};
            //alert(obj);
            //console.log(obj);
            $http({

                method:'POST',
                url : '/users/editNews',
                data:obj
            }).then(function successCallBack(res){

                    var obj = res.data;
                    // console.log("obj");
                    // console.log(obj);
                    var data = obj.data;
                    // var campName = data.$set.name;



                    //  $routeParams.campName =campName;
                    // $routeParams.campId = campId;
                    $window.location ='#/users/step3/'+campId+'/'+newsId;
                    $scope.showNews = true;

                },
                function errorCallBack(res){
                    console.log(res.data);
                })
        }
        else {
            console.log("edit News error  line no:  5189");
            $scope.processEditNews=false;
            //alert("EndOn Date must be greater than StartOn Date");
        }

    }


    $scope.fckValue = 0;
    var oFCKeditor = new FCKeditor('editor');
    //alert("ctrl3 called");
    $scope.fckeditor = function(){
        //alert("fckeditor  ");
        if($scope.fckValue<1){

            oFCKeditor.BasePath = "/FCKeditor_2.0rc3/";
            oFCKeditor.Width = 700;
            oFCKeditor.Height = 500;
            oFCKeditor.ProcessHTMLEntities = false;
            oFCKeditor.ReplaceTextarea();
            $scope.fckValue++;

        }
        else{
            var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
            oEditor.SetHTML("");
        }

    }

    $scope.fckeditor();


    $scope.fileUndefined=false;
    $scope.fileNoZip = false;

    $scope.fileUpload = function () {

        var file = $scope.myFile;
        // alert("fileUPload  :  "+(typeof file=="undefined"));
        var file1 = document.getElementById("uploadFile");
        var fileName1=file1.value.toString();
        // alert("11111");
        if(fileName1.split('.').pop().toLowerCase() == "zip" ){
            //  if(typeof file=="undefined"){$scope.disableSave=true;}else{$scope.disableSave=false;}
            //  console.log('file is ' );
            // console.dir(file);

            var uploadUrl = "/users/uploadFile";
            fileUpload.async(file, uploadUrl).then(function(res){

                $scope.uploadDetails = res.data;
                $scope.fckmodel= res.data;
                //  console.log(res.data);
                //document.getElementById("editor").innerHTML(res.data);

                //alert(res.data);
                $scope.fckValue = 0;
                var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
                oEditor.SetHTML(res.data);
                $scope.radioModel='create';

            });


        }else if(typeof file=="undefined"){
            $scope.fileNoZip = false;
            $scope.fileUndefined=true;
            //alert("Please Select the file to be uploaded");
        }else{ $scope.fileNoZip = true;
            $scope.fileUndefined=false;
            //alert("Please Upload Only Zip File");
        }

    }

    $scope.fcmodelSpan = false;
    $scope.addStep3 = function()
    {

        console.log("editor");
        var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
        var cont = oEditor.GetHTML();
        $scope.editorContent=oEditor.GetHTML();
        //console.log("cont :: "+cont);
        // alert("cont  "+cont);
        //alert("fckmodel    :  "+cont);

        if(typeof cont == "undefined" || cont==''|| $scope.senderData=='' || $scope.subjectData== '' ||cont=='<br>')
        {
            if($scope.senderData!='' && $scope.subjectData!= ''){
                $scope.fcmodelSpan = true;
            }
            else {
                $scope.fcmodelSpan = false;
            }

            console.log("Incomplete data line no.:5278");
        }
        else{
            $scope.processing=true;
            var obj ={SN:$scope.senderData,SL:$scope.subjectData,cBy:loginId,newsId:newsId, creative:cont,status:-5};
            console.log("obj : "+obj);

            $http({

                method:'POST',
                url : '/users/updateStep3',
                data:obj

            }).then(function successCallBack(res){

                    if(res.length<1){
                        $window.location.reload();
                    }
                    else{
                        $window.location ="#/users/step4/"+campId+'/'+newsId;
                    }

                },
                function errorCallBack(res){
                    console.log(res.data);
                    $scope.processing=false;
                })
        }
    }

    $scope.senderData = [];
    var i=0;

    $scope.senderSubmit= false;
    $scope.addSender = function(senderName)
    {
        if(senderName!='' && senderName != null && $scope.senderData.length<3){
            $scope.senderData.push(senderName);
            $scope.senderName='';
        }
        if(senderName != null && senderName!='' )
        {    i++;
            if(i>3 && $scope.senderData.length==3){
                $scope.senderSubmit=true;}
            //alert("Sender Name limit exceed");
        }

    }
    $scope.subjectData = [];
    $scope.subjectSubmit=false;
    var j=0;
    $scope.addSubject = function(subject)
    {
        if(subject!='' && subject != null && $scope.subjectData.length<3){
            $scope.subjectData.push(subject);
            $scope.subject='';
        }
        if(subject != null && subject!='')
        {    j++;
            if(j>3 && $scope.subjectData.length==3){
                $scope.subjectSubmit=true;}
            //alert("Sender Name limit exceed");
        }
    }
    $scope.removeSender=function(index)
    {
        $scope.senderData.splice(index,1);
        $scope.senderSubmit=false;
    }
    $scope.removeSubject=function(index)
    {
        $scope.subjectData.splice(index,1);
        $scope.subjectSubmit=false;
    }



}]);




sampleApp.controller('campaignStep4Ctrl', ['$filter','$scope', '$routeParams','$http','$q', '$cookies', '$cookieStore', '$window','$timeout' ,function ($filter,$scope,$routeParams, $http,$q,$cookies, $cookieStore, $window, $timeout) {


    $scope.processing=false;
    var campId = $routeParams.campId;
    /*    $scope.regex ='^[a-zA-Z0-9_ ]*$';*/
    $scope.regex ='^[a-zA-Z0-9_ !@$%&-.]*$';
    $scope.maxlength=100;
    var newsId = $routeParams.newsId;
    $scope.campId = campId;
    $scope.newsId = newsId;

    //alert(campId);
    var loginId = $cookieStore.get("userid");

    $scope.regex2 = new RegExp('^[a-zA-Z0-9_ ]*$');
    /*$scope.regex2 ='^[a-zA-Z0-9_ !@$%&-.]*$';*/
    $scope.specialCharT = false;
    $scope.specialCharB = false;
    $scope.tagIn=[];
    $scope.brand=[];

    console.log("$scope.newsId ;  ",$scope.newsId);
    $http({

        method: 'GET',
        url: '/users/getNewsTags/'+$scope.newsId


    }).then(
        function successCallBack(res) {

            if(typeof res.data.tags != 'undefined')
            {

                // console.log("response ");
                //console.log(res);
                //console.log("response of campaingn6 ctrl" + JSON.stringify(res));
                $scope.newsTags = res.data.tags;
                $scope.brandsTags = res.data.tBrands;
                $scope.tPRTags = res.data.tPR;
                $scope.nTags = [];
                $scope.newsTagIds = 0;
                //console.log("res.data.tags  : ", res.data.tags);
                for (i = 0; i < res.data.tags.length; i++) {
                    //$scope.newsTagIds.push(res.data.tags[i]);
                    $scope.newsTagIds = res.data.tags[i];
                    $http({

                        method: 'GET',
                        url: '/users/getNewsTags1/' + $scope.newsTagIds

                    }).then(
                        function successCallBack(res) {
                            //  console.log("response ");
                            //  console.log(res);
                            // console.log("response of campaingn7 ctrl" + res);
                            $scope.news1Tags = res.data;

                            // console.log("res.data.name...." + res.data.id);

                            $scope.nTags.push({"name": res.data.name, "id": res.data.id});
                            $scope.tagIn.push({"text": res.data.name, "id": res.data.id});

                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });
                }
                //brands from newsletter
                $scope.nBrands = [];
                $scope.newsBrandIds = 0;
                if(typeof res.data.tBrands != 'undefined'){
                    for (i = 0; i < res.data.tBrands.length; i++) {
                        //$scope.newsTagIds.push(res.data.tags[i]);
                        $scope.newsBrandIds = res.data.tBrands[i];


                        $http({

                            method: 'GET',
                            url: '/users/getNewsTags1/' + $scope.newsBrandIds


                        }).then(
                            function successCallBack(res) {
                                //console.log("response ");
                                // console.log(res);
                                //console.log("response of campaingn7 ctrl" + res);
                                $scope.brand1Tags = res.data;

                                // console.log("res.data.name...." + res.data.id + "  res.data.name  :  ", res.data.name);

                                $scope.nBrands.push({"name": res.data.name, "id": res.data.id});
                                $scope.brand.push({"text": res.data.name, "id": res.data.id});

                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }}


                $scope.ntPRs = [];
                $scope.newstPrIds = 0;
                if(typeof res.data.tPR != 'undefined'){
                    for (i = 0; i < res.data.tPR.length; i++) {
                        //$scope.newsTagIds.push(res.data.tags[i]);
                        $scope.newstPrIds = res.data.tPR[i];


                        $http({

                            method: 'GET',
                            url: '/users/getNewsTags1/' + $scope.newstPrIds


                        }).then(
                            function successCallBack(res) {
                                // console.log("response ");

                                // console.log("res.data.name...." + res.data.id);

                                $scope.ntPRs.push({"name": res.data.name, "id": res.data.id});
                                var priceString = res.data.name;
                                var index = priceString.indexOf("-");
                                $scope.priceFrom = parseInt(priceString.slice(0, index));
                                $scope.priceTo = parseInt(priceString.slice(index + 1, priceString.length));

                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }}

            }
        },
        function errorCallBack(res) {

            //alert("error");
            console.log("error in tags");

            return res.data;
        });





    $http({

        method: 'POST',
        url: '/users/getTagsOnly/'

    }).then(
        function successCallBack(res) {
            // console.log("response ");
            // console.log(res);
            $scope.tags = res.data;
            // $scope.brand=[];
            $scope.tagNames = [];
            //$scope.tagIds = [];
            $scope.tags.forEach(function (obj) {
                //$scope.tagIds.push(obj.id);
                $scope.tagNames.push({"text": obj.name, "id": obj.id});
            });

            $scope.loadTags = function ($query) {
                //alert("tags")
                if($scope.regex2.test($query.toString())){
                    $scope.specialCharT = false;
                }
                else{$scope.specialCharT = true;}
                return $scope.tagNames.filter(function (tags) {
                    return tags.text.toLowerCase().indexOf($query.toLowerCase()) != -1;
                });

            };
            /* $scope.loadBrands = function ($query) {


             if($scope.regex2.test($query.toString())){
             $scope.specialCharB = false;
             }
             else{$scope.specialCharB = true;}
             return $scope.tagNames.filter(function (tags) {
             return tags.text.toLowerCase().indexOf($query.toLowerCase()) != -1;
             });

             };*/

        },
        function errorCallBack(res) {

            //alert("error");
            console.log("error in tags");

            return res.data;
        });

    $http({

        method: 'POST',
        url: '/users/getBrandsOnly/'

    }).then(
        function successCallBack(res) {
            //console.log("response ");
            //console.log(res);
            $scope.tags1 = res.data;
            // $scope.brand=[];
            $scope.tagNames1 = [];
            //$scope.tagIds = [];
            $scope.tags1.forEach(function (obj) {
                //$scope.tagIds.push(obj.id);
                $scope.tagNames1.push({"text": obj.name, "id": obj.id});
            });


            $scope.loadBrands = function ($query) {

                //alert("brands");
                if($scope.regex2.test($query.toString())){
                    $scope.specialCharB = false;
                }
                else{$scope.specialCharB = true;}
                return $scope.tagNames1.filter(function (tags) {
                    return tags.text.toLowerCase().indexOf($query.toLowerCase()) != -1;
                });

            };

        },
        function errorCallBack(res) {

            //alert("error");
            console.log("error in tags");

            return res.data;
        });





    $http({

        method:'POST',
        url:'/users/getStep1/'+campId

    }).then(
        function successCallBack(res){

            var obj = res.data;
            var data = obj.data;
            $scope.campName = data.name;
            //console.log($scope.campName);
            //console.log("NEWS STEP1 start");

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );


    $http({

        method:'POST',
        url:'/users/getStep2/'+newsId

    }).then(
        function successCallBack(res){

            var obj = res.data;
            var data = obj.data;


            /*  console.log("obj");
             console.log(JSON.stringify(obj));
             console.log("data");
             console.log(JSON.stringify( data));*/


            $scope.news={newsTitle:data.title,type:data.type,startOn:$filter('date')(new Date(data.startOn*1000),'yyyy-MM-dd')
                ,endOn:$filter('date')(new Date(data.endOn*1000),'yyyy-MM-dd'),roi:data.roi,SN:data.SN,SL:data.SL,creative:data.creative};


            /* $scope.news.newsTitle = data.title;
             $scope.news.type = data.type;
             $scope.news.startOn = new Date(data.startOn);
             $scope.news.endOn = new Date(data.endOn);
             $scope.news.roi = data.roi;*/

            document.getElementById("modelHTML").innerHTML=$scope.news.creative;
            console.log($scope.news);
            console.log("news start");

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );





    $scope.offSave = false;
    $scope.showCamp = true;
    $scope.alterEdit = function()
    {
        $scope.offSave = true;
        $scope.showCamp = false;
    }

    $scope.showNews = true;
    $scope.alterNews = function()
    {
        $scope.offSave=true;
        $scope.showNews = false;
    }

    $scope.removeSender=function(index)
    {
        $scope.news.SN.splice(index,1);
    }
    $scope.removeSubject=function(index)
    {
        $scope.news.SL.splice(index,1);
    }


    $scope.editCamp = function(){

        $scope.offSave = false;
        var obj = {campName : $scope.campName,userId:loginId, campId : campId};
        $http({

            method:'POST',
            url : '/users/editCamp',
            data:obj

        }).then(function successCallBack(res){

                var obj = res.data;
                //console.log("obj");
                // console.log(obj);
                var data = obj.data;
                var campName = data.$set.name;

                var campId = data.id;

                console.log(campName);
                //  $routeParams.campName =campName;
                // $routeParams.campId = campId;
                $window.location ='#/users/step4/'+campId+'/'+newsId;
                $scope.showCamp=true;

            },
            function errorCallBack(res){
                console.log(res.data);
            })

    }


    $scope.editNews = function(news){

        $scope.offSave=false;
        // console.log(news);

        var d1 = new Date(news.startOn);
        var date1 = d1.setHours(0, 0, 0,0);
        var startOn =  date1/ 1000;

        var d2 = new Date(news.endOn);
        var date2 = d2.setHours(0, 0, 0,0);
        var endOn =  date2/ 1000;

        /*  var date1=new Date(news.startOn).toISOString().substr(0, 10);
         var startOn=Math.round((new Date(date1+" 00:00:00")).getTime() / 1000)
         var date2=new Date(news.endOn).toISOString().substr(0, 10);
         var endOn=Math.round((new Date(date2+" 00:00:00")).getTime() / 1000)*/

        if(startOn<=endOn) {

            var obj = {
                title: news.newsTitle,
                campId: campId,
                type: news.type,
                roi: news.roi,
                cBy: loginId,
                startOn: startOn,
                endOn: endOn,
                newsId: newsId
            };

            // var obj ={title:news.title,campId:campId,type:news.type,roi:news.roi,cBy:loginId,startOn:news.startOn,endOn:news.endOn,newsId:newsId};
            $http({
                method: 'POST',
                url: '/users/editNews',
                data: obj
            }).then(function successCallBack(res) {

                    var obj = res.data;
                    // console.log("success editNews  " + newsId + " campId  " + campId);
                    // console.log(obj);
                    var data = obj.data;
                    // console.log(data);

                    $window.location = '#/users/step4/' + campId + '/' + newsId;
                    $scope.showNews = true;
                },
                function errorCallBack(res) {
                    console.log(res.data);
                })
        }
        else {
            //alert("EndOn date must be greater than StartOn date");
            console.log("edit News error  line no:  2922");
        }

    }


    $scope.enterBrands = function()
    {
        $scope.idArray2=[];


        return $q(function(resolve,reject) {

            if($scope.brand != ''){
                $scope.brand.forEach(function(obj) {

                    if (obj.id == undefined || obj.id == null) {

                        var obj2={id:0, name:obj.text, type:2, from:$scope.priceFrom, to:$scope.priceTo};

                        $http({

                            method: 'POST',
                            url: '/users/createBrands/',
                            data:obj2

                        }).then(
                            function successCallBack(res) {

                                var obj = res.data;

                                $scope.idArray2.push(obj.data.id);
                                if($scope.idArray2.length == $scope.brand.length)
                                {
                                    // console.log("idArray2 if::   ",$scope.brand.length);
                                    resolve($scope.idArray2);
                                }


                                //console.log(obj);
                                console.log("brands creation started");

                            },
                            function errorCallBack(res) {

                                console.log("error getStep1");
                                reject(res);
                            }
                        );
                    }

                    else {
                        // console.log('brands else :: ' + obj.id);
                        $scope.idArray2.push(parseInt(obj.id));
                        if($scope.idArray2.length == $scope.brand.length)
                        {
                            //  console.log("i ::   &  ",$scope.brand.length);
                            resolve($scope.brand);
                        }
                    }
                })
            }
            else {
                resolve([]);
            }
        })

    }



    $scope.enterPR = function()
    {

        $scope.idArray3 = [];

        return $q(function(resolve,reject) {

            if (typeof $scope.priceFrom != 'undefined' && typeof $scope.priceTo != 'undefined') {

                var tagName1=$scope.priceFrom.toString().concat("-".concat($scope.priceTo.toString()));
                //console.log(tagName1);

                var obj3={id:0, name:tagName1, type:3, from:$scope.priceFrom, to:$scope.priceTo};

                $http({

                    method: 'POST',
                    url: '/users/createPrice/',
                    data:obj3

                }).then(
                    function successCallBack(res) {
                        var obj = res.data;
                        var data = obj.data;
                        $scope.idArray3.push(obj.data.id);

                        //console.log($scope.priceTo);
                        // console.log(data);
                        // console.log("price creation started");
                        if($scope.idArray3.length == 1)
                        {
                            //  console.log("idArray3 if::    ",$scope.idArray3.length);
                            resolve($scope.idArray3);
                        }

                    },
                    function errorCallBack(res) {

                        console.log("error getStep1");
                        reject(res);
                    });

            }
            else {
                resolve([]);
            }

        })

    }



    $scope.enterTags = function()
    {
        $scope.idArray1 = [];


        return $q(function(resolve,reject){

            console.log("$scope.tagIn  : " + JSON.stringify($scope.tagIn));
            console.log($scope.tagIn);
            console.log("$scope.tagIn  : ");

            var newtags = [];

            $scope.tagIn.forEach(function(obj) {


                if (obj.id == undefined || obj.id == null) {

                    newtags.push(obj.text);

                    var obj1={id:0, name:obj.text, type:1,from:$scope.priceFrom, to:$scope.priceTo};

                    $http({

                        method: 'POST',
                        url: '/users/createTags/',
                        data:obj1

                    }).then(
                        function successCallBack(res) {
                            var obj = res.data;

                            $scope.idArray1.push(obj.data.id);

                            console.log(obj.data);
                            console.log("tags creation started type1");
                            if( $scope.idArray1.length == $scope.tagIn.length)
                            {
                                console.log("idArray1 if::   ",$scope.brand.length);
                                resolve($scope.idArray1);
                            }


                        },
                        function errorCallBack(res) {

                            console.log("error getStep1");
                            reject(res);
                        }
                    );

                }
                else {
                    console.log('pushing1 :: ' + obj.id);
                    $scope.idArray1.push(parseInt(obj.id));
                    if( $scope.idArray1.length == $scope.tagIn.length)
                    {
                        console.log("idArray1 if::   ",$scope.tagIn.length);
                        resolve($scope.idArray1);
                    }
                }
            })



        })

    }



    $scope.addStep4 = function()
    {

        console.log("$scope.specialCharB  : "+$scope.specialCharB);
        console.log("$scope.idArray2  : "+$scope.idArray2);
        console.log("$scope.priceTo  : "+$scope.priceTo);
        console.log("$scope.priceFrom  : "+$scope.priceFrom);
        console.log("$scope.priceTo>$scope.priceFrom  :  "+$scope.priceTo>$scope.priceFrom);

        if(!$scope.specialCharT && (!$scope.specialCharB || typeof $scope.idArray2=='undefined')&&
            ($scope.priceTo>$scope.priceFrom||(typeof $scope.priceFrom=='undefined'
            && typeof $scope.priceTo=='undefined')))
        {

            console.log("addSTep4 called");
            var promiseTags = $scope.enterTags();
            promiseTags.then(function(success){ $scope.tags = success.idArray1;
                console.log("$scope.tags  :  ",success);
                var promiseBrands = $scope.enterBrands();
                promiseBrands.then(function (success){ $scope.tBrands = success.idArray2;
                    console.log("$scope.tBrands  :  ",success);},function(error){console.log("eror brnd",error);});
                var promisePR = $scope.enterPR();
                promisePR.then(function (success) {

                    $scope.processing=true;

                    var obj = {

                        tags: $scope.idArray1,
                        tBrands: $scope.idArray2,
                        tPR: $scope.idArray3,
                        newsId: newsId,
                        cBy: loginId
                    };
                    console.log("obj addStep4  : " + JSON.stringify(obj));

                    $http({

                        method:'POST',
                        url : '/users/updateStep4',
                        data:obj
                    }).then(function successCallBack(res) {

                            console.log("res after updateStep4 :  ",JSON.stringify(res.data));
                            $window.location = "#/users/step5/" + campId + '/' + newsId;
                        },
                        function errorCallBack(res){
                            $scope.processing=false;
                            console.log(res.data);
                        })
                }, function (error) {
                    console.log("error  : ", error);
                })

            },function(error){console.log("eror tags    ",error);});
        }
        else
        {
            console.log("Validation problem line no. 3171");
        }}

}]);


sampleApp.controller('campaignStep5Ctrl', ['$filter','$scope', '$routeParams','$http','$q', '$cookies', '$cookieStore', '$window','$timeout' ,function ($filter,$scope,$routeParams, $http,$q,$cookies, $cookieStore, $window, $timeout)
{


    $scope.processing=false;

    $scope.loadTags = function(query) {
        return $http.get('/tags?query=' + query);
    };



    $scope.selectSource1 = function (bool,v) {
        $scope.showSource1 = bool;
        $scope.source1=v;
        $scope.dataSrcId = v.id;
    }

    $scope.srcDetails = [];
    $http({

        method: 'post',
        url: '/users/getDataSrc/'

    }).then(
        function successCallBack(res) {

            console.log("response data src  "+res);
            console.log(res.data);
            $scope.srcDetails.push(res.data.data);

        },
        function errorCallBack(res) {

            console.log("error in tags");
            return res.data;

        });

    $scope.dtId = '';
    $scope.selectDtSrc = function (bool,v) {

        $scope.singleCall = true;
        $scope.showDtSrc1 = bool;
        $scope.dtSrc=v;
        $scope.dtId = v.id;
        $scope.countSubscriber();
    }


    var campId = $routeParams.campId;
    /* $scope.regex ='^[a-zA-Z0-9_ ]*$';*/
    $scope.regex ='^[a-zA-Z0-9_ !@$%&-.]*$';
    $scope.maxlength=100;
    var newsId = $routeParams.newsId;
    $scope.campId = campId;
    $scope.newsId = newsId;

    //alert(campId);
    var loginId = $cookieStore.get("userid");

    $scope.cityTagBoolean = false;
    $scope.citySelected=[];
    $http({

        method: 'GET',
        url: '/users/getNewsTags/'+$scope.newsId

    }).then(
        function successCallBack(res) {

            $scope.targetSuccess = res.data.targets;

            if(typeof res.data.targets != 'undefined')
            {
                console.log("response ");
                console.log("res.data.targets  : ", JSON.stringify(res.data.targets));

                if(typeof res.data.targets.gender!='undefined') {
                    $scope.target.gender = res.data.targets.gender;
                }
                if(typeof res.data.targets.age!='undefined') {
                    $scope.fromAge = {"label":parseInt(res.data.targets.age.from)};
                    $scope.toAge = {"label":parseInt(res.data.targets.age.to)};
                }
                if(typeof res.data.targets.eDomain!='undefined') {
                    $scope.eDomain = res.data.targets.eDomain;
                }



                $scope.dVol = res.data.dVol;
                if(typeof res.data.targets.city!='undefined')
                {
                    for(var i=0;i<res.data.targets.city.length;i++)
                    {
                        var cityObj = {cityId:res.data.targets.city[i]};
                        $http({

                            method: 'POST',
                            url: '/users/getCityById/',
                            data:cityObj

                        }).then(
                            function successCallBack(res) {
                                $scope.cityTagBoolean = true;
                                $scope.getCities();
                                $scope.citySelected.push({text:res.data.data.name,id:res.data.data.id});
                                $scope.cityTags.push({text:res.data.data.name,id:res.data.data.id});

                            },
                            function errorCallBack(res){
                                //alert("error");
                                console.log("error in tags");
                                return res.data;
                            });
                    }
                }

                var countryObj={countryId:res.data.targets.country}
                $http({

                    method: 'POST',
                    url: '/users/getCountriesById/',
                    data:countryObj

                }).then(
                    function successCallBack(res) {

                        if(typeof res.data.data !='undefined'){
                            console.log("getCountriesById  res  :  "+JSON.stringify(res.data),"    and  :  ",res.data.data.name);
                            $scope.target.country=res.data.data.id;
                        }
                    },
                    function errorCallBack(res) {

                        //alert("error");
                        console.log("error in tags");
                        return res.data;
                    });



                $scope.nCatTags=[];
                $scope.catIds = 0;
                $scope.tagIn = [];
                if(typeof res.data.targets.catTags!='undefined') {
                    for (i = 0; i < res.data.targets.catTags.length; i++) {

                        $scope.catIds = res.data.targets.catTags[i];

                        $http({

                            method: 'GET',
                            url: '/users/getNewsTags1/' + $scope.catIds


                        }).then(
                            function successCallBack(res) {
                                console.log("response ");
                                console.log(res);
                                console.log("response of campaingn7 ctrl" + res);

                                console.log("res.data.name...." + res.data.id);

                                $scope.nCatTags.push({"name": res.data.name, "id": res.data.id});
                                $scope.tagIn.push({"text": res.data.name, "id": res.data.id})

                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }
                }



            }
        },
        function errorCallBack(res) {

            //alert("error");
            console.log("error in tags");

            return res.data;
        });



    $http({

        method:'POST',
        url:'/users/getStep1/'+campId

    }).then(
        function successCallBack(res){

            console.log("res step1 :  ",JSON.stringify(res));
            var obj = res.data;
            var data = obj.data;
            $scope.campName = data.name;
            console.log($scope.campName);
            console.log("NEWS STEP1 start");

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );


    $http({

        method:'POST',
        url:'/users/getStep2/'+newsId

    }).then(
        function successCallBack(res){

            // console.log("res obj  ",JSON.stringify(res));
            var obj = res.data;
            var data = obj.data;
            $scope.news={newsTitle:data.title,type:data.type,startOn:$filter('date')(new Date(data.startOn*1000),'yyyy-MM-dd')
                ,endOn:$filter('date')(new Date(data.endOn*1000),'yyyy-MM-dd'),roi:data.roi,tags:data.tags,tBrands:data.tBrands,tPR:data.tPR};


            console.log($scope.news);
            console.log("news start");

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );


    $http({

        method: 'POST',
        url: '/users/gettags/'

    }).then(
        function successCallBack(res) {
            console.log("response ");
            console.log(res);
            $scope.tags = res.data;
            // $scope.brand=[];
            $scope.tagNames = [];
            //$scope.tagIds = [];
            $scope.tags.forEach(function (obj) {
                //$scope.tagIds.push(obj.id);
                $scope.tagNames.push({"text": obj.name, "id": obj.id});
            });
            $scope.loadTags = function ($query) {

                return $scope.tagNames.filter(function (tags) {
                    return tags.text.toLowerCase().indexOf($query.toLowerCase()) != -1;
                });

            };

        },
        function errorCallBack(res) {

            //alert("error");
            console.log("error in tags");

            return res.data;
        });


    $scope.countriesArray = [];
    $scope.citiesTag=[]
    $scope.$watch('citySelected',function(newVal,oldVal){

        $scope.citiesTag=[];
        console.log("$scope.citySelected  : ",$scope.citySelected);
        if(typeof $scope.citySelected != "undefined" && $scope.citySelected!='')
        {
            $scope.citySelected.forEach(function(obj)
            {
                if(typeof obj.id!="undefined" && $scope.citiesTag.indexOf(obj.id)==-1)
                {
                    console.log("hey u called");
                    $scope.citiesTag.push(obj.id);
                    $scope.countSubscriber();
                    console.log("$scope.citiesTag   :  ",$scope.citiesTag);
                }
            })
        }
        else
        {
            console.log("citiesTag  : "+$scope.citiesTag);
            $scope.countSubscriber();
        }

    },true)

    $scope.getCountry = function() {
        var deferred = $q.defer();

        $http({
            url: 'users/getCountries',
            method: 'POST'
        }).then(
            function success(res) {
                console.log("getting coutries  :", res.data.data);
                $scope.countriesArray = res.data.data;
                console.log($scope.countriesArray);
                deferred.resolve($scope.countriesArray);
                //$scope.target.country=$scope.countriesArray[0].id;
                /*$scope.countSubscriber();*/
            },
            function error(res) {
                console.log("error in getting countries");
                console.log(res.data);
                deferred.reject(res.data);
            }
        );
        return deferred.promise;
    }



    $scope.cityTags = [];
    var promiseCountry = $scope.getCountry();
    if(typeof $scope.target!= 'undefined') {
        promiseCountry.then(function (successRes) {

            /* var countryObj = {"name":"","id":""}
             countryObj = $scope.target.country;
             var countryId = JSON.parse(countryObj).id;*/
            console.log("promiseCountry success");
            var countryId = $scope.target.country;

            var obj = {countryId: countryId};
            console.log("getcity obj id : ", countryId);
            console.log(countryId);
            $http({
                url: "users/getCities",
                method: "POST",
                data: obj
            }).then(function success(res) {

                console.log("res  :", res);

                var resObj = res.data;
                $scope.citiesArray = resObj.data;
                console.log("res.data.data  : ", res.data);
                $scope.cityTags = [];
                $timeout(function () {
                    $scope.citiesArray.forEach(function (obj) {
                        //  console.log("obj  ",obj);
                        $scope.cityTags.push({"text": obj.name, "id": obj.id});
                    })
                }, 100)

                $scope.loadCities = function ($query) {
                    return $scope.cityTags.filter(function (tags) {
                        return tags.text.toLowerCase().indexOf($query.toLowerCase()) != -1;
                    });

                };


            }, function error(res) {
                console.log("error   :", res.data.data);
            })

        }, function (errRes) {

            console.log("error getCity COuntry line : 3393");
            console.log(errRes);
        });
    }



    $scope.getCities = function()
    {

        if(!$scope.cityTagBoolean){
            $scope.citySelected=[];
            $scope.citiesTag=[];
        }

        var countryId = $scope.target.country;
        if(countryId != -1){
            var obj = {countryId:countryId};
            console.log("getcity obj id : ",countryId);
            console.log(countryId);
            $http({
                url:"users/getCities",
                method:"POST",
                data:obj
            }).then(function success(res){

                console.log("res  :",res);

                var resObj = res.data;
                $scope.citiesArray = resObj.data;
                console.log("res.data.data  : ",res.data);
                if(!$scope.cityTagBoolean){
                    $scope.cityTags = [];}
                $timeout(function () {
                    $scope.citiesArray.forEach(function(obj)
                    {
                        // console.log("obj  ",obj);
                        if(obj.id != 0 && obj.id != null)
                        $scope.cityTags.push({"text":obj.name,"id":obj.id});
                    })

                },1000)

                $scope.loadCities = function ($query) {

                    return $scope.cityTags.filter(function (tags) {
                        return tags.text.toLowerCase().indexOf($query.toLowerCase()) != -1;
                    });

                };


            },function error(res)
            {
                console.log("error   :",res.data.data);
            })
        }

    }



    $scope.loadTags = function(query) {
        return $scope.cityTags;
    };

    $scope.showCamp = true;
    $scope.alterEdit = function()
    {
        $scope.showCamp = false;
    }

    $scope.showNews = true;
    $scope.alterNews = function()
    {
        $scope.showNews = false;
    }


    $scope.editCamp = function(){

        var obj = {campName : $scope.campName,userId:loginId, campId : campId};
        $http({

            method:'POST',
            url : '/users/editCamp',
            data:obj
        }).then(function successCallBack(res){

                var obj = res.data;
                console.log("obj");
                console.log(obj);
                var data = obj.data;
                var campName = data.$set.name;
                var campId = data.id;

                console.log(campName);
                //  $routeParams.campName =campName;
                // $routeParams.campId = campId;
                $window.location ='#/users/step5/'+campId+'/'+newsId;
                $scope.showCamp=true;

            },
            function errorCallBack(res){
                console.log(res.data);
            })

    }


    $scope.editNews = function(news){

        alert("2755");
        alert(news);
        console.log(news);
        var d1 = new Date(news.startOn);
        var date1 = d1.setHours(0, 0, 0,0);
        var startOn =  date1/ 1000;

        var d2 = new Date(news.endOn);
        var date2 = d2.setHours(0, 0, 0,0);
        var endOn =  date2/ 1000;


        if(startOn<=endOn) {
            var obj = {
                title: news.title,
                campId: campId,
                type: news.type,
                roi: news.roi,
                cBy: loginId,
                startOn: startOn,
                endOn: endOn,
                newsId: newsId
            };

            // var obj ={title:news.title,campId:campId,type:news.type,roi:news.roi,cBy:loginId,startOn:news.startOn,endOn:news.endOn,newsId:newsId};
            $http({
                method: 'POST',
                url: '/users/editNews',
                data: obj
            }).then(function successCallBack(res) {

                    var obj = res.data;
                    console.log("obj edit news");
                    console.log(obj);
                    var data = obj.data;
                    console.log(data);

                    $window.location = '#/users/step5/' + campId + '/' + newsId;
                    $scope.showNews=true;

                },
                function errorCallBack(res) {
                    console.log(res.data);
                })
        }
        else {
            alert("EndOn date must be greater than StartOn date");
        }

    }
    $scope.target={country:""};

    $scope.tagId = [];

    $scope.enterTags = function()
    {
        $scope.idArray1 = [];


        return $q(function(resolve,reject){

            console.log("$scope.tagIn  : " + JSON.stringify($scope.tagIn));
            console.log($scope.tagIn);
            console.log("$scope.tagIn  : ");

            var newtags = [];

            $scope.tagIn.forEach(function(obj) {


                if (obj.id == undefined || obj.id == null) {

                    newtags.push(obj.text);

                    var obj1={id:0, name:obj.text, type:1,from:$scope.priceFrom, to:$scope.priceTo};

                    $http({

                        method: 'POST',
                        url: '/users/createTags/',
                        data:obj1

                    }).then(
                        function successCallBack(res) {
                            var obj = res.data;

                            $scope.idArray1.push(obj.data.id);

                            console.log(obj.data);
                            console.log("tags creation started type1");
                            if( $scope.idArray1.length == $scope.tagIn.length)
                            {
                                console.log("idArray1 if::   ",JSON.stringify($scope.idArray1));
                                resolve($scope.idArray1);
                            }


                        },
                        function errorCallBack(res) {

                            console.log("error getStep1");
                            reject(res);
                        }
                    );

                }
                else {
                    console.log('pushing1 :: ' + obj.id);
                    $scope.idArray1.push(parseInt(obj.id));
                    if( $scope.idArray1.length == $scope.tagIn.length)
                    {
                        console.log("idArray1 if::   ",$scope.tagIn.length);
                        resolve($scope.idArray1);
                    }
                }
            })

        })

    }
    $scope.ages = [];

    for(var i=1;i<100;i++){
        $scope.ages.push({"label":i});
    }
    $scope.toAge={};
    $scope.fromAge={};
    $scope.searchSub = false;
    $scope.singleCall = "firstCall";
    var d = new Date();
    $scope.currentYear = d.getFullYear();

    $scope.countSubscriber = function() {
        if ($scope.singleCall || $scope.singleCall != "firstCall") {

            console.log("countSubscriber called");
            $scope.countSUB = 0;
            if (typeof $scope.fromAge.label != 'undefined' && typeof $scope.toAge.label != 'undefined') {
                $scope.age1 = {to: $scope.currentYear - $scope.fromAge.label, from: $scope.currentYear - $scope.toAge.label};
            }
            $scope.ageBoolean = true;

            if (typeof $scope.toAge.label == 'undefined' || typeof $scope.fromAge.label == 'undefined') {
                $scope.ageBoolean = false;
                if (typeof $scope.toAge.label == 'undefined' && typeof $scope.fromAge.label == 'undefined') {
                    $scope.ageBoolean = true;
                }
            }
            else if ($scope.fromAge.label > $scope.toAge.label) {
                $scope.ageBoolean = false;
            }
            else {
                $scope.ageBoolean = true;
            }


            var obj = {
                esp: $scope.eDomain,
                age: $scope.age1,
                gender: $scope.target.gender,
                countries: $scope.target.country,
                cities: $scope.citiesTag /*catTags:$scope.catTags,dVol:$scope.dVol,newsId:newsId*/
                ,catTags: $scope.catTags,
                source: $scope.dtId
            };

            console.log(" countSubscriber obj : " + JSON.stringify(obj));

          if ($scope.ageBoolean && $scope.singleCall) {
                //alert("sub called");
                $scope.singleCall = false;
                $scope.searchSub = false;
                $http({

                    method: 'POST',
                    url: '/users/countSub',
                    data: obj
                }).then(function successCallBack(res) {
                        //alert("result arrived");
                        $scope.countSUB = res.data.count;
                        $scope.singleCall = true;
                        //console.log("successcallback coujnt subscriber  :   "+res.data.count);
                        //console.log("$scope.countSUB" + $scope.countSUB);
                        $scope.searchSub = true;
                    },
                    function errorCallBack(res) {
                        $scope.singleCall = true;
                        console.log("error callback countSubscriber !");
                        console.log(res.data);
                    })
            }
            else {
                console.log("counsub not executed");
            }

        }
        else if($scope.singleCall != "firstCall") {

            alert("processing one request please wait !");
        }

    };


    $scope.catTags=[];
    $scope.$watch('tagIn',function(newVal,oldVal){

        $scope.catTags = [];
        console.log("tagIn catogory tags  : ",$scope.tagIn);
        if(typeof $scope.tagIn != "undefined" && $scope.tagIn!=''){

            $scope.tagIn.forEach(function(obj)
            {
                if(typeof obj.id!="undefined"){
                    $scope.catTags.push(obj.id);
                    $scope.countSubscriber();
                    $scope.getCatTags();
                }
            })
        }
        else {
            $scope.countSubscriber();
        }

    },true)


    $scope.getCatTags=function () {

        var promiseCatogory = $scope.enterTags();
        promiseCatogory.then(function(successRes){

            console.log("success promise addstep5");

            $scope.catTags = successRes;
            console.log($scope.catTags);


        },function(errRes){

            console.log("error --------");
            console.log(errRes);
        })

    }

    $scope.addStep5 = function()
    {
        $scope.processing=true;
        var currYr = (new Date()).getFullYear();
        $scope.age1 = {from:currYr-$scope.toAge.label,to:currYr-$scope.fromAge.label};

        console.log("age  : ",$scope.age1);
        $scope.age = 1990;


        var obj ={eDomain:$scope.eDomain,age:$scope.age1,
            gender:$scope.target.gender,countries:$scope.target.country,
            cities:$scope.citiesTag,catTags:$scope.catTags,
            cBy:loginId,dVol:$scope.dVol,newsId:newsId,source:$scope.dtId};


        //alert('obj :: '+JSON.stringify(obj));
        console.log("obj : "+JSON.stringify(obj));

        //alert("objects : "+JSON.stringify(obj));

        $http({
            method:'POST',
            url : '/users/updateStep5',
            data:obj
        }).then(function successCallBack(res) {

                console.log("successcallback step5  :   ",res);
                console.log(JSON.stringify(res));
                $window.location = "#/users/step6/" + campId + '/' + newsId;
            },
            function errorCallBack(res){
                $scope.processing=false;
                console.log("error callback  !");
                console.log(res.data);
            })

    }


}]);










sampleApp.controller('campaignStep6Ctrl', ['$notification','$log','$filter','$scope', '$routeParams','$http','$q', '$cookies', '$cookieStore', '$window','$timeout' ,function ($notification,$log,$filter,$scope,$routeParams, $http,$q,$cookies, $cookieStore, $window, $timeout) {



    $scope.processing=false;
    var campId = $routeParams.campId;
    /*  $scope.regex ='^[a-zA-Z0-9_ ]*$';*/
    $scope.regex ='^[a-zA-Z0-9_ !@$%&-.]*$';
    $scope.maxlength=100;
    var newsId = $routeParams.newsId;
    $scope.campId = campId;
    $scope.newsId = newsId;

    //alert(campId);
    var loginId = $cookieStore.get("userid");

    $scope.tagIn=[];

    $http({

        method: 'GET',
        url: '/users/getNewsTags/'+newsId


    }).then(
        function successCallBack(res) {

            console.log("response ");
            console.log(res);
            console.log("response of campaingn6 ctrl"+JSON.stringify(res));
            $scope.newsTags = res.data.tags;
            $scope.brandsTags = res.data.tBrands;
            $scope.tPRTags = res.data.tPR;

            if(typeof res.data.targets != 'undefined') {
                if(typeof res.data.targets.catTags != 'undefined') {
                    $scope.catTags = res.data.targets.catTags;
                }}

            $scope.nTags=[];
            $scope.newsTagIds = 0;
            if(typeof res.data.tags != 'undefined'){
                for(i=0;i<res.data.tags.length; i++){
                    //$scope.newsTagIds.push(res.data.tags[i]);
                    $scope.newsTagIds=res.data.tags[i] ;
                    $http({

                        method: 'GET',
                        url: '/users/getNewsTags1/'+$scope.newsTagIds

                    }).then(
                        function successCallBack(res) {
                            console.log("response ");
                            console.log(res);
                            console.log("response of campaingn7 ctrl"+res);
                            $scope.news1Tags = res.data;

                            console.log("res.data.name...."+res.data.id);

                            $scope.nTags.push({"name":res.data.name, "id":res.data.id});
                            $scope.tagIn.push({"text":res.data.name, "id":res.data.id});

                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });
                }
            }
            //brands from newsletter

            $scope.nBrands=[];
            $scope.newsBrandIds = 0;
            if(typeof res.data.tBrands != 'undefined') {
                for (i = 0; i < res.data.tBrands.length; i++) {
                    //$scope.newsTagIds.push(res.data.tags[i]);
                    $scope.newsBrandIds = res.data.tBrands[i];


                    $http({

                        method: 'GET',
                        url: '/users/getNewsTags1/' + $scope.newsBrandIds


                    }).then(
                        function successCallBack(res) {
                            console.log("response ");
                            console.log(res);
                            console.log("response of campaingn7 ctrl" + res);
                            $scope.brand1Tags = res.data;

                            console.log("res.data.name...." + res.data.id);

                            $scope.nBrands.push({"name": res.data.name, "id": res.data.id});


                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });
                }
            }

            $scope.ntPRs=[];
            $scope.newstPrIds = 0;
            if(typeof res.data.tPR != 'undefined') {
                for (i = 0; i < res.data.tPR.length; i++) {
                    //$scope.newsTagIds.push(res.data.tags[i]);
                    $scope.newstPrIds = res.data.tPR[i];


                    $http({

                        method: 'GET',
                        url: '/users/getNewsTags1/' + $scope.newstPrIds


                    }).then(
                        function successCallBack(res) {
                            console.log("response ");

                            console.log("res.data.name...." + res.data.id);

                            $scope.ntPRs.push({"name": res.data.name, "id": res.data.id});


                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });
                }
            }
            //catTags from newsletter

            $scope.nCatTags=[];
            $scope.catIds = 0;
            if(typeof res.data.targets != 'undefined'){
                if(typeof res.data.targets.catTags != 'undefined'){
                    for(i=0;i<res.data.targets.catTags.length; i++){

                        $scope.catIds=res.data.targets.catTags[i] ;

                        $http({

                            method: 'GET',
                            url: '/users/getNewsTags1/'+$scope.catIds


                        }).then(
                            function successCallBack(res) {
                                console.log("response ");
                                console.log(res);
                                console.log("response of campaingn7 ctrl"+res);

                                console.log("res.data.name...."+res.data.id);

                                $scope.nCatTags.push({"name":res.data.name, "id":res.data.id});


                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }
                }}




        },
        function errorCallBack(res) {

            //alert("error");
            console.log("error in tags");

            return res.data;
        });




    $scope.loadTags = function(query) {
        return $http.get('/tags?query=' + query);
    };




    //code from step4Ctrl



    $http({

        method: 'POST',
        url: '/users/gettags/'

    }).then(
        function successCallBack(res) {
            console.log("response ");
            console.log(res);
            $scope.tags = res.data;
            // $scope.brand=[];
            $scope.tagNames = [];
            //$scope.tagIds = [];
            $scope.tags.forEach(function (obj) {
                //$scope.tagIds.push(obj.id);
                $scope.tagNames.push({"text": obj.name, "id": obj.id});
            });
            $scope.loadTags = function ($query) {

                return $scope.tagNames.filter(function (tags) {
                    return tags.text.toLowerCase().indexOf($query.toLowerCase()) != -1;
                });

            };
            /*res.data.forEach(function(obj) {
             $scope.brand.push(obj.id);

             });*/


        },
        function errorCallBack(res) {

            //alert("error");
            console.log("error in tags");

            return res.data;
        });




    $http({

        method:'POST',
        url:'/users/getStep1/'+campId

    }).then(
        function successCallBack(res){

            var obj = res.data;
            var data = obj.data;
            $scope.campName = data.name;
            console.log($scope.campName);
            console.log("NEWS STEP1 start");

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );


    $http({

        method:'POST',
        url:'/users/getStep2/'+newsId

    }).then(
        function successCallBack(res){

            var obj = res.data;
            var data = obj.data;


            console.log("obj");
            console.log(JSON.stringify(obj));
            console.log("data");
            console.log(JSON.stringify( data));


            $scope.news={newsTitle:data.title,type:data.type,startOn:$filter('date')(new Date(data.startOn*1000),'yyyy-MM-dd')
                ,endOn:$filter('date')(new Date(data.endOn*1000),'yyyy-MM-dd'),roi:data.roi,SN:data.SN,SL:data.SL,creative:data.creative,volume:data.dVol,targets:data.targets,startOn:data.startOn
                ,cBy:data.cBy};

            if(typeof data.targets != 'undefined')
            {
                console.log("response ");
                console.log("data.targets  : ", JSON.stringify(data.targets));

                if(typeof data.targets.gender!='undefined') {
                    //$scope.target.gender = res.data.targets.gender;
                    $scope.targetGender = data.targets.gender;
                }
                console.log("data.targets.age  : "+data.targets.age);
                if(typeof data.targets.age!='undefined') {

                    $scope.fromAge = data.targets.age.from;
                    $scope.toAge = data.targets.age.to;
                }

                if(typeof data.targets.eDomain!='undefined') {
                    $scope.eDomain = data.targets.eDomain;
                }



                $scope.dVol = res.data.dVol;
                $scope.citiesNames = [];
                if(typeof data.targets.city!='undefined')
                {
                    console.log("data.targets.city   : "+data.targets.city);
                    cityArrays =[];
                    var strarray = data.targets.city.toString().split(',');
                    /*for(var i=0;i<strarray.length;i++){
                     console.log("strarray  i : "+strarray[i]);
                     cityArrays.push(strarray[i]);
                     }*/

                    var cityObj = {cityIds:data.targets.city};
                    $http({

                        method: 'POST',
                        url: '/users/getCityByIds/',
                        data:cityObj

                    }).then(
                        function successCallBack(res) {

                            console.log("res 8968: "+JSON.stringify(res.data.data));
                            //$scope.citySelected.push({text:res.data.data.name,id:res.data.data.id});
                            $scope.citiesNames=res.data.data;
                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });

                }

                var countryObj={countryId:data.targets.country};

                $http({

                    method: 'POST',
                    url: '/users/getCountriesById/',
                    data:countryObj

                }).then(
                    function successCallBack(res) {

                        console.log("getCountriesById  res  :  "+JSON.stringify(res.data),"    and  :  ",res.data.data.name);
                        // $scope.target.country=res.data.data.id;
                        $scope.countryName = res.data.data.name;
                    },
                    function errorCallBack(res) {

                        //alert("error");
                        console.log("error in tags");

                        return res.data;
                    });



                $scope.nCatTags=[];
                $scope.catIds = 0;
                $scope.tagIn = [];
                if(typeof data.targets.catTags!='undefined') {
                    for (i = 0; i < data.targets.catTags.length; i++) {

                        $scope.catIds = data.targets.catTags[i];

                        $http({

                            method: 'GET',
                            url: '/users/getNewsTags1/' + $scope.catIds


                        }).then(
                            function successCallBack(res) {
                                console.log("response ");
                                console.log(res);
                                console.log("response of campaingn7 ctrl" + res);

                                console.log("res.data.name...." + res.data.id);

                                $scope.nCatTags.push({"name": res.data.name, "id": res.data.id});
                                $scope.tagIn.push({"text": res.data.name, "id": res.data.id})

                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }
                }


            }



            /* $scope.news.newsTitle = data.title;
             $scope.news.type = data.type;
             $scope.news.startOn = new Date(data.startOn);
             $scope.news.endOn = new Date(data.endOn);
             $scope.news.roi = data.roi;*/
            /*
             document.getElementById("modelHTML").innerHTML=$scope.news.creative;
             console.log($scope.news);
             console.log("news start");*/

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );






    $scope.showCamp = true;
    $scope.alterEdit = function()
    {
        $scope.showCamp = false;
    }

    $scope.showNews = true;
    $scope.alterNews = function()
    {
        $scope.showNews = false;
    }

    $scope.removeSender=function(index)
    {
        $scope.news.SN.splice(index,1);
    }
    $scope.removeSubject=function(index)
    {
        $scope.news.SL.splice(index,1);
    }
    $scope.showTags=false;
    $scope.editTagsStep6 = function()
    {
        $scope.showTags = true;


    }

    $scope.showCats=false;
    $scope.editCatogories = function()
    {
        $scope.showCats = true;
    }
    $scope.editCamp = function(){

        var obj = {campName : $scope.campName,userId:loginId, campId : campId};
        $http({

            method:'POST',
            url : '/users/editCamp',
            data:obj

        }).then(function successCallBack(res){

                var obj = res.data;
                console.log("obj");
                console.log(obj);
                var data = obj.data;
                var campName = data.$set.name;

                var campId = data.id;

                console.log(campName);
                //  $routeParams.campName =campName;
                // $routeParams.campId = campId;
                $window.location ='#/users/step3/'+campId+'/'+$scope.newsId;

            },
            function errorCallBack(res){
                console.log(res.data);
            })

    }


    $scope.editNews = function(news)
    {
        //alert("3329");
        //alert(news);
        console.log(news);
        var d1 = new Date(news.startOn);
        var date1 = d1.setHours(0, 0, 0,0);
        var startOn =  date1/ 1000;

        var d2 = new Date(news.endOn);
        var date2 = d2.setHours(0, 0, 0,0);
        var endOn =  date2/ 1000;

        /*  var date1=new Date(news.startOn).toISOString().substr(0, 10);
         var startOn=Math.round((new Date(date1+" 00:00:00")).getTime() / 1000)
         var date2=new Date(news.endOn).toISOString().substr(0, 10);
         var endOn=Math.round((new Date(date2+" 00:00:00")).getTime() / 1000)*/

        /*   var d1 = news.startOn;
         var date1 = new Date(d1.split(' ').join('T'))
         var startOn =  date1.getTime() / 1000;
         var d2 = news.endOn;
         var date2 = new Date(d2.split(' ').join('T'))
         var endOn =  date2.getTime() / 1000;*/

        if(startOn<=endOn) {
            var obj = {
                title: news.title,
                campId: campId,
                type: news.type,
                roi: news.roi,
                cBy: loginId,
                startOn: startOn,
                endOn: endOn,
                newsId: newsId
            };
            $http({
                method: 'POST',
                url: '/users/editNews',
                data: obj
            }).then(function successCallBack(res) {

                    var obj = res.data;
                    console.log("obj edit news");
                    console.log(obj);
                    var data = obj.data;
                    console.log(data);

                    //  $routeParams.campName =campName;
                    // $routeParams.campId = campId;
                    $window.location = '#/users/step4/' + campId + '/' + newsId;

                },
                function errorCallBack(res) {
                    console.log(res.data);
                })
        }
        else {
            alert("EndOn date must be greater than StartOn date");
        }

    }

    //end of step4Ctrl code


    // $scope.campaignSuccess = function()
    // {
    //     var notification = $notification('New message', {
    //         body: 'Request sent Successfully',
    //         delay: 2000
    //     });
    // }

    $scope.addStep6 = function()
    {
        //alert("addstep6");
        $scope.processing=true;
        var obj = {cBy:loginId,newsId:newsId};
        console.log("obj : "+obj);

        $http({

            method:'POST',
            url : '/users/updateStep6',
            data:obj

        }).then(function successCallBack(res) {

                var reqobj={
                    "campId": $scope.campId,
                    "nlmId": $scope.newsId,
                    "targets": $scope.news.targets,
                    "date": $scope.news.startOn,
                    "reqPush": $scope.news.volume,
                    "userId":$scope.news.cBy,
                    "altPush": 0,
                    "status": 0};

                //alert("reqobj :: "+JSON.stringify(reqobj));
                $http({

                    method:'POST',
                    url : '/users/requestVolume',
                    data:reqobj

                }).then(function successCallBack(res) {
                        //alert("res :: "+JSON.stringify(res));

                        if(res.data.statusCode==200)
                        {
                            // alert("Request send succesfully");
                            /*$scope.campaignSuccess();*/
                            alert("Volume requested successfully !");
                            $window.location = "#/users/step7";

                        }
                        else {
                            alert("problem in requesting volume,plz contact admin");
                        }

                    },
                    function errorCallBack(res){
                        $scope.processing=false;
                        console.log(res.data);
                    })

            },
            function errorCallBack(res){
                $scope.processing=false;
                console.log(res.data);
            })

    }


}]);

sampleApp.controller('reportsCtrl', ['reportsData0','$rootScope','$filter','$scope', '$routeParams','$http','$q', '$cookies', '$cookieStore', '$window','$timeout' ,function (reportsData0,$rootScope,$filter,$scope,$routeParams, $http,$q,$cookies, $cookieStore, $window, $timeout) {


    $scope.iconClick = function () {
        var element = document.getElementById("datePicker1");
        element.focus();
    }


    $scope.viewNlReports = function(campId)
    {
        reportsData0.setDate($scope.startOn);
        reportsData0.setCampId(campId);
        window.location.href = "#users/reports2";
    }

    $scope.colors=["visibility-hdn border-yellow","visibility-hdn border-green","visibility-hdn border-orrange"];

    $scope.startOn = $filter('date')(new Date(), 'yyyy-MM-dd');

    $scope.sortByVar = '-ctdOn';
    $scope.changeFilter = function(type)
    {
        $scope.sortByVar = type;
    }
    $scope.filterSort = [{type:'createdBy',show:'Sort by CreatedBy'},
        {type:'title',show:'Sort by NewsletterTitle'}];



    $scope.reportResult = [];
    $scope.preload = true;
    $scope.startOn = $filter('date')(new Date(), 'yyyy-MM-dd');

    /* if(typeof $rootScope.reportDate != 'undefined'){

     $scope.startOn = $filter('date')(new Date($rootScope.reportDate), 'yyyy-MM-dd');
     $rootScope.reportDate=new Date();
     }
     */

    var date = new Date();
    var date2Day = date.setHours(0, 0, 0, 0);
    var dateObj = {date2Day: date2Day};


    $scope.getReportsNow = function(){

        $scope.reportResult = [];
        $scope.preload = true;

        $http({
            method: 'POST',
            url: '/users/getReports',
            data: dateObj
        }).then(function successCallBack(res) {

                var obj = res.data;
                var nlmIds = [];
                console.log("obj reports");
                console.log(obj);
                $scope.reportDetail = obj;
                obj.forEach(function (object) {
                    nlmIds.push(object._id.nlmId);

                });
                var data1 = {nlmIds: nlmIds};
                $http({
                    method: 'POST',
                    url: '/users/getNlmNames',
                    data: data1
                }).then(function successCallBack(res) {

                    var obj = res.data;

                    /*console.log("obj getNames");
                     console.log(obj);*/


                    var poermain=[];

                    var d=0;
                    // alert($scope.reportDetail.length);
                    function addNames1()
                    {
                        if(d<$scope.reportDetail.length)
                        {

                            var tempmain=$scope.reportDetail[d];
                            // alert(JSON.stringify($scope.reportDetail[d]));
                            var i =0 ;
                            obj.forEach(function (object) {
                                if(object.id==$scope.reportDetail[d]._id.nlmId)
                                {
                                    //alert(JSON.stringify(object));
                                    tempmain["title"]=object.title;
                                    tempmain["SN"] = object.SN;
                                    poermain.push(tempmain);
                                }
                                i++;
                            });

                            d++;
                            addNames1();

                        }
                        else
                        {
                            //alert(JSON.stringify(poermain));
                            $scope.reportResult = poermain;
                            $scope.preload = false;
                            console.log("$scope.reportDetail   :  ", $scope.reportDetail);
                        }

                    }
                    addNames1();



                });




            },
            function errorCallBack(res) {
                console.log(res.data);
            })
    }

    //$scope.getReportsNow();

    $scope.getNews = function()
    {

        $scope.reportResult = [];
        $scope.preload = true;
        console.log($scope.startOn);

        var date = new Date($scope.startOn);
        var date2Day = date.setHours(0, 0, 0,0);
        var dateObj = {date2Day : date2Day};

        $http({
            method:'POST',
            url : '/users/getReports',
            data:dateObj
        }).then(function successCallBack(res){

                var obj = res.data;
                var nlmIds = [];
                // console.log("obj reports");
                //console.log(obj);
                $scope.reportDetail = obj;
                obj.forEach(function(object)
                {
                    nlmIds.push(object._id.nlmId);

                });

                setTimeout(function() {

                    var data1 = {nlmIds:nlmIds};
                    $http({
                        method:'POST',
                        url : '/users/getNlmNames',
                        data:data1
                    }).then(function successCallBack(res) {

                        var obj = res.data;

                        if(obj=='')
                        {
                            $scope.reportDetail = [];
                        }

                        for(var i=0;i<$scope.reportDetail.length;i++)
                        {
                            var j;
                            for(j=0;j<obj.length;j++){

                                if (obj[j].id == $scope.reportDetail[i]._id.nlmId) {
                                    $scope.reportDetail[i].title = obj[j].title;
                                    $scope.reportDetail[i].SN = obj[j].SN;
                                    break;
                                }
                            }
                            if(j==obj.length)
                            {
                                $scope.reportDetail[i]='';
                            }
                        }


                        $scope.reportResult = $scope.reportDetail;
                        $scope.preload = false;
                        console.log("$scope.reportDetail   :  ",$scope.reportDetail);
                    })

                },10)

            },
            function errorCallBack(res){
                console.log(res.data);
            })

    }

    if(reportsData0.getDate()!='')
    {
        $scope.startOn = $filter('date')(new Date(reportsData0.getDate()), 'yyyy-MM-dd');
        $scope.getNews();
    }
    else
    {
        $scope.getNews();
    }





}]);

sampleApp.controller('reportNlmCtrlR', ['reportsData0','$rootScope','$filter','$scope', '$routeParams','$http','$q', '$cookies', '$cookieStore', '$window','$timeout' ,function (reportsData0,$rootScope,$filter,$scope,$routeParams, $http,$q,$cookies, $cookieStore, $window, $timeout)
{

    $scope.alterDomStatus = function(domStatus)
    {
        alert(domStatus);
    }

    $scope.colors=["visibility-hdn border-yellow","visibility-hdn border-green","visibility-hdn border-orrange"];

    var nlmId = reportsData0.getCampId();
    var startOn = reportsData0.getDate();
    var startOn1 = reportsData0.getDate1();


    /*$scope.eDomain = [{name:'',open:'',click:'',unSub:'',spam:''}];*/
    $scope.eDomain = [];

    var date = new Date(startOn);
    var date2Day = date.setHours(0, 0, 0,0);
    var date1 = new Date(startOn1);
    var date2Day1 = date1.setHours(0, 0, 0,0);

    var dateObj = {date2Day:date2Day,nlmId:nlmId,date2Day1:date2Day1};
    $scope.incre = -1;

    if(nlmId != ''){

        $http({
            method: 'POST',
            url: 'users/getUser',
            data: {
                'id': $cookieStore.get("userid")
            }
        }).then(function successCallback(response) {
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {

                if (response.data.error) {
                   // console.log("reports getUSER erro : ",response.data.error)
                    //alert(response.data.error);
                } else if (response.data.success) {

                   // console.log("reports res success :  ",response.data.success);
                    $scope.submittedBy  =  response.data.success.name;
                }
            }
        }, function errorCallback(response) {
            alert('error');
        });



        $http({
            method:'POST',
            url : '/users/getNlmReportsR',
            data:dateObj
        }).then(function successCallBack(res){

                var obj = res.data;

                $scope.reportResult = obj;
                $scope.totalVol1 = 0;
                $scope.totalSent = 0;
                $scope.totalDelivered = 0;
                $scope.totaluOpen= 0;
                $scope.totalReplies = 0;
                $scope.totaluClick = 0;
                $scope.totalBounce = 0;
                $scope.totalunSub= 0;
                $scope.totalSpam = 0;

                $scope.reportResult.forEach(function(object){
                    $scope.totalVol1 = $scope.totalVol1+object.totalVol;
                    $scope.totalSent = $scope.totalSent+object.sent;
                    $scope.totalDelivered = $scope.totalDelivered+object.dlvrd;
                    $scope.totaluOpen = $scope.totaluOpen+object.uOpen;
                    $scope.totalReplies = $scope.totalReplies+object.replies;
                    $scope.totaluClick = $scope.totaluClick+object.uClick;
                    $scope.totalBounce = $scope.totalBounce+object.bounce;
                    $scope.totalunSub = $scope.totalunSub+object.unSub;
                    $scope.totalSpam = $scope.totalSpam+object.spam;
                })


            },
            function errorCallBack(res){
                console.log(res.data);
            })


        //getNewsLetter Details

        $http({

            method:'POST',
            url:'/users/getStep2/'+nlmId


        }).then(
            function successCallBack(res){

                var obj = res.data;
                var data = obj.data;
                //console.log("news start : 1  ");
               // console.log(new Date(data.startOn*1000));
                $scope.campId = data.campId;

                $scope.news={newsTitle:data.title,dVol:data.dVol,startOn:$filter('date')(new Date(data.startOn*1000),'yyyy-MM-dd')
                    ,endOn:$filter('date')(new Date(data.endOn*1000),'yyyy-MM-dd'),cBy:data.userRel.name,creative:data.creative};

                document.getElementById("modelHTML").innerHTML=$scope.news.creative;
              //  console.log($scope.news);
               // console.log("news start");

                $http({

                    method:'POST',
                    url:'/users/getStep1/'+data.campId

                }).then(
                    function successCallBack(res){

                        var obj = res.data;
                        var data = obj.data;
                        // $scope.campId = data.id;
                        // $scope.campName = data.name;
                        $scope.news.campName = data.name;
                        //console.log($scope.campName);
                       // console.log("res start");
                        $scope.newsletter = $scope.news;

                    },
                    function errorCallBack(res){

                        console.log("error getStep1");
                    }
                );

                var objLoc = {campId:data.campId,nlmId:nlmId,startOn:data.startOn}
               // console.log("objLoc  : "+objLoc);

                $scope.cityDetails=[];

                //old statslocation http call
                $http({

                    method:'POST',
                    url:'/users/statsLocation/',
                    data:objLoc
                }).then(
                    function successCallBack(res){

                        if (res.data === 'logout' || JSON.stringify(res.data).indexOf('logout') > -1) {
                            window.location.href = "./";
                        } else {
                            $scope.cityDetails = res.data;
                        }

                    },
                    function errorCallBack(res){

                        console.log("error statsLocation");
                    }
                );



                var d1 = new Date();
                var date1 = d1.setHours(0, 0, 0,0);
                var sentOn =  date1/ 1000;
                var objDom = {campId:data.campId,nlmId:nlmId,sentOn:sentOn}


                $http({
                    method: 'POST',
                    url: 'users/statsDomains',
                    data: objDom
                }).then(function successCallback(response) {
                    if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                        window.location.href = "./";
                    } else {
                        var obj=response.data;
                        $scope.eDomain=obj;
                        //console.log("eDomain : "+JSON.stringify($scope.eDomain));

                    }
                }, function errorCallback(response) {
                    console.log('error');
                    console.log(response);
                });



            },
            function errorCallBack(res){
                console.log("error getStep1");
            }
        );

    }

}]);



sampleApp.controller('reportNlmCtrl', ['reportsData0','$rootScope','$filter','$scope', '$routeParams','$http','$q', '$cookies', '$cookieStore', '$window','$timeout' ,function (reportsData0,$rootScope,$filter,$scope,$routeParams, $http,$q,$cookies, $cookieStore, $window, $timeout)
{

    $scope.alterDomStatus = function(domStatus)
    {
        alert(domStatus);

    }

    $scope.colors=["visibility-hdn border-yellow","visibility-hdn border-green","visibility-hdn border-orrange"];

    var nlmId = reportsData0.getCampId();
    var startOn = reportsData0.getDate();


    /*$scope.eDomain = [{name:'',open:'',click:'',unSub:'',spam:''}];*/
    $scope.eDomain = [];

    var date = new Date(startOn);
    var date2Day = date.setHours(0, 0, 0,0);

    var dateObj = {date2Day:date2Day,nlmId:nlmId};
    $scope.incre = -1;

    if(nlmId != ''){

        $http({
            method: 'POST',
            url: 'users/getUser',
            data: {
                'id': $cookieStore.get("userid")
            }
        }).then(function successCallback(response) {
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {

                if (response.data.error) {
                    console.log("reports getUSER erro : ",response.data.error)
                    //alert(response.data.error);
                } else if (response.data.success) {

                    console.log("reports res success :  ",response.data.success);
                    $scope.submittedBy  =  response.data.success.name;
                }
            }
        }, function errorCallback(response) {
            alert('error');
        });



        $http({
            method:'POST',
            url : '/users/getNlmReports',
            data:dateObj
        }).then(function successCallBack(res){

                var obj = res.data;


                $scope.reportResult = obj;
                $scope.totalVol1 = 0;
                $scope.totalSent = 0;
                $scope.totalDelivered = 0;
                $scope.totaluOpen= 0;
                $scope.totalReplies = 0;
                $scope.totaluClick = 0;
                $scope.totalBounce = 0;
                $scope.totalunSub= 0;
                $scope.totalSpam = 0;

                $scope.reportResult.forEach(function(object){
                    $scope.totalVol1 = $scope.totalVol1+object.totalVol;
                    $scope.totalSent = $scope.totalSent+object.sent;
                    $scope.totalDelivered = $scope.totalDelivered+object.dlvrd;
                    $scope.totaluOpen = $scope.totaluOpen+object.uOpen;
                    $scope.totalReplies = $scope.totalReplies+object.replies;
                    $scope.totaluClick = $scope.totaluClick+object.uClick;
                    $scope.totalBounce = $scope.totalBounce+object.bounce;
                    $scope.totalunSub = $scope.totalunSub+object.unSub;
                    $scope.totalSpam = $scope.totalSpam+object.spam;
                })


            },
            function errorCallBack(res){
                console.log(res.data);
            })


        //getNewsLetter Details

        $http({

            method:'POST',
            url:'/users/getStep2/'+nlmId


        }).then(
            function successCallBack(res){

                var obj = res.data;
                var data = obj.data;
                console.log("news start : 1  ");
                console.log(new Date(data.startOn*1000));
                $scope.campId = data.campId;

                $scope.news={newsTitle:data.title,dVol:data.dVol,startOn:$filter('date')(new Date(data.startOn*1000),'yyyy-MM-dd')
                    ,endOn:$filter('date')(new Date(data.endOn*1000),'yyyy-MM-dd'),cBy:data.userRel.name,creative:data.creative};

                document.getElementById("modelHTML").innerHTML=$scope.news.creative;
                console.log($scope.news);
                console.log("news start");

                $http({

                    method:'POST',
                    url:'/users/getStep1/'+data.campId

                }).then(
                    function successCallBack(res){

                        var obj = res.data;
                        var data = obj.data;
                        // $scope.campId = data.id;
                        // $scope.campName = data.name;
                        $scope.news.campName = data.name;
                        //console.log($scope.campName);
                        console.log("res start");
                        $scope.newsletter = $scope.news;

                    },
                    function errorCallBack(res){

                        console.log("error getStep1");
                    }
                );

                var objLoc = {campId:data.campId,nlmId:nlmId,startOn:data.startOn}
                console.log("objLoc  : "+objLoc);

                $scope.cityDetails=[];

                //old statslocation http call
                $http({

                    method:'POST',
                    url:'/users/statsLocation/',
                    data:objLoc
                }).then(
                    function successCallBack(res){

                        if (res.data === 'logout' || JSON.stringify(res.data).indexOf('logout') > -1) {
                            window.location.href = "./";
                        } else {
                            $scope.cityDetails = res.data;
                        }

                    },
                    function errorCallBack(res){

                        console.log("error statsLocation");
                    }
                );



                var d1 = new Date();
                var date1 = d1.setHours(0, 0, 0,0);
                var sentOn =  date1/ 1000;
                var objDom = {campId:data.campId,nlmId:nlmId,sentOn:sentOn}


                $http({
                    method: 'POST',
                    url: 'users/statsDomains',
                    data: objDom
                }).then(function successCallback(response) {
                    if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                        window.location.href = "./";
                    } else {
                        var obj=response.data;
                        $scope.eDomain=obj;
                        console.log("eDomain : "+JSON.stringify($scope.eDomain));

                    }
                }, function errorCallback(response) {
                    console.log('error');
                    console.log(response);
                });



            },
            function errorCallBack(res){
                console.log("error getStep1");
            }
        );

    }

}]);

sampleApp.controller('campaign-view-controllerR', ['$scope', '$routeParams','$http','$q', '$cookies', '$cookieStore', '$window','$timeout' ,function ($scope,$routeParams, $http,$q,$cookies, $cookieStore, $window, $timeout) {


    $scope.recordExist = false;
    $scope.processing = false;

    if(typeof($routeParams.campName) != 'undefined')
    {
        alert("campName : "+$routeParams.campName);
        $scope.campName = $routeParams.campName;
        $scope.campId = $routeParams.campId;
        //$window.location ='#/users/step2/'+$scope.campName+'/'+$scope.campId;
    }
    $scope.regex ='^[a-zA-Z0-9_ !@$%&-.]*$';
    $scope.maxlength=100;


    var loginId = $cookieStore.get("userid");

    if(typeof(loginId)=="undefined")
    {
        $window.location=('#/');
    }



    $scope.createCampaign = function()
    {

        var obj={camp:$scope.campTitle
            ,userId:loginId}


        $scope.processing=true;

        $http({
            method: 'POST',
            url: 'users/createCamp/',
            data:obj
        }).then(function successCallback(response) {

            console.log("success : ",response.data);
            if(response.data.length != 0 && typeof response.data.data != 'undefined')
            {
                var obj = response.data;
                var data = obj.data;
                var campId = data.id;
                //console.log("success : ",$scope.campName);
                $window.location ='#/users/step2R/'+campId;
            }
            else if(response.data.message == "Record exists")
            {
                alert("Continuing with old Campaign");
                var obj = response.data;
                var data = obj.details;
                var campId = data.id;
                $window.location ='#/users/step2R/'+campId;

            }
            else {
                $scope.processing=false;
                $scope.recordExist = true;
                // alert("record exist");
            }

        }, function errorCallback(response) {

            console.log("error ",response);

        });

    }


}]);
sampleApp.controller('campaignStep2CtrlR', ['$scope','$filter', '$routeParams','$http','$q', '$cookies', '$cookieStore', '$window','$timeout',function ($scope,$filter,$routeParams, $http,$q,$cookies, $cookieStore, $window, $timeout) {



    var campId = $routeParams.campId;
    /*    $scope.regex ='^[a-zA-Z0-9_ ]*$';*/
    $scope.regex ='^[a-zA-Z0-9_ !@$%&-.]*$';
    $scope.maxlength=100;
    $scope.processing=false;

    var loginId = $cookieStore.get("userid");

    $http({

        method:'POST',
        url:'/users/getStep1R/'+campId


    }).then(
        function successCallBack(res){
            //console.log("res  getStep1: ",JSON.stringify(res));
            var obj = res.data;
            var data = obj.data;
            $scope.campId = data.id;
            $scope.campName = data.name;
            // console.log($scope.campName);
            //console.log("res start");

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );




    $scope.showCamp = true;
    $scope.alterEdit = function()
    {
        $scope.showCamp = false;
    }
    $scope.editCampaign = function(camp)
    {
        var obj = {campName : $scope.campName,userId:loginId, campId : $scope.campId};
        $http({

            method:'POST',
            url : '/users/editCamp',
            data:obj
        }).then(function successCallBack(res){

                var obj = res.data;
                //console.log("obj");
                //  console.log(obj);
                var data = obj.data;
                var campName = data.$set.name;
                var campId = data.id;

                //   console.log(campName);
                //  $routeParams.campName =campName;
                // $routeParams.campId = campId;
                $window.location ='#/users/step2R/'+campId;

            },
            function errorCallBack(res){
                console.log(res.data);
            })

        $scope.showCamp = true;

    }


    $scope.news={};
    $scope.news.scd = {};
    $scope.news.scd.d1 = $filter('date')(new Date(), "yyyy-MM-dd");
    $scope.news.scd.d2 = $filter('date')(new Date(), "yyyy-MM-dd");


    $scope.changeEndOn = function()
    {
        $scope.news.scd.d2 = $scope.news.scd.d1;
        //alert($scope.news.scd.d2);
    }

    $scope.addNews = function(news)
    {

        console.log("addNews1 for step2");

        var d1 = new Date(news.scd.d1);
        var date1 = d1.setHours(0, 0, 0,0);
        var startOn =  date1/ 1000;


        var d2 = new Date(news.scd.d2);
        var date2 = d2.setHours(0, 0, 0,0);
        var endOn =  date2/ 1000;


        //alert(endOn);
        if(parseInt(startOn)<=parseInt(endOn)){

            $scope.processing=true;

            var obj = {news:$scope.news,campId:$scope.campId,cBy:loginId,startOn:startOn,endOn:endOn};
            //alert(JSON.stringify(obj));
            $http({

                method:'POST',
                url : '/users/createNewsR',
                data:obj
            }).then(function successCallBack(res){

                    if(res.length<1){

                        $window.location.reload();
                    }
                    else{

                        var obj = res.data;

                        if(obj.data != "Record exists"){
                        console.log("obj   ",JSON.stringify(obj));
                        var news = obj.data;
                        // console.log(obj);

                        var newsId = news.id;
                        console.log("newsId :  "+newsId);

                        $window.location = "#/users/step3R/"+$scope.campId+'/'+newsId;
                        }
                        else{
                            alert("Newsletter name already exist");
                            $scope.processing=false;
                        }
                    }

                },
                function errorCallBack(res){
                    console.log("Error  :  ",JSON.strigify(res));
                    //console.log(res.data);
                })

        }
        else {
            $scope.processing=false ;
            console.log("error in createNews line:2368");
            //alert("EndOn Date must be greater than StartOn Date");
        }
        $scope.showCamp = true;
    }



}]);

sampleApp.controller('campaignStep3CtrlR', ['$filter','fileUpload','$scope', '$routeParams','$http','$q', '$cookies', '$cookieStore', '$window','$timeout' ,function ($filter,fileUpload,$scope,$routeParams, $http,$q,$cookies, $cookieStore, $window, $timeout) {

    $scope.radioModel = "upload";
    var campId = $routeParams.campId;
    $scope.campId = $routeParams.campId;
    $scope.processing=false;
    $scope.processEditCamp=false;
    $scope.processEditNews=false;


    /*    $scope.regex ='^[a-zA-Z0-9_ ]*$';*/
    $scope.regex ='^[a-zA-Z0-9_ !@$%&-.]*$';
    $scope.maxlength=100;
    var newsId = $routeParams.newsId;

    var loginId = $cookieStore.get("userid");




    $http({

        method:'POST',
        url:'/users/getStep1R/'+$routeParams.campId


    }).then(
        function successCallBack(res){
            console.log(campId);
            var obj = res.data;
            //  console.log(obj);
            var data = obj.data;
            $scope.campName = data.name;
            //console.log($scope.campName);
            // console.log("NEWS STEP1 start");

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );


    $http({

        method:'POST',
        url:'/users/getStep2R/'+newsId


    }).then(
        function successCallBack(res){

            var obj = res.data;
            var data = obj.data;
            console.log("news start : 1 "+JSON.stringify(res.data));
            console.log(new Date(data.startOn*1000));

            $scope.news={newsTitle:data.title,type:data.type,startOn:$filter('date')(new Date(data.startOn*1000),'yyyy-MM-dd')
                ,endOn:$filter('date')(new Date(data.endOn*1000),'yyyy-MM-dd'),roi:data.roi};

            //console.log($scope.news);
            console.log("news start");

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );


    $scope.showCamp = true;
    $scope.alterEdit = function()
    {
        $scope.showCamp = false;
    }

    $scope.showNews = true;
    $scope.alterNews = function()
    {
        $scope.showNews = false;
    }

    $scope.editCamp = function(){

        $scope.processEditCamp=true;

        var obj = {campName : $scope.campName,userId:loginId, campId : campId};
        $http({

            method:'POST',
            url : '/users/editCamp',
            data:obj
        }).then(function successCallBack(res){

                var obj = res.data;
                // console.log("obj");
                // console.log(obj);
                var data = obj.data;
                var campName = data.$set.name;
                var campId = data.id;

                // console.log(campName);
                //  $routeParams.campName =campName;
                // $routeParams.campId = campId;
                $window.location ='#/users/step3R/'+campId+'/'+newsId;
                $scope.showCamp = true;
            },
            function errorCallBack(res){
                console.log(res.data);
            })

    }


    $scope.editNews = function(news){

        $scope.processEditNews=true;
        var d1 = new Date(news.startOn);
        var date1 = d1.setHours(0, 0, 0,0);
        var startOn =  date1/ 1000;

        var d2 = new Date(news.endOn);
        var date2 = d2.setHours(0, 0, 0,0);
        var endOn =  date2/ 1000;

        /*   var date1=new Date(news.startOn).toISOString().substr(0, 10);
         var startOn=Math.round((new Date(date1+" 00:00:00")).getTime() / 1000)
         var date2=new Date(news.endOn).toISOString().substr(0, 10);
         var endOn=Math.round((new Date(date2+" 00:00:00")).getTime() / 1000)*/


        if(startOn<=endOn){


            var obj = {title:news.newsTitle,campId:campId,type:news.type,roi:news.roi,cBy:loginId,startOn:startOn,endOn:endOn,newsId:newsId};
            //alert(obj);
            //console.log(obj);
            $http({

                method:'POST',
                url : '/users/editNewsR',
                data:obj
            }).then(function successCallBack(res){

                    var obj = res.data;
                    // console.log("obj");
                    // console.log(obj);
                    var data = obj.data;
                    // var campName = data.$set.name;



                    //  $routeParams.campName =campName;
                    // $routeParams.campId = campId;
                    $window.location ='#/users/step3R/'+campId+'/'+newsId;
                    $scope.showNews = true;

                },
                function errorCallBack(res){
                    console.log(res.data);
                })
        }
        else {
            console.log("edit News error  line no:  5189");
            $scope.processEditNews=false;
            //alert("EndOn Date must be greater than StartOn Date");
        }

    }


    $scope.fckValue = 0;
    var oFCKeditor = new FCKeditor('editor');
    //alert("ctrl3 called");
    $scope.fckeditor = function(){
        //alert("fckeditor  ");
        if($scope.fckValue<1){

            oFCKeditor.BasePath = "/FCKeditor_2.0rc3/";
            oFCKeditor.Width = 700;
            oFCKeditor.Height = 500;
            oFCKeditor.ProcessHTMLEntities = false;
            oFCKeditor.ReplaceTextarea();
            $scope.fckValue++;

        }
        else{
            var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
            oEditor.SetHTML("");
        }

    }

    $scope.fckeditor();


    $scope.fileUndefined=false;
    $scope.fileNoZip = false;

    $scope.fileUpload = function () {

        var file = $scope.myFile;
        // alert("fileUPload  :  "+(typeof file=="undefined"));
        var file1 = document.getElementById("uploadFile");
        var fileName1=file1.value.toString();
        // alert("11111");
        if(fileName1.split('.').pop().toLowerCase() == "zip" ){
            //  if(typeof file=="undefined"){$scope.disableSave=true;}else{$scope.disableSave=false;}
            //  console.log('file is ' );
            // console.dir(file);

            var uploadUrl = "/users/uploadFileR";
            fileUpload.async(file, uploadUrl).then(function(res){

                $scope.uploadDetails = res.data;
                $scope.fckmodel= res.data;
                //  console.log(res.data);
                //document.getElementById("editor").innerHTML(res.data);

                //alert(res.data);
                $scope.fckValue = 0;
                var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
                oEditor.SetHTML(res.data);
                $scope.radioModel='create';

            });


        }else if(typeof file=="undefined"){
            $scope.fileNoZip = false;
            $scope.fileUndefined=true;
            //alert("Please Select the file to be uploaded");
        }else{ $scope.fileNoZip = true;
            $scope.fileUndefined=false;
            //alert("Please Upload Only Zip File");
        }

    }


    $scope.addStep3 = function()
    {

        console.log("editor");
        var oEditor = FCKeditorAPI.GetInstance(oFCKeditor.InstanceName);
        var cont = oEditor.GetHTML();
        $scope.editorContent=oEditor.GetHTML();
        //console.log("cont :: "+cont);
        // alert("cont  "+cont);
        //alert("fckmodel    :  "+cont);

        if(typeof cont == "undefined" || cont==''|| $scope.senderData=='' || $scope.subjectData== '' ||cont=='<br>')
        {console.log("Incomplete data line no.:5278");
        }
        else{
            $scope.processing=true;
            var obj ={status:-5,SN:$scope.senderData,SL:$scope.subjectData,cBy:loginId,newsId:newsId, creative:cont};
            console.log("obj : "+obj);

            $http({

                method:'POST',
                url : '/users/updateStep3R',
                data:obj

            }).then(function successCallBack(res){

                    if(res.length<1){
                        $window.location.reload();
                    }
                    else{
                        $window.location ="#/users/step4R/"+campId+'/'+newsId;
                    }

                },
                function errorCallBack(res){
                    console.log(res.data);
                    $scope.processing=false;
                })
        }
    }

    $scope.senderData = [];
    var i=0;

    $scope.senderSubmit= false;
    $scope.addSender = function(senderName)
    {
        if(senderName!='' && senderName != null && $scope.senderData.length<3){
            $scope.senderData.push(senderName);
            $scope.senderName='';
        }
        if(senderName != null && senderName!='' )
        {    i++;
            if(i>3 && $scope.senderData.length==3){
                $scope.senderSubmit=true;}
            //alert("Sender Name limit exceed");
        }

    }
    $scope.subjectData = [];
    $scope.subjectSubmit=false;
    var j=0;
    $scope.addSubject = function(subject)
    {
        if(subject!='' && subject != null && $scope.subjectData.length<3){
            $scope.subjectData.push(subject);
            $scope.subject='';
        }
        if(subject != null && subject!='')
        {    j++;
            if(j>3 && $scope.subjectData.length==3){
                $scope.subjectSubmit=true;}
            //alert("Sender Name limit exceed");
        }
    }
    $scope.removeSender=function(index)
    {
        $scope.senderData.splice(index,1);
        $scope.senderSubmit=false;
    }
    $scope.removeSubject=function(index)
    {
        $scope.subjectData.splice(index,1);
        $scope.subjectSubmit=false;
    }



}]);

sampleApp.controller('campaignStep4CtrlR', ['$filter','$scope', '$routeParams','$http','$q', '$cookies', '$cookieStore', '$window','$timeout' ,function ($filter,$scope,$routeParams, $http,$q,$cookies, $cookieStore, $window, $timeout) {


    $scope.processing=false;
    var campId = $routeParams.campId;
    /*   $scope.regex ='^[a-zA-Z0-9_ ]*$';*/
    $scope.regex ='^[a-zA-Z0-9_ !@$%&-.]*$';
    $scope.maxlength=100;
    var newsId = $routeParams.newsId;
    $scope.campId = campId;
    $scope.newsId = newsId;

    //alert(campId);
    var loginId = $cookieStore.get("userid");

    $scope.regex2 = new RegExp('^[a-zA-Z0-9_ ]*$');
    $scope.specialCharT = false;
    $scope.specialCharB = false;
    $scope.tagIn=[];
    $scope.brand=[];

    console.log("$scope.newsId ;  ",$scope.newsId);
    $http({

        method: 'GET',
        url: '/users/getNewsTags/'+$scope.newsId


    }).then(
        function successCallBack(res) {

            if(typeof res.data.tags != 'undefined')
            {

                // console.log("response ");
                //console.log(res);
                //console.log("response of campaingn6 ctrl" + JSON.stringify(res));
                $scope.newsTags = res.data.tags;
                $scope.brandsTags = res.data.tBrands;
                $scope.tPRTags = res.data.tPR;
                $scope.nTags = [];
                $scope.newsTagIds = 0;
                //console.log("res.data.tags  : ", res.data.tags);
                for (i = 0; i < res.data.tags.length; i++) {
                    //$scope.newsTagIds.push(res.data.tags[i]);
                    $scope.newsTagIds = res.data.tags[i];
                    $http({

                        method: 'GET',
                        url: '/users/getNewsTags1/' + $scope.newsTagIds

                    }).then(
                        function successCallBack(res) {
                            //  console.log("response ");
                            //  console.log(res);
                            // console.log("response of campaingn7 ctrl" + res);
                            $scope.news1Tags = res.data;

                            // console.log("res.data.name...." + res.data.id);

                            $scope.nTags.push({"name": res.data.name, "id": res.data.id});
                            $scope.tagIn.push({"text": res.data.name, "id": res.data.id});

                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });
                }
                //brands from newsletter
                $scope.nBrands = [];
                $scope.newsBrandIds = 0;
                if(typeof res.data.tBrands != 'undefined'){
                    for (i = 0; i < res.data.tBrands.length; i++) {
                        //$scope.newsTagIds.push(res.data.tags[i]);
                        $scope.newsBrandIds = res.data.tBrands[i];


                        $http({

                            method: 'GET',
                            url: '/users/getNewsTags1/' + $scope.newsBrandIds


                        }).then(
                            function successCallBack(res) {
                                //console.log("response ");
                                // console.log(res);
                                //console.log("response of campaingn7 ctrl" + res);
                                $scope.brand1Tags = res.data;

                                // console.log("res.data.name...." + res.data.id + "  res.data.name  :  ", res.data.name);

                                $scope.nBrands.push({"name": res.data.name, "id": res.data.id});
                                $scope.brand.push({"text": res.data.name, "id": res.data.id});

                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }}


                $scope.ntPRs = [];
                $scope.newstPrIds = 0;
                if(typeof res.data.tPR != 'undefined'){
                    for (i = 0; i < res.data.tPR.length; i++) {
                        //$scope.newsTagIds.push(res.data.tags[i]);
                        $scope.newstPrIds = res.data.tPR[i];


                        $http({

                            method: 'GET',
                            url: '/users/getNewsTags1/' + $scope.newstPrIds


                        }).then(
                            function successCallBack(res) {
                                // console.log("response ");

                                // console.log("res.data.name...." + res.data.id);

                                $scope.ntPRs.push({"name": res.data.name, "id": res.data.id});
                                var priceString = res.data.name;
                                var index = priceString.indexOf("-");
                                $scope.priceFrom = parseInt(priceString.slice(0, index));
                                $scope.priceTo = parseInt(priceString.slice(index + 1, priceString.length));

                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }}

            }
        },
        function errorCallBack(res) {

            //alert("error");
            console.log("error in tags");

            return res.data;
        });





    $http({

        method: 'POST',
        url: '/users/getTagsOnly/'

    }).then(
        function successCallBack(res) {
            // console.log("response ");
            // console.log(res);
            $scope.tags = res.data;
            // $scope.brand=[];
            $scope.tagNames = [];
            //$scope.tagIds = [];
            $scope.tags.forEach(function (obj) {
                //$scope.tagIds.push(obj.id);
                $scope.tagNames.push({"text": obj.name, "id": obj.id});
            });

            $scope.loadTags = function ($query) {
                //alert("tags")
                if($scope.regex2.test($query.toString())){
                    $scope.specialCharT = false;
                }
                else{$scope.specialCharT = true;}
                return $scope.tagNames.filter(function (tags) {
                    return tags.text.toLowerCase().indexOf($query.toLowerCase()) != -1;
                });

            };
            /* $scope.loadBrands = function ($query) {


             if($scope.regex2.test($query.toString())){
             $scope.specialCharB = false;
             }
             else{$scope.specialCharB = true;}
             return $scope.tagNames.filter(function (tags) {
             return tags.text.toLowerCase().indexOf($query.toLowerCase()) != -1;
             });

             };*/

        },
        function errorCallBack(res) {

            //alert("error");
            console.log("error in tags");

            return res.data;
        });

    $http({

        method: 'POST',
        url: '/users/getBrandsOnly/'

    }).then(
        function successCallBack(res) {
            //console.log("response ");
            //console.log(res);
            $scope.tags1 = res.data;
            // $scope.brand=[];
            $scope.tagNames1 = [];
            //$scope.tagIds = [];
            $scope.tags1.forEach(function (obj) {
                //$scope.tagIds.push(obj.id);
                $scope.tagNames1.push({"text": obj.name, "id": obj.id});
            });


            $scope.loadBrands = function ($query) {

                //alert("brands");
                if($scope.regex2.test($query.toString())){
                    $scope.specialCharB = false;
                }
                else{$scope.specialCharB = true;}
                return $scope.tagNames1.filter(function (tags) {
                    return tags.text.toLowerCase().indexOf($query.toLowerCase()) != -1;
                });

            };

        },
        function errorCallBack(res) {

            //alert("error");
            console.log("error in tags");

            return res.data;
        });





    $http({

        method:'POST',
        url:'/users/getStep1R/'+campId

    }).then(
        function successCallBack(res){

            var obj = res.data;
            var data = obj.data;
            $scope.campName = data.name;
            //console.log($scope.campName);
            //console.log("NEWS STEP1 start");

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );


    $http({

        method:'POST',
        url:'/users/getStep2R/'+newsId

    }).then(
        function successCallBack(res){

            var obj = res.data;
            var data = obj.data;


            /*  console.log("obj");
             console.log(JSON.stringify(obj));
             console.log("data");
             console.log(JSON.stringify( data));*/


            $scope.news={newsTitle:data.title,type:data.type,startOn:$filter('date')(new Date(data.startOn*1000),'yyyy-MM-dd')
                ,endOn:$filter('date')(new Date(data.endOn*1000),'yyyy-MM-dd'),roi:data.roi,SN:data.SN,SL:data.SL,creative:data.creative};


            /* $scope.news.newsTitle = data.title;
             $scope.news.type = data.type;
             $scope.news.startOn = new Date(data.startOn);
             $scope.news.endOn = new Date(data.endOn);
             $scope.news.roi = data.roi;*/

            document.getElementById("modelHTML").innerHTML=$scope.news.creative;
            console.log($scope.news);
            console.log("news start");

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );





    $scope.offSave = false;
    $scope.showCamp = true;
    $scope.alterEdit = function()
    {
        $scope.offSave = true;
        $scope.showCamp = false;
    }

    $scope.showNews = true;
    $scope.alterNews = function()
    {
        $scope.offSave=true;
        $scope.showNews = false;
    }

    $scope.removeSender=function(index)
    {
        $scope.news.SN.splice(index,1);
    }
    $scope.removeSubject=function(index)
    {
        $scope.news.SL.splice(index,1);
    }


    $scope.editCamp = function(){

        $scope.offSave = false;
        var obj = {campName : $scope.campName,userId:loginId, campId : campId};
        $http({

            method:'POST',
            url : '/users/editCamp',
            data:obj

        }).then(function successCallBack(res){

                var obj = res.data;
                //console.log("obj");
                // console.log(obj);
                var data = obj.data;
                var campName = data.$set.name;

                var campId = data.id;

                console.log(campName);
                //  $routeParams.campName =campName;
                // $routeParams.campId = campId;
                $window.location ='#/users/step4R/'+campId+'/'+newsId;
                $scope.showCamp=true;

            },
            function errorCallBack(res){
                console.log(res.data);
            })

    }


    $scope.editNews = function(news){

        $scope.offSave=false;
        // console.log(news);

        var d1 = new Date(news.startOn);
        var date1 = d1.setHours(0, 0, 0,0);
        var startOn =  date1/ 1000;

        var d2 = new Date(news.endOn);
        var date2 = d2.setHours(0, 0, 0,0);
        var endOn =  date2/ 1000;

        /*  var date1=new Date(news.startOn).toISOString().substr(0, 10);
         var startOn=Math.round((new Date(date1+" 00:00:00")).getTime() / 1000)
         var date2=new Date(news.endOn).toISOString().substr(0, 10);
         var endOn=Math.round((new Date(date2+" 00:00:00")).getTime() / 1000)*/

        if(startOn<=endOn) {

            var obj = {
                title: news.newsTitle,
                campId: campId,
                type: news.type,
                roi: news.roi,
                cBy: loginId,
                startOn: startOn,
                endOn: endOn,
                newsId: newsId
            };

            // var obj ={title:news.title,campId:campId,type:news.type,roi:news.roi,cBy:loginId,startOn:news.startOn,endOn:news.endOn,newsId:newsId};
            $http({
                method: 'POST',
                url: '/users/editNewsR',
                data: obj
            }).then(function successCallBack(res) {

                    var obj = res.data;
                    // console.log("success editNews  " + newsId + " campId  " + campId);
                    // console.log(obj);
                    var data = obj.data;
                    // console.log(data);

                    $window.location = '#/users/step4R/' + campId + '/' + newsId;
                    $scope.showNews = true;
                },
                function errorCallBack(res) {
                    console.log(res.data);
                })
        }
        else {
            //alert("EndOn date must be greater than StartOn date");
            console.log("edit News error  line no:  2922");
        }

    }


    $scope.enterBrands = function()
    {
        $scope.idArray2=[];


        return $q(function(resolve,reject) {

            if($scope.brand != ''){
                $scope.brand.forEach(function(obj) {

                    if (obj.id == undefined || obj.id == null) {

                        var obj2={id:0, name:obj.text, type:2, from:$scope.priceFrom, to:$scope.priceTo};

                        $http({

                            method: 'POST',
                            url: '/users/createBrands/',
                            data:obj2

                        }).then(
                            function successCallBack(res) {
                                var obj = res.data;

                                $scope.idArray2.push(obj.data.id);
                                if($scope.idArray2.length == $scope.brand.length)
                                {
                                    // console.log("idArray2 if::   ",$scope.brand.length);
                                    resolve($scope.idArray2);
                                }
                                //console.log(obj);
                                console.log("brands creation started");

                            },
                            function errorCallBack(res) {

                                console.log("error getStep1");
                                reject(res);
                            }
                        );
                    }

                    else {
                        // console.log('brands else :: ' + obj.id);
                        $scope.idArray2.push(parseInt(obj.id));
                        if($scope.idArray2.length == $scope.brand.length)
                        {
                            //  console.log("i ::   &  ",$scope.brand.length);
                            resolve($scope.brand);
                        }
                    }
                })
            }
            else {
                resolve([]);
            }
        })

    }



    $scope.enterPR = function()
    {

        $scope.idArray3 = [];

        return $q(function(resolve,reject) {

            if (typeof $scope.priceFrom != 'undefined' && typeof $scope.priceTo != 'undefined') {

                var tagName1=$scope.priceFrom.toString().concat("-".concat($scope.priceTo.toString()));
                //console.log(tagName1);

                var obj3={id:0, name:tagName1, type:3, from:$scope.priceFrom, to:$scope.priceTo};

                $http({

                    method: 'POST',
                    url: '/users/createPrice/',
                    data:obj3

                }).then(
                    function successCallBack(res) {
                        var obj = res.data;
                        var data = obj.data;
                        $scope.idArray3.push(obj.data.id);

                        //console.log($scope.priceTo);
                        // console.log(data);
                        // console.log("price creation started");
                        if($scope.idArray3.length == 1)
                        {
                            //  console.log("idArray3 if::    ",$scope.idArray3.length);
                            resolve($scope.idArray3);
                        }

                    },
                    function errorCallBack(res) {

                        console.log("error getStep1");
                        reject(res);
                    });

            }
            else {
                resolve([]);
            }

        })

    }



    $scope.enterTags = function()
    {
        $scope.idArray1 = [];


        return $q(function(resolve,reject){

            console.log("$scope.tagIn  : " + JSON.stringify($scope.tagIn));
            console.log($scope.tagIn);
            console.log("$scope.tagIn  : ");

            var newtags = [];

            $scope.tagIn.forEach(function(obj) {


                if (obj.id == undefined || obj.id == null) {

                    newtags.push(obj.text);

                    var obj1={id:0, name:obj.text, type:1,from:$scope.priceFrom, to:$scope.priceTo};

                    $http({

                        method: 'POST',
                        url: '/users/createTags/',
                        data:obj1

                    }).then(
                        function successCallBack(res) {
                            var obj = res.data;

                            $scope.idArray1.push(obj.data.id);

                            console.log(obj.data);
                            console.log("tags creation started type1");
                            if( $scope.idArray1.length == $scope.tagIn.length)
                            {
                                console.log("idArray1 if::   ",$scope.brand.length);
                                resolve($scope.idArray1);
                            }


                        },
                        function errorCallBack(res) {

                            console.log("error getStep1");
                            reject(res);
                        }
                    );

                }
                else {
                    console.log('pushing1 :: ' + obj.id);
                    $scope.idArray1.push(parseInt(obj.id));
                    if( $scope.idArray1.length == $scope.tagIn.length)
                    {
                        console.log("idArray1 if::   ",$scope.tagIn.length);
                        resolve($scope.idArray1);
                    }
                }
            })



        })

    }



    $scope.addStep4 = function()
    {

        console.log("$scope.specialCharB  : "+$scope.specialCharB);
        console.log("$scope.idArray2  : "+$scope.idArray2);
        console.log("$scope.priceTo  : "+$scope.priceTo);
        console.log("$scope.priceFrom  : "+$scope.priceFrom);
        console.log("$scope.priceTo>$scope.priceFrom  :  "+$scope.priceTo>$scope.priceFrom);

        if(!$scope.specialCharT && (!$scope.specialCharB || typeof $scope.idArray2=='undefined')&&
            ($scope.priceTo>$scope.priceFrom||(typeof $scope.priceFrom=='undefined'
            && typeof $scope.priceTo=='undefined')))
        {
            console.log("addSTep4 called");
            var promiseTags = $scope.enterTags();
            promiseTags.then(function(success){ $scope.tags = success.idArray1;
                console.log("$scope.tags  :  ",success);
                var promiseBrands = $scope.enterBrands();
                promiseBrands.then(function (success){ $scope.tBrands = success.idArray2;
                    console.log("$scope.tBrands  :  ",success);},function(error){console.log("eror brnd",error);});
                var promisePR = $scope.enterPR();
                promisePR.then(function (success) {

                    $scope.processing=true;

                    var obj = {

                        tags: $scope.idArray1,
                        tBrands: $scope.idArray2,
                        tPR: $scope.idArray3,
                        newsId: newsId,
                        cBy: loginId
                    };
                    console.log("obj addStep4  : " + JSON.stringify(obj));

                    $http({

                        method:'POST',
                        url : '/users/updateStep4R',
                        data:obj
                    }).then(function successCallBack(res) {

                            console.log("res after updateStep4 :  ",JSON.stringify(res.data));
                            $window.location = "#/users/step5R/" + campId + '/' + newsId;
                        },
                        function errorCallBack(res){
                            $scope.processing=false;
                            console.log(res.data);
                        })
                }, function (error) {
                    console.log("error  : ", error);
                })

            },function(error){console.log("eror tags    ",error);});
        }
        else
        {
            console.log("Validation problem line no. 3171");
        }}

}]);


sampleApp.controller('campaignStep5CtrlR', ['$filter','$scope', '$routeParams','$http','$q', '$cookies', '$cookieStore', '$window','$timeout',function ($filter,$scope,$routeParams, $http,$q,$cookies, $cookieStore, $window, $timeout)
{



    $scope.domains=[];

    $scope.device = "0";
    $scope.domainType ="source";
    $scope.returnType = "0";
    $scope.resTime = 0;
    var newsId = $routeParams.newsId;
    $scope.otherCountry = true;

    $scope.cityTagBoolean = false;
    $scope.citySelected=[];
    $scope.countriesArray = [];
    $scope.citiesTag=[]
    $scope.$watch('citySelected',function(newVal,oldVal){

        $scope.citiesTag=[];
        console.log("$scope.citySelected  : ",$scope.citySelected);
        if(typeof $scope.citySelected != "undefined" && $scope.citySelected!='')
        {
            $scope.citySelected.forEach(function(obj)
            {
                if(typeof obj.id!="undefined" && $scope.citiesTag.indexOf(obj.id)==-1)
                {
                    console.log("hey u called");
                    $scope.citiesTag.push(obj.id);

                    console.log("$scope.citiesTag   :  ",$scope.citiesTag);
                }
            })
        }
        else
        {
            console.log("citiesTag  : "+$scope.citiesTag);

        }

    },true)


    $scope.getCountry = function() {
        var deferred = $q.defer();

        $http({
            url: 'users/getCountries',
            method: 'POST'
        }).then(
            function success(res) {
                console.log("getting coutries  :", res.data.data);
                $scope.countriesArray = res.data.data;
                console.log($scope.countriesArray);
                deferred.resolve($scope.countriesArray);
                //$scope.target.country=$scope.countriesArray[0].id;
                /*$scope.countSubscriber();*/
            },
            function error(res) {
                console.log("error in getting countries");
                console.log(res.data);
                deferred.reject(res.data);
            }
        );
        return deferred.promise;
    }



    $scope.cityTags = [];
    var promiseCountry = $scope.getCountry();
    if(typeof $scope.target!= 'undefined') {
        promiseCountry.then(function (successRes) {

            /* var countryObj = {"name":"","id":""}
             countryObj = $scope.target.country;
             var countryId = JSON.parse(countryObj).id;*/
            console.log("promiseCountry success");
            var countryId = $scope.target.country;

            var obj = {countryId: countryId};
            console.log("getcity obj id : ", countryId);
            console.log(countryId);
            $http({
                url: "users/getCities",
                method: "POST",
                data: obj
            }).then(function success(res) {

                console.log("res  :", res);

                var resObj = res.data;
                $scope.citiesArray = resObj.data;
                console.log("res.data.data  : ", res.data);
                $scope.cityTags = [];
                $timeout(function () {
                    $scope.citiesArray.forEach(function (obj) {
                        //  console.log("obj  ",obj);
                        $scope.cityTags.push({"text": obj.name, "id": obj.id});
                    })
                }, 100)

                $scope.loadCities = function ($query) {
                    return $scope.cityTags.filter(function (tags) {
                        return tags.text.toLowerCase().indexOf($query.toLowerCase()) != -1;
                    });

                };


            }, function error(res) {
                console.log("error   :", res.data.data);
            })

        }, function (errRes) {

            console.log("error getCity COuntry line : 3393");
            console.log(errRes);
        });
    }



    $scope.getCities = function()
    {
        $scope.otherCountry = false;

        if(!$scope.cityTagBoolean){
            $scope.citySelected=[];
            $scope.citiesTag=[];
        }

        var countryId = $scope.target.country;
        if(countryId != -1){
            var obj = {countryId:countryId};
            console.log("getcity obj id : ",countryId);
            console.log(countryId);
            $http({
                url:"users/getCities",
                method:"POST",
                data:obj
            }).then(function success(res){

                console.log("res  :",res);

                var resObj = res.data;
                $scope.citiesArray = resObj.data;
                console.log("res.data.data  : ",res.data);
                if(!$scope.cityTagBoolean){
                    $scope.cityTags = [];}
                $timeout(function () {
                    $scope.citiesArray.forEach(function(obj)
                    {
                        console.log("obj  ",obj);
                        $scope.cityTags.push({"text":obj.name,"id":obj.id});
                    })
                },100)

                $scope.loadCities = function ($query) {

                    return $scope.cityTags.filter(function (tags) {
                        return tags.text.toLowerCase().indexOf($query.toLowerCase()) != -1;
                    });

                };


            },function error(res)
            {
                console.log("error   :",res.data.data);
            })
        }

    }



    $scope.getSource = function()
    {

        $http({

            method:'POST',
            url:'/users/allDomainsR/'

        }).then(
            function successCallBack(res){

                $scope.domainDetail = res.data;
                console.log($scope.domainDetail);

            },
            function errorCallBack(res){
                console.log("error domain");
            });

    }
    $scope.getSource();

    $scope.selectSource1 = function (bool,v) {
        $scope.showSource1 = bool;
        $scope.source1=v;
        $scope.from = v.id;
        $scope.searchSourceFrom = v.name;
    }

    $scope.selectSource2 = function (bool,v) {
        $scope.showSource2 = bool;
        $scope.source2=v;
        $scope.to = v.id;
        $scope.searchSourceTo = v.name;
    }


    $scope.processing=false;
    $scope.loadTags = function(query) {
        return $http.get('/tags?query=' + query);
    };

    var loginId = $cookieStore.get("userid");


    $scope.updateNewsLetter = function()
    {

        if($scope.domainType=="source"){
            var domObj = {from:$scope.from,to:$scope.to}
        }
        else {
            var domObj = {from:0,to:0}
        }

        var obj = {cBy:loginId,newsId:newsId,dVol:$scope.volume,resTime:$scope.resTime,retType:$scope.returnType,
            domType:domObj,device:$scope.device,campRelName:$scope.news.newsTitle,agentName:$cookieStore.get('userName'),
            campRelName:$scope.news.newsTitle,startOn:$scope.news.startAt,tempVol: $scope.volume,campId:$scope.news.campId,
            SN:$scope.news.SN,SL:$scope.news.SL,creative:$scope.news.creative,countries:$scope.target.country,cities:$scope.citiesTag};
        console.log("obj : "+obj);
        //alert(JSON.stringify(obj));
        $http({

            method:'POST',
            url : '/users/updateNewsR',
            data:obj
        }).then(function successCallback(response) {
            //console.log(response);
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {
                $scope.volume = 0;
                if (response.data.error) {
                    console.log(response.data.error)
                    alert(response.data.error);
                    window.location.href = "#/users/CreateCampaignR";
                } else if (response.data.success) {
                    console.log("updateNewsR successfully executed");
                    alert("Campaign added Successfully");
                } else {
                }

            }
        }, function errorCallback(response) {
            window.location.href = "./";

        });

    }


    var campId = $routeParams.campId;
    /*    $scope.regex ='^[a-zA-Z0-9_ ]*$';*/
    $scope.regex ='^[a-zA-Z0-9_ !@$%&-.]*$';
    $scope.maxlength=100;
    var newsId = $routeParams.newsId;
    $scope.campId = campId;
    $scope.newsId = newsId;

    //alert(campId);
    var loginId = $cookieStore.get("userid");


    $scope.citySelected=[];
    $http({

        method: 'GET',
        url: '/users/getNewsTags/'+$scope.newsId

    }).then(
        function successCallBack(res) {

            if(typeof res.data.targets != 'undefined')
            {
                console.log("response ");
                console.log("res.data.targets  : ", JSON.stringify(res.data.targets));

                if(typeof res.data.targets.gender!='undefined') {
                    $scope.target.gender = res.data.targets.gender;
                }
                if(typeof res.data.targets.age!='undefined') {

                    $scope.fromAge = {"label":parseInt(res.data.targets.age.from)};
                    $scope.toAge = {"label":parseInt(res.data.targets.age.to)};
                }
                if(typeof res.data.targets.eDomain!='undefined') {
                    $scope.eDomain = res.data.targets.eDomain;
                }



                $scope.dVol = res.data.dVol;
                if(typeof res.data.targets.city!='undefined')
                {
                    for(var i=0;i<res.data.targets.city.length;i++)
                    {
                        var cityObj = {cityId:res.data.targets.city[i]};
                        $http({

                            method: 'POST',
                            url: '/users/getCityById/',
                            data:cityObj

                        }).then(
                            function successCallBack(res) {

                                $scope.citySelected.push({text:res.data.data.name,id:res.data.data.id});
                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }
                }

                var countryObj={countryId:res.data.targets.country}
                $http({

                    method: 'POST',
                    url: '/users/getCountriesById/',
                    data:countryObj

                }).then(
                    function successCallBack(res) {

                        console.log("getCountriesById  res  :  "+JSON.stringify(res.data),"    and  :  ",res.data.data.name);
                        $scope.target.country=res.data.data.id;

                    },
                    function errorCallBack(res) {

                        //alert("error");
                        console.log("error in tags");

                        return res.data;
                    });



                $scope.nCatTags=[];
                $scope.catIds = 0;
                $scope.tagIn = [];
                if(typeof res.data.targets.catTags!='undefined') {
                    for (i = 0; i < res.data.targets.catTags.length; i++) {

                        $scope.catIds = res.data.targets.catTags[i];

                        $http({

                            method: 'GET',
                            url: '/users/getNewsTags1/' + $scope.catIds


                        }).then(
                            function successCallBack(res) {
                                console.log("response ");
                                console.log(res);
                                console.log("response of campaingn7 ctrl" + res);

                                console.log("res.data.name...." + res.data.id);

                                $scope.nCatTags.push({"name": res.data.name, "id": res.data.id});
                                $scope.tagIn.push({"text": res.data.name, "id": res.data.id})

                            },
                            function errorCallBack(res) {

                                //alert("error");
                                console.log("error in tags");

                                return res.data;
                            });
                    }
                }


            }
        },
        function errorCallBack(res) {

            //alert("error");
            console.log("error in tags");

            return res.data;
        });



    $http({

        method:'POST',
        url:'/users/getStep1R/'+campId

    }).then(
        function successCallBack(res){

            console.log("res step1 :  ",JSON.stringify(res));
            var obj = res.data;
            var data = obj.data;
            $scope.campName = data.name;
            console.log($scope.campName);
            console.log("NEWS STEP1 start");

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );



    $http({

        method:'POST',
        url:'/users/getStep2R/'+newsId

    }).then(
        function successCallBack(res){

            // console.log("res obj  ",JSON.stringify(res));
            var obj = res.data;
            var data = obj.data;
            $scope.news={newsTitle:data.title,type:data.type,startOn:$filter('date')(new Date(data.startOn*1000),'yyyy-MM-dd')
                ,endOn:$filter('date')(new Date(data.endOn*1000),'yyyy-MM-dd'),roi:data.roi,tags:data.tags,tBrands:data.tBrands,tPR:data.tPR
                ,SN:data.SN,SL:data.SL,creative:data.creative,campId:data.campId,startAt:data.startOn};


            console.log($scope.news);
            console.log("news start");

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );


    $http({

        method: 'POST',
        url: '/users/gettags/'

    }).then(
        function successCallBack(res) {
            console.log("response ");
            console.log(res);
            $scope.tags = res.data;
            // $scope.brand=[];
            $scope.tagNames = [];
            //$scope.tagIds = [];
            $scope.tags.forEach(function (obj) {
                //$scope.tagIds.push(obj.id);
                $scope.tagNames.push({"text": obj.name, "id": obj.id});
            });
            $scope.loadTags = function ($query) {

                return $scope.tagNames.filter(function (tags) {
                    return tags.text.toLowerCase().indexOf($query.toLowerCase()) != -1;
                });

            };

        },
        function errorCallBack(res) {

            //alert("error");
            console.log("error in tags");

            return res.data;
        });


    $scope.countriesArray = [];
    $scope.citiesTag=[]
    $scope.$watch('citySelected',function(newVal,oldVal){

        $scope.citiesTag=[];
        console.log("$scope.citySelected  : ",$scope.citySelected);
        if(typeof $scope.citySelected != "undefined" && $scope.citySelected!='')
        {
            $scope.citySelected.forEach(function(obj)
            {
                if(typeof obj.id!="undefined" && $scope.citiesTag.indexOf(obj.id)==-1)
                {
                    console.log("hey u called");
                    $scope.citiesTag.push(obj.id);
                    // $scope.countSubscriber();
                    console.log("$scope.citiesTag   :  ",$scope.citiesTag);
                }
            })
        }
        else
        {
            console.log("citiesTag  : "+$scope.citiesTag);
            //$scope.countSubscriber();
        }

    },true)

    $scope.getCountry = function() {
        var deferred = $q.defer();

        $http({
            url: 'users/getCountries',
            method: 'POST'
        }).then(
            function success(res) {
                console.log("getting coutries  :", res.data.data);
                $scope.countriesArray = res.data.data;
                console.log($scope.countriesArray);
                deferred.resolve($scope.countriesArray);
                //$scope.target.country=$scope.countriesArray[0].id;
                /*$scope.countSubscriber();*/
            },
            function error(res) {
                console.log("error in getting countries");
                console.log(res.data);
                deferred.reject(res.data);
            }
        );
        return deferred.promise;
    }



    $scope.cityTags = [];
    var promiseCountry = $scope.getCountry();
    if(typeof $scope.target!= 'undefined') {
        promiseCountry.then(function (successRes) {

            /* var countryObj = {"name":"","id":""}
             countryObj = $scope.target.country;
             var countryId = JSON.parse(countryObj).id;*/
            console.log("promiseCountry success");
            var countryId = $scope.target.country;

            var obj = {countryId: countryId};
            console.log("getcity obj id : ", countryId);
            console.log(countryId);
            $http({
                url: "users/getCities",
                method: "POST",
                data: obj
            }).then(function success(res) {

                console.log("res  :", res);

                var resObj = res.data;
                $scope.citiesArray = resObj.data;
                console.log("res.data.data  : ", res.data);
                $scope.cityTags = [];
                $timeout(function () {
                    $scope.citiesArray.forEach(function (obj) {
                        //  console.log("obj  ",obj);
                        $scope.cityTags.push({"text": obj.name, "id": obj.id});
                    })
                }, 100)

                $scope.loadCities = function ($query) {
                    return $scope.cityTags.filter(function (tags) {
                        return tags.text.toLowerCase().indexOf($query.toLowerCase()) != -1;
                    });

                };


            }, function error(res) {
                console.log("error   :", res.data.data);
            })

        }, function (errRes) {

            console.log("error getCity COuntry line : 3393");
            console.log(errRes);
        });
    }



    $scope.getCities = function()
    {

        $scope.citySelected=[];
        $scope.citiesTag=[];
        var countryId = $scope.target.country;
        if(countryId != -1){
            var obj = {countryId:countryId};
            console.log("getcity obj id : ",countryId);
            console.log(countryId);
            $http({
                url:"users/getCities",
                method:"POST",
                data:obj
            }).then(function success(res){

                console.log("res  :",res);

                var resObj = res.data;
                $scope.citiesArray = resObj.data;
                console.log("res.data.data  : ",res.data);
                $scope.cityTags = [];
                $timeout(function () {
                    $scope.citiesArray.forEach(function(obj)
                    {
                        console.log("obj  ",obj);
                        $scope.cityTags.push({"text":obj.name,"id":obj.id});
                    })
                },100)

                $scope.loadCities = function ($query) {

                    return $scope.cityTags.filter(function (tags) {
                        return tags.text.toLowerCase().indexOf($query.toLowerCase()) != -1;
                    });

                };
            },function error(res)
            {
                console.log("error   :",res.data.data);
            })
        }
    }



    $scope.loadTags = function(query) {
        return $scope.cityTags;
    };

    $scope.showCamp = true;
    $scope.alterEdit = function()
    {
        $scope.showCamp = false;
    }

    $scope.showNews = true;
    $scope.alterNews = function()
    {
        $scope.showNews = false;
    }


    $scope.editCamp = function(){

        var obj = {campName : $scope.campName,userId:loginId, campId : campId};
        $http({

            method:'POST',
            url : '/users/editCamp',
            data:obj
        }).then(function successCallBack(res){

                var obj = res.data;
                console.log("obj");
                console.log(obj);
                var data = obj.data;
                var campName = data.$set.name;
                var campId = data.id;

                console.log(campName);
                //  $routeParams.campName =campName;
                // $routeParams.campId = campId;
                $window.location ='#/users/step5R/'+campId+'/'+newsId;
                $scope.showCamp=true;

            },
            function errorCallBack(res){
                console.log(res.data);
            })

    }


    $scope.editNews = function(news){

        alert("2755");
        alert(news);
        console.log(news);
        var d1 = new Date(news.startOn);
        var date1 = d1.setHours(0, 0, 0,0);
        var startOn =  date1/ 1000;

        var d2 = new Date(news.endOn);
        var date2 = d2.setHours(0, 0, 0,0);
        var endOn =  date2/ 1000;


        if(startOn<=endOn) {
            var obj = {
                title: news.title,
                campId: campId,
                type: news.type,
                roi: news.roi,
                cBy: loginId,
                startOn: startOn,
                endOn: endOn,
                newsId: newsId
            };

            // var obj ={title:news.title,campId:campId,type:news.type,roi:news.roi,cBy:loginId,startOn:news.startOn,endOn:news.endOn,newsId:newsId};
            $http({
                method: 'POST',
                url: '/users/editNewsR',
                data: obj
            }).then(function successCallBack(res) {

                    var obj = res.data;
                    console.log("obj edit news");
                    console.log(obj);
                    var data = obj.data;
                    console.log(data);

                    $window.location = '#/users/step5R/' + campId + '/' + newsId;
                    $scope.showNews=true;

                },
                function errorCallBack(res) {
                    console.log(res.data);
                })
        }
        else {
            alert("EndOn date must be greater than StartOn date");
        }

    }


    $scope.target={country:""};

    $scope.tagId = [];

    $scope.enterTags = function()
    {
        $scope.idArray1 = [];

        return $q(function(resolve,reject){

            console.log("$scope.tagIn  : " + JSON.stringify($scope.tagIn));
            console.log($scope.tagIn);
            console.log("$scope.tagIn  : ");

            var newtags = [];

            $scope.tagIn.forEach(function(obj) {


                if (obj.id == undefined || obj.id == null) {

                    newtags.push(obj.text);

                    var obj1={id:0, name:obj.text, type:1,from:$scope.priceFrom, to:$scope.priceTo};

                    $http({

                        method: 'POST',
                        url: '/users/createTags/',
                        data:obj1

                    }).then(
                        function successCallBack(res) {
                            var obj = res.data;

                            $scope.idArray1.push(obj.data.id);

                            console.log(obj.data);
                            console.log("tags creation started type1");
                            if( $scope.idArray1.length == $scope.tagIn.length)
                            {
                                console.log("idArray1 if::   ",JSON.stringify($scope.idArray1));
                                resolve($scope.idArray1);
                            }


                        },
                        function errorCallBack(res) {

                            console.log("error getStep1");
                            reject(res);
                        }
                    );

                }
                else {
                    console.log('pushing1 :: ' + obj.id);
                    $scope.idArray1.push(parseInt(obj.id));
                    if( $scope.idArray1.length == $scope.tagIn.length)
                    {
                        console.log("idArray1 if::   ",$scope.tagIn.length);
                        resolve($scope.idArray1);
                    }
                }
            })

        })

    }
    $scope.ages = [];

    for(var i=1;i<100;i++){
        $scope.ages.push({"label":i});
    }
    $scope.toAge={};
    $scope.fromAge={};
    $scope.searchSub = false;
    $scope.singleCall = true;
    var d = new Date();
    $scope.currentYear = d.getFullYear();
    $scope.countSubscriber = function()
    {
        if(typeof $scope.targetSuccess != 'undefined'){

            console.log("countSubscriber called");
            $scope.countSUB = 0;
            if(typeof $scope.fromAge.label != 'undefined' && typeof $scope.toAge.label != 'undefined')
            {
                $scope.age1 = {to: $scope.currentYear-$scope.fromAge.label, from: $scope.currentYear-$scope.toAge.label};
            }
            $scope.ageBoolean = true;

            if(typeof $scope.toAge.label == 'undefined' || typeof $scope.fromAge.label == 'undefined')
            {
                $scope.ageBoolean = false;
                if(typeof $scope.toAge.label == 'undefined' && typeof $scope.fromAge.label == 'undefined')
                {
                    $scope.ageBoolean = true;
                }
            }
            else if($scope.fromAge.label>$scope.toAge.label){
                $scope.ageBoolean = false;
            }
            else{
                $scope.ageBoolean = true;
            }


            var obj = {
                esp: $scope.eDomain,
                age: $scope.age1,
                gender: $scope.target.gender,
                countries: $scope.target.country,
                cities: $scope.citiesTag /*catTags:$scope.catTags,dVol:$scope.dVol,newsId:newsId*/
                ,catTags:$scope.catTags
            };

            console.log(" countSubscriber obj : " + JSON.stringify(obj));

            if(!$scope.singleCall)
            {
                alert("Please Wait one request is under process");
            }
            /*        if(typeof obj.esp!="undefined" && obj.countries!='' && obj.esp!='' && typeof obj.countries!="undefined" && $scope.ageBoolean && $scope.singleCall)*/
            if($scope.ageBoolean && $scope.singleCall)
            {
                //alert("sub called");
                $scope.singleCall = false;
                $scope.searchSub = false;
                $http({

                    method: 'POST',
                    url: '/users/countSub',
                    data: obj
                }).then(function successCallBack(res) {
                        //alert("result arrived");
                        $scope.countSUB = res.data.count;
                        $scope.singleCall = true;
                        //console.log("successcallback coujnt subscriber  :   "+res.data.count);
                        console.log("$scope.countSUB" + $scope.countSUB);
                        $scope.searchSub = true;
                    },
                    function errorCallBack(res) {
                        $scope.singleCall = true;
                        console.log("error callback  !");
                        console.log(res.data);
                    })
            }
            else {
                console.log("counsub not executed");
            }

        }};


    $scope.catTags=[];
    $scope.$watch('tagIn',function(newVal,oldVal){

        $scope.catTags = [];
        console.log("tagIn catogory tags  : ",$scope.tagIn);
        if(typeof $scope.tagIn != "undefined" && $scope.tagIn!=''){

            $scope.tagIn.forEach(function(obj)
            {
                if(typeof obj.id!="undefined"){

                    $scope.catTags.push(obj.id);
                    //$scope.countSubscriber();
                    $scope.getCatTags();

                }

            })
        }
        else {
            //$scope.countSubscriber();
        }

    },true)




    $scope.getCatTags=function () {

        var promiseCatogory = $scope.enterTags();
        promiseCatogory.then(function(successRes){

            console.log("success promise addstep5");

            $scope.catTags = successRes;
            console.log($scope.catTags);


        },function(errRes){

            console.log("error --------");
            console.log(errRes);
        })

    }

    $scope.addStep5 = function()
    {
        $scope.processing=true;
        //add callback for below function
        //alert("addStep5");
        /*  if(typeof $scope.citySelected != "undefined"){
         $scope.citySelected.forEach(function(obj)
         {
         $scope.citiesTag.push(obj.id);
         })
         }*/


        /* var countryObj = $scope.target.country;

         var countryTags =[JSON.parse(countryObj).id];*/

        $scope.age1 = {to:$scope.toAge.label,from:$scope.fromAge.label};

        console.log("age  : ",$scope.age1);
        $scope.age = 1990;

        var obj ={eDomain:$scope.eDomain,age:$scope.age1,
            gender:$scope.target.gender,countries:$scope.target.country,
            cities:$scope.citiesTag,catTags:$scope.catTags,
            cBy:loginId,dVol:$scope.dVol,newsId:newsId};


        if(typeof $scope.resTime !='undefined' && $scope.resTime != ''){
            obj.resTime = $scope.resTime;
            console.log("obj.resTime  :  "+obj.resTime);
        }
        if(typeof $scope.returnType !='undefined' && $scope.returnType != ''){
            obj.returnType = $scope.returnType;
            console.log("obj.returnType  :  "+obj.returnType);
        }
        if(typeof $scope.domainType!='undefined' && $scope.domainType != ''){
            if($scope.domainType == 'other')
            {
                obj.domainType = {'other' :$scope.domainTypeIp};
            }
            else {
                obj.domainType = {'source' :$scope.domainTypeIp};
            }
            /* obj.domainType = $scope.domainType;*/
            console.log("obj.domainType  :  "+obj.domainType);
        }
        if(typeof $scope.device !='undefined' && $scope.device != ''){
            obj.device = $scope.device;
            console.log("obj.device  :  "+obj.device);
        }


        //alert('obj :: '+JSON.stringify(obj));
        console.log("obj : "+JSON.stringify(obj));

        //alert("objects : "+JSON.stringify(obj));

        $http({
            method:'POST',
            url : '/users/updateStep5R',
            data:obj
        }).then(function successCallBack(res) {

                console.log("successcallback step5  :   ",res);
                console.log(JSON.stringify(res));
                $window.location = "#/users/step6R/" + campId + '/' + newsId;
            },
            function errorCallBack(res){
                $scope.processing=false;
                console.log("error callback  !");
                console.log(res.data);
            })

    }


}]);


sampleApp.controller('campaignStep6CtrlR', ['$notification','$log','$filter','$scope', '$routeParams','$http','$q', '$cookies', '$cookieStore', '$window','$timeout' ,function ($notification,$log,$filter,$scope,$routeParams, $http,$q,$cookies, $cookieStore, $window, $timeout) {



    $scope.processing=false;
    var campId = $routeParams.campId;
    /*    $scope.regex ='^[a-zA-Z0-9_ ]*$';*/
    $scope.regex ='^[a-zA-Z0-9_ !@$%&-.]*$';
    $scope.maxlength=100;
    var newsId = $routeParams.newsId;
    $scope.campId = campId;
    $scope.newsId = newsId;

    //alert(campId);
    var loginId = $cookieStore.get("userid");

    $scope.tagIn=[];

    $http({

        method: 'GET',
        url: '/users/getNewsTags/'+newsId

    }).then(
        function successCallBack(res) {
            console.log("response ");
            console.log(res);
            console.log("response of campaingn6 ctrl"+JSON.stringify(res));
            $scope.newsTags = res.data.tags;
            $scope.brandsTags = res.data.tBrands;
            $scope.tPRTags = res.data.tPR;

            $scope.catTags = res.data.targets.catTags;
            $scope.nTags=[];
            $scope.newsTagIds = 0;
            if(typeof res.data.tags != 'undefined'){
                for(i=0;i<res.data.tags.length; i++){
                    //$scope.newsTagIds.push(res.data.tags[i]);
                    $scope.newsTagIds=res.data.tags[i] ;
                    $http({

                        method: 'GET',
                        url: '/users/getNewsTags1/'+$scope.newsTagIds

                    }).then(
                        function successCallBack(res) {
                            console.log("response ");
                            console.log(res);
                            console.log("response of campaingn7 ctrl"+res);
                            $scope.news1Tags = res.data;

                            console.log("res.data.name...."+res.data.id);

                            $scope.nTags.push({"name":res.data.name, "id":res.data.id});
                            $scope.tagIn.push({"text":res.data.name, "id":res.data.id});

                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });
                }
            }
            //brands from newsletter

            $scope.nBrands=[];
            $scope.newsBrandIds = 0;
            if(typeof res.data.tBrands != 'undefined') {
                for (i = 0; i < res.data.tBrands.length; i++) {
                    //$scope.newsTagIds.push(res.data.tags[i]);
                    $scope.newsBrandIds = res.data.tBrands[i];


                    $http({

                        method: 'GET',
                        url: '/users/getNewsTags1/' + $scope.newsBrandIds


                    }).then(
                        function successCallBack(res) {
                            console.log("response ");
                            console.log(res);
                            console.log("response of campaingn7 ctrl" + res);
                            $scope.brand1Tags = res.data;

                            console.log("res.data.name...." + res.data.id);

                            $scope.nBrands.push({"name": res.data.name, "id": res.data.id});


                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });
                }
            }

            $scope.ntPRs=[];
            $scope.newstPrIds = 0;
            if(typeof res.data.tPR != 'undefined') {
                for (i = 0; i < res.data.tPR.length; i++) {
                    //$scope.newsTagIds.push(res.data.tags[i]);
                    $scope.newstPrIds = res.data.tPR[i];


                    $http({

                        method: 'GET',
                        url: '/users/getNewsTags1/' + $scope.newstPrIds


                    }).then(
                        function successCallBack(res) {
                            console.log("response ");

                            console.log("res.data.name...." + res.data.id);

                            $scope.ntPRs.push({"name": res.data.name, "id": res.data.id});


                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });
                }
            }
            //catTags from newsletter

            $scope.nCatTags=[];
            $scope.catIds = 0;
            if(typeof res.data.targets.catTags != 'undefined'){
                for(i=0;i<res.data.targets.catTags.length; i++){

                    $scope.catIds=res.data.targets.catTags[i] ;

                    $http({

                        method: 'GET',
                        url: '/users/getNewsTags1/'+$scope.catIds


                    }).then(
                        function successCallBack(res) {
                            console.log("response ");
                            console.log(res);
                            console.log("response of campaingn7 ctrl"+res);

                            console.log("res.data.name...."+res.data.id);

                            $scope.nCatTags.push({"name":res.data.name, "id":res.data.id});


                        },
                        function errorCallBack(res) {

                            //alert("error");
                            console.log("error in tags");

                            return res.data;
                        });
                }
            }




        },
        function errorCallBack(res) {

            //alert("error");
            console.log("error in tags");

            return res.data;
        });




    $scope.loadTags = function(query) {
        return $http.get('/tags?query=' + query);
    };




    //code from step4Ctrl



    $http({

        method: 'POST',
        url: '/users/gettags/'

    }).then(
        function successCallBack(res) {
            console.log("response ");
            console.log(res);
            $scope.tags = res.data;
            // $scope.brand=[];
            $scope.tagNames = [];
            //$scope.tagIds = [];
            $scope.tags.forEach(function (obj) {
                //$scope.tagIds.push(obj.id);
                $scope.tagNames.push({"text": obj.name, "id": obj.id});
            });
            $scope.loadTags = function ($query) {

                return $scope.tagNames.filter(function (tags) {
                    return tags.text.toLowerCase().indexOf($query.toLowerCase()) != -1;
                });

            };
            /*res.data.forEach(function(obj) {
             $scope.brand.push(obj.id);

             });*/


        },
        function errorCallBack(res) {

            //alert("error");
            console.log("error in tags");

            return res.data;
        });




    $http({

        method:'POST',
        url:'/users/getStep1R/'+campId

    }).then(
        function successCallBack(res){

            var obj = res.data;
            var data = obj.data;
            $scope.campName = data.name;
            console.log($scope.campName);
            console.log("NEWS STEP1 start");

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );


    $http({

        method:'POST',
        url:'/users/getStep2R/'+newsId

    }).then(
        function successCallBack(res){

            var obj = res.data;
            var data = obj.data;


            console.log("obj");
            console.log(JSON.stringify(obj));
            console.log("data");
            console.log(JSON.stringify( data));


            $scope.news={newsTitle:data.title,type:data.type,startOn:$filter('date')(new Date(data.startOn*1000),'yyyy-MM-dd')
                ,endOn:$filter('date')(new Date(data.endOn*1000),'yyyy-MM-dd'),roi:data.roi,SN:data.SN,SL:data.SL,creative:data.creative,volume:data.dVol,targets:data.targets,startOn:data.startOn
                ,cBy:data.cBy};


            /* $scope.news.newsTitle = data.title;
             $scope.news.type = data.type;
             $scope.news.startOn = new Date(data.startOn);
             $scope.news.endOn = new Date(data.endOn);
             $scope.news.roi = data.roi;*/

            document.getElementById("modelHTML").innerHTML=$scope.news.creative;
            console.log($scope.news);
            console.log("news start");

        },
        function errorCallBack(res){

            console.log("error getStep1");
        }
    );






    $scope.showCamp = true;
    $scope.alterEdit = function()
    {
        $scope.showCamp = false;
    }

    $scope.showNews = true;
    $scope.alterNews = function()
    {
        $scope.showNews = false;
    }

    $scope.removeSender=function(index)
    {
        $scope.news.SN.splice(index,1);
    }
    $scope.removeSubject=function(index)
    {
        $scope.news.SL.splice(index,1);
    }
    $scope.showTags=false;
    $scope.editTagsStep6 = function()
    {
        $scope.showTags = true;


    }

    $scope.showCats=false;
    $scope.editCatogories = function()
    {
        $scope.showCats = true;
    }
    $scope.editCamp = function(){

        var obj = {campName : $scope.campName,userId:loginId, campId : campId};
        $http({

            method:'POST',
            url : '/users/editCamp',
            data:obj

        }).then(function successCallBack(res){

                var obj = res.data;
                console.log("obj");
                console.log(obj);
                var data = obj.data;
                var campName = data.$set.name;

                var campId = data.id;

                console.log(campName);
                //  $routeParams.campName =campName;
                // $routeParams.campId = campId;
                $window.location ='#/users/step3R/'+campId+'/'+$scope.newsId;

            },
            function errorCallBack(res){
                console.log(res.data);
            })

    }


    $scope.editNews = function(news)
    {
        alert("3329");
        alert(news);
        console.log(news);
        var d1 = new Date(news.startOn);
        var date1 = d1.setHours(0, 0, 0,0);
        var startOn =  date1/ 1000;

        var d2 = new Date(news.endOn);
        var date2 = d2.setHours(0, 0, 0,0);
        var endOn =  date2/ 1000;

        /*  var date1=new Date(news.startOn).toISOString().substr(0, 10);
         var startOn=Math.round((new Date(date1+" 00:00:00")).getTime() / 1000)
         var date2=new Date(news.endOn).toISOString().substr(0, 10);
         var endOn=Math.round((new Date(date2+" 00:00:00")).getTime() / 1000)*/

        /*   var d1 = news.startOn;
         var date1 = new Date(d1.split(' ').join('T'))
         var startOn =  date1.getTime() / 1000;
         var d2 = news.endOn;
         var date2 = new Date(d2.split(' ').join('T'))
         var endOn =  date2.getTime() / 1000;*/

        if(startOn<=endOn) {
            var obj = {
                title: news.title,
                campId: campId,
                type: news.type,
                roi: news.roi,
                cBy: loginId,
                startOn: startOn,
                endOn: endOn,
                newsId: newsId
            };
            $http({
                method: 'POST',
                url: '/users/editNewsR',
                data: obj
            }).then(function successCallBack(res) {

                    var obj = res.data;
                    console.log("obj edit news");
                    console.log(obj);
                    var data = obj.data;
                    console.log(data);

                    //  $routeParams.campName =campName;
                    // $routeParams.campId = campId;
                    $window.location = '#/users/step4R/' + campId + '/' + newsId;

                },
                function errorCallBack(res) {
                    console.log(res.data);
                })
        }
        else {
            alert("EndOn date must be greater than StartOn date");
        }

    }

    //end of step4Ctrl code


    $scope.campaignSuccess = function()
    {
        var notification = $notification('New message', {
            body: 'Request sent Successfully',
            delay: 2000
        });
    }

    $scope.addStep6 = function()
    {
        //alert("addstep6");
        $scope.processing=true;
        var obj = {cBy:loginId,newsId:newsId};
        console.log("obj : "+obj);

        $http({

            method:'POST',
            url : '/users/updateStep6R',
            data:obj

        }).then(function successCallBack(res) {

                $window.location = "#/users/step7R";
                //alert("reqobj :: "+JSON.stringify(reqobj));

            },
            function errorCallBack(res){
                $scope.processing=false;
                console.log(res.data);
            })

    }


}]);


sampleApp.controller('innerR-campaignsR-controller', ['campaignData0','innerCampEdit0','$window','socket','$scope', '$cookies', '$cookieStore', '$http', function (campaignData0,innerCampEdit0,$window,socket,$scope, $cookies, $cookieStore, $http) {

    //alert("inner campaigns");
    $scope.typeColor = {open:'fa rate-icon blue-1',click:'fa rate-icon green-1',lead:'fa rate-icon orrange-1',push:'fa rate-icon pink-1'};


    var reportId = campaignData0.getCampId();
    var d1 = new Date(campaignData0.getDate());
    var date1 = d1.setHours(0, 0, 0,0);
    var newDate =  date1/ 1000;
    var ctdOn = newDate;


    var loginId = $cookieStore.get("userid");


    $scope.preload = true;
    $scope.campaigns = [];
    $scope.pickedvolumes = [];
    $scope.selected = -1;
    $scope.viewing = null;
    $scope.subjects = [];
    $scope.senders = [];
    $scope.volume = 0;

    $scope.vol = 0;

    $scope.disableAdding = true;

    $scope.backFunction = function()
    {
        campaignData0.setBack(true);
        window.location.href = "#/users/campaignsR/";
    }


    $scope.startRetargetCamp = function(newsId,status)
    {

           obj = {"status":0,"newsId":newsId}

        $http({
            method: 'POST',
            url: 'users/newLetterUpdate',
            data:obj
        }).then(function successCallback(response) {

            // console.log("response : ",response);
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1)
            {
                window.location.href = "./";
            } else
            {
                console.log("response.data  14431: "+JSON.stringify(response.data));
                window.location.href = "#users/innerCampaignR";
            }
        }, function errorCallback(response) {
            console.log("startRetargetCamp error 14434");
        });

    }

    $scope.stopRetargetCamp = function(newsId,status)
    {

        var obj = {"status":3,"newsId":newsId}
        $http({
            method: 'POST',
            url: 'users/newLetterUpdate',
            data:obj
        }).then(function successCallback(response) {
            //console.log("response : ",response);
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {

                console.log("response 14453 : "+response.data);
                console.log("response 14454 : "+JSON.stringify(response.data));
                window.location.href = "#users/innerCampaignR";

            }
        }, function errorCallback(response) {
            console.log("stop retargetCamp res error : 14458");
        });
    }

    $scope.editInnerCamp = function(camp)
    {

        innerCampEdit0.setNlmId(camp.id);
        innerCampEdit0.setUserId(camp.userRel.id);
        innerCampEdit0.setCtdOn(ctdOn);
        innerCampEdit0.setCampId(reportId);
        var campId=camp.campRel.id;
        var nlmId=camp.id;

        $http({
            method: 'POST',
            url: '/users/getNlIdOnNewsId',
            data:{"campId":campId,"nlmId":nlmId}
        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1)
                {
                    window.location.href = "./";
                }
                else
                {
                   // console.log("response 14479 : "+JSON.stringify(response.data)," response.data.id  "+response.data[0].id);
                    if(typeof response.data[0].id != 'undefined' && response.data[0].id != null)
                    {
                        innerCampEdit0.setNlId(response.data[0].id);
                        window.location.href = "#/users/innerCampR";
                    }


                }
            }
            , function errorCallback(response) {
                alert('getNlIdOnNewsId' + JSON.stringify(response));
            });



    }

    $scope.startTestMail = function(camp)
    {
        innerCampEdit0.setNlmId(camp.id);
        innerCampEdit0.setUserId(camp.userRel.id);
        innerCampEdit0.setCtdOn(ctdOn);
        innerCampEdit0.setCampId(reportId);
        window.location.href = "#/users/startRetarget";

    }



    $scope.loadToday = function () {

        var id = $cookieStore.get("userid");
        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {
            var obj = {"where":{ "campId":reportId,"ctdOn":ctdOn }};
            $http({
                method: 'POST',
                url: 'users/getInnerCampaignsR',
                data:{url:"api/nlm/query?filter="+JSON.stringify(obj)}
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1)
                {
                    window.location.href = "./";
                } else
                {
                    $scope.campaigns = response.data;
                    // console.log("$scope.campaigns  : "+JSON.stringify($scope.campaigns));
                    $scope.preload = false;
                    //console.log('check');
                    //console.log($scope.pickedvolumes);
                    // console.log('check');
                    for (cmp in $scope.campaigns) {
                        // alert($scope.campaigns[cmp].id);
                        var idstring=''+$scope.campaigns[cmp].id;
                        if ($scope.pickedvolumes[idstring] == undefined || $scope.pickedvolumes[idstring] == null) {
                            $scope.pickedvolumes[$scope.campaigns[cmp].id] = 0;
                        }
                        /*if ($scope.pickedvolumes[cmp.id] == undefined || $scope.pickedvolumes[cmp.id] == null) {
                         $scope.pickedvolumes[$scope.campaigns[cmp].id] = 0;
                         }*/
                    }
                    //console.log($scope.pickedvolumes);
                    //console.log('check');
                }

            }, function errorCallback(response) {
                //alert('error' + response);
                console.log(response);
            });
        }
    }

    $scope.selecteddvol=0;
    $scope.selectedpvol=0;
    $scope.loadToday();
    $scope.getUserDomain = function(){

        $http({
            method: 'POST',
            url: 'users/getUserDomain'
        }).then(function successCallback(response) {
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {

                var obj=response.data;
                $scope.userDomains=obj.data;
                //console.log("getUserDomain:   ",$scope.userDomains);
                if($scope.userDomains == '' || $scope.userDomains == null)
                {
                    alert("No Domains alloted to you please contact admin");
                    $("#myModal").modal('hide');
                }
                else {
                    $("#myModal").modal('show');
                }
            }

        }, function errorCallback(response) {
            console.log('error');
            console.log(response);
        });

    }


    $scope.addToMineShow = function (x, dvol, pvol) {

        //$("#myModal").modal('hide');

        $scope.remaining = dvol - pvol;
        //alert(pvol+" and remaining is  :  "+$scope.remaining);
        if($scope.remaining<=0){

            alert("No remaining vol to sent campaign");
            //$("#myModal").modal('hide');

        }else{

            console.log(dvol);
            console.log(pvol);
            $scope.selecteddvol=dvol;
            $scope.selectedpvol=pvol;
            console.log(dvol - pvol);
            $scope.selected = parseInt(x);

            if (!isNaN($scope.remaining) && $scope.remaining > 0) {
                $scope.disableAdding = false;
            } else {
                console.log('cannot enable add button');
            }
        }

        $scope.getUserDomain();
    };


    $scope.addToMineClose = function () {
        $scope.disableAdding = false;
        $scope.selected = -1;
        /* $scope.volume = 0;
         $scope.selecteddvol=0;
         $scope.selectedpvol=0;*/
    };


    $scope.addToMine = function (vol, campid) {

        var id = $cookieStore.get("userid");
        //alert("addToMine userid  "+id);
        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {
            var obj = {
                "userId": parseInt(id),
                "nlmId": parseInt($scope.selected),
                'pickVol': parseInt($scope.volume)
            }
            console.log(obj);
            $http({
                method: 'POST',
                url: 'users/allotToMe',
                data: obj
            }).then(function successCallback(response) {
                console.log(response);
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    $scope.volume = 0;
                    if (response.data.error) {
                        console.log(response.data.error)
                        alert(response.data.error);
                    } else if (response.data.success) {
                        console.log(response.data.success)
                        alert("Campaign added Successfully");
                        $scope.loadToday();
                    } else {
                    }
                }
            }, function errorCallback(response) {
                window.location.href = "./";
                /*   alert('error1' + response);*/
            });
        }
    };


    $scope.updateNewsLetter = function(camp)
    {
        var obj = {cBy:loginId,newsId:camp.id,dVol:camp.dVol};
        console.log("obj : "+obj);
        //alert(JSON.stringify(obj));
        $http({

            method:'POST',
            url : '/users/updateNews',
            data:obj
        }).then(function successCallBack(res) {

                //alert("res   :  "+JSON.stringify(res));
                if(res.data.statusCode == 200){

                    alert("Campaign Started Successfully");
                    $window.location = "#/users/campaignsR"
                }
                else {
                    alert("something went wrong");
                }

            },
            function errorCallBack(res){
                alert("error updateNEws");
                console.log(res.data);
            })
    }

}]);


sampleApp.controller('draftsCtrlR', ['$rootScope','$filter','$window','socket','$scope', '$cookies', '$cookieStore', '$http', function ($rootScope,$filter,$window,socket,$scope, $cookies, $cookieStore, $http)
{

    $scope.iconClick = function () {
        var element = document.getElementById("datePicker1");
        element.focus();
    }



    $scope.typeColor = {open:'fa rate-icon blue-1',click:'fa rate-icon green-1',lead:'fa rate-icon orrange-1',push:'fa rate-icon pink-1'};
    $scope.startOn = $filter('date')(new Date(), 'yyyy-MM-dd');
    //alert("outer campaign ");
    $scope.sortByVar = '-ctdOn';

    if(typeof $rootScope.campDate != 'undefined'){
        $scope.startOn = $filter('date')($rootScope.campDate*1000, 'yyyy-MM-dd');
        $rootScope.campDate=new Date()/1000;
    }

    $scope.changeFilter = function(type)
    {
        $scope.sortByVar = type;
    }

    $scope.filterSort = [{type:'title',show:'Sort by NewsletterTitle'},
        {type:'createdBy',show:'Sort by CreatedBy'}];


    var loginId = $cookieStore.get("userid");
    $scope.loginId = loginId;
    $scope.preload = true;
    $scope.campaigns = [];
    $scope.pickedvolumes = [];
    $scope.selected = -1;
    $scope.viewing = null;
    $scope.subjects = [];
    $scope.senders = [];
    $scope.volume = 0;


    function calculateCamp(campaigns)
    {

        var tempCamp = [];
        var pushCamp = [];

        for (var j=0;j<campaigns.length;j++)
        {
            var i = 0;
            pushCamp=[];
            //alert("j in "+$scope.campNames[j]);
            while(i<campaigns.length)
            {
                if(campaigns[j].title==$scope.campNames[i])
                {
                    tempCamp.push({title:campaigns[j].title,ctdOn:campaigns[j].ctdOn,campId:campaigns[j].campId,
                        createdBy:campaigns[j].userRel.name,cBy:campaigns[j].cBy})
                }
                i++;
            }


        }


        $scope.resultCamp = tempCamp;

    }

    $scope.getCampaigns = function()
    {
        //alert("getCampaigns called");
        $scope.campaigns=[];
        $http({
            method: 'GET',
            url: 'users/getCampaignsR'
        }).then(function successCallback(response) {
            //console.log("response : ",response);
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {

                $scope.campNames=[];
                //console.log("getCampaigns  res  :  ",JSON.stringify(response.data))
                $scope.campaigns=response.data;
                $scope.preload = false;
                //console.log("length  :  "+response.data.length);
                $scope.campIn=[[]];
                for(var i=0;i<response.data.length;i++)
                {

                    var campId = response.data[i].campId;
                    var ctdOn = response.data[i].ctdOn;
                    var newsLetter = response.data[i].title;

                    $http({
                        method: 'POST',
                        url: 'users/getStep1/'+campId
                    }).then(function successCallback(response) {
                            // console.log("response : ",response);
                            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1)
                            {
                                window.location.href = "./";

                            } else
                            {
                                // console.log("response in getCamapaings campaign :  "+JSON.stringify(response.data));
                                $scope.campNames.push(response.data.name);
                            }
                        }
                        , function errorCallback(response) {
                            alert('getCampaigns' + JSON.stringify(response));
                        });
                }
                calculateCamp($scope.campaigns);
            }
        }, function errorCallback(response) {
            alert('getCampaigns' + JSON.stringify(response));
        });

    }

    $scope.getCampaigns();


    $scope.deleteNewsletter = function (id) {

        $http({
            method: 'POST',
            url: 'users/deleteNewsletter/',
            data:{newsId : id}
        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {

                    if(typeof response.data.success != 'undefined'){
                        alert(response.data.success);
                        window.location.href = "#users/drafts";
                    }
                    else if(typeof response.data.error != 'undefined')
                    {
                        alert(response.data.error);
                        window.location.href = "#users/drafts";
                    }
                }
            }
            , function errorCallback(response) {
                alert('deletenewsleter' + JSON.stringify(response));
            });


    }


}]);

sampleApp.filter('emptyFilter', function() {
    return function(array) {
        var filteredArray = [];
        angular.forEach(array, function(item) {
            if (item) filteredArray.push(item);
        });
        return filteredArray;
    };
});



sampleApp.controller('reportsCtrlR', ['reportsData0','$rootScope','$filter','$scope', '$routeParams','$http','$q', '$cookies', '$cookieStore', '$window','$timeout','$q' ,function (reportsData0,$rootScope,$filter,$scope,$routeParams, $http,$q,$cookies, $cookieStore, $window, $timeout,$q) {


    $scope.iconClick = function () {
        var element = document.getElementById("datePicker1");
        element.focus();
    }


    $scope.colors=["visibility-hdn border-yellow","visibility-hdn border-green","visibility-hdn border-orrange"];


    $scope.sortByVar = '-ctdOn';
    $scope.changeFilter = function(type)
    {
        $scope.sortByVar = type;
    }


    $scope.filterSort = [{type:'createdBy',show:'Sort by CreatedBy'},
        {type:'title',show:'Sort by NewsletterTitle'}];



    $scope.reportResult = [];
    $scope.preload = true;
    $scope.startOn = $filter('date')(new Date(), 'yyyy-MM-dd');
    $scope.startOn1 = $filter('date')(new Date().setHours(0, 0, 0, 0)+86400000, 'yyyy-MM-dd');

    if(typeof $rootScope.reportDate != 'undefined'){

        $scope.startOn = $filter('date')(new Date($rootScope.reportDate), 'yyyy-MM-dd');
        $scope.startOn1 = $filter('date')(new Date().setHours(0, 0, 0, 0)+86400000, 'yyyy-MM-dd');
        $rootScope.reportDate=new Date();

    }


    $scope.viewNlReports = function(campId)
    {
        reportsData0.setDate($scope.startOn);
        reportsData0.setDate1($scope.startOn1);
        reportsData0.setCampId(campId);
        window.location.href = "#users/reports2R";
    }

    var date = new Date();
    var date2Day = date.setHours(0, 0, 0, 0);
    var date = new Date();
    //var date2Day1 = date.setHours(0, 0, 0, 0);
    var dateObj = {date2Day: date2Day,date2Day1: date2Day+86400};


    $scope.getReportsNow = function(){

        $scope.reportResult = [];
        $scope.preload = true;

        $http({
            method: 'POST',
            url: '/users/getReportsRetargets',
            data: dateObj
        }).then(function successCallBack(res) {

                var obj = res.data;
                var nlmIds = [];
                console.log("obj reports");
                console.log(obj);
                $scope.reportDetail = obj;
                obj.forEach(function (object) {
                    nlmIds.push(object._id.nlmId);

                });
                var data1 = {nlmIds: nlmIds};
                $http({
                    method: 'POST',
                    url: '/users/getNlmNamesR',
                    data: data1
                }).then(function successCallBack(res) {

                    var obj = res.data;

                    /* console.log("obj getNamesR");
                     console.log(obj);*/


                    var poermain=[];

                    var d=0;
                    // alert($scope.reportDetail.length);
                    function addNames1()
                    {
                        if(d<$scope.reportDetail.length)
                        {
                            var tempmain=$scope.reportDetail[d];
                            // alert(JSON.stringify($scope.reportDetail[d]));
                            var i =0 ;
                            obj.forEach(function (object) {
                                if(object.id==$scope.reportDetail[d]._id.nlmId)
                                {
                                    //alert(JSON.stringify(object));

                                    tempmain["title"]=object.title;
                                    tempmain["SN"] = object.SN;
                                    poermain.push(tempmain);
                                }
                                i++;
                            });

                            d++;
                            addNames1();
                        }
                        else
                        {
                            // alert(JSON.stringify(poermain));
                            $scope.reportResult = poermain;
                            $scope.preload = false;
                            //console.log("$scope.reportDetail   :  ", $scope.reportDetail);
                        }

                    }
                    addNames1();

                });

            },
            function errorCallBack(res) {
                console.log(res.data);
            })

    }


/*$scope.getDomainName = function(nlmId,i){
    $http({
        method:'POST',
        url:'/users/getStep2/'+nlmId


    }).then(
        function successCallBack(res){

            var obj = res.data;
            var data = obj.data;
            console.log("news start : 1  ");
            console.log(new Date(data.startOn*1000));
            $scope.campId = data.campId;

            var d1 = new Date();
            var date1 = d1.setHours(0, 0, 0,0);
            var sentOn =  date1/ 1000;
            var objDom = {campId:data.campId,nlmId:nlmId,sentOn:sentOn}


            $http({
                method: 'POST',
                url: 'users/statsDomains',
                data: objDom
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    var obj=response.data;
                    $scope.reportDetail[i].domain=obj;
                    console.log("$scope.reportDetail[i].domain : i= "+i+" &reportDetail  "+JSON.stringify($scope.reportDetail[i].domain));
                }
            }, function errorCallback(response) {
                console.log('error');
                console.log(response);
            });

        },
        function errorCallBack(res){
            console.log("error getStep1");
        });
}*/


    //$scope.getReportsNow();

    $scope.getNews = function()
    {

        $scope.reportResult = [];
        $scope.preload = true;
       // console.log($scope.startOn);
       // console.log($scope.startOn1);
        var date = new Date($scope.startOn);
        var date2Day = date.setHours(0, 0, 0,0);
        var date1 = new Date($scope.startOn1);
        var date2Day1 = date1.setHours(0, 0, 0,0);
        var dateObj = {date2Day : date2Day,date2Day1 : date2Day1};

        $http({
            method:'POST',
            url : '/users/getReportsRetargets',
            data:dateObj
        }).then(function successCallBack(res){

                var obj = res.data;
                var nlmIds = [];
                //console.log("obj reports");
               // console.log(JSON.stringify(obj));
                $scope.reportDetail = obj;
                obj.forEach(function(object)
                {
                    nlmIds.push(object._id.nlmId);

                });

                setTimeout(function() {
                    //console.log("nlmIds :   "+JSON.stringify(nlmIds));
                    var data1 = {nlmIds:nlmIds};
                    //console.log("nlmIds  11258 : "+nlmIds);
                    $http({
                        method:'POST',
                        url : '/users/getNlmNamesR',
                        data:data1
                    }).then(function successCallBack(res) {

                        var obj = res.data;

                        /* console.log("obj getNames");
                         console.log(JSON.stringify(obj));*/
                        if(obj=='')
                        {
                            $scope.reportDetail = [];
                        }

                        for(var i=0;i<$scope.reportDetail.length;i++)
                        {
                            var j;
                            for(j=0;j<obj.length;j++){

                                if (obj[j].id == $scope.reportDetail[i]._id.nlmId) {

                                   // $scope.getDomainName(obj[j].id,i);
                                    $scope.reportDetail[i].title = obj[j].title;
                                    $scope.reportDetail[i].SN = obj[j].SN;
                                    break;

                                }
                            }
                            if(j==obj.length)
                            {
                                $scope.reportDetail[i]='';
                            }
                        }


                        $scope.reportResult = $scope.reportDetail;

                        $scope.preload = false;
                       // console.log("$scope.reportDetail   :  ",$scope.reportDetail);
                    })

                },10)

            },
            function errorCallBack(res){
                console.log(res.data);
            })

    }
    /*    $scope.getNews();*/

    if(reportsData0.getDate()!='' && reportsData0.getDate1()!='')
    {
        $scope.startOn = $filter('date')(new Date(reportsData0.getDate()), 'yyyy-MM-dd');
        $scope.startOn1 = $filter('date')(new Date(reportsData0.getDate1()), 'yyyy-MM-dd');
        $scope.getNews();
    }
    else
    {
        $scope.getNews();
    }


}]);


sampleApp.controller('outerR-campaignsR-controller', ['campaignData0','$filter','$window','socket','$scope', '$cookies', '$cookieStore', '$http', function (campaignData0,$filter,$window,socket,$scope, $cookies, $cookieStore, $http)
{

    $scope.iconClick = function () {
        var element = document.getElementById("datePicker1");
        element.focus();
    }

    $scope.colors=["visibility-hdn border-yellow","visibility-hdn border-green","visibility-hdn border-orrange"];


    $scope.typeColor = {open:'fa rate-icon blue-1',click:'fa rate-icon green-1',lead:'fa rate-icon orrange-1',push:'fa rate-icon pink-1'};
    $scope.startOn = $filter('date')(new Date(), 'yyyy-MM-dd');
    //alert("outer campaign ");
    $scope.sortByVar = '-ctdOn';



    $scope.viewNlCampaign = function(camp)
    {
        campaignData0.setDate($scope.startOn);
        campaignData0.setCampId(camp.campId);
        window.location.href = "#users/innerCampaignR";
    }



    $scope.changeFilter = function(type)
    {
        $scope.sortByVar = type;
    }

    $scope.filterSort = [{type:'title',show:'Sort by NewsletterTitle'},
        {type:'createdBy',show:'Sort by CreatedBy'}];


    var loginId = $cookieStore.get("userid");
    $scope.loginId = loginId;
    $scope.preload = true;
    $scope.campaigns = [];
    $scope.pickedvolumes = [];
    $scope.selected = -1;
    $scope.viewing = null;
    $scope.subjects = [];
    $scope.senders = [];
    $scope.volume = 0;

    $scope.vol = 0;

    $scope.disableAdding = true;

    function calculateCamp(campaigns)
    {
        //alert("calculateCamp "+campaigns.length);
        var campIds = [];
        var tempCamp = [];
        var pushCamp = [];
        var temp='';
        for (var j=0;j<campaigns.length;j++)
        {
            var i = 0;
            pushCamp=[];
            var count=0;
            campIds.push(campaigns[j].campId);
            while(i<campaigns.length)
            {

                // alert("campaigns  :   "+JSON.stringify(campaigns))
                if(campaigns[j].campId==campaigns[i].campId && campaigns[j].ctdOn == campaigns[i].ctdOn)
                {
                    count++;

                    pushCamp.push(campaigns[j]);
                    if(count>1){
                        tempCamp[tempCamp.length-1].count=count;
                    }
                    else{
                        tempCamp.push({count:count,title:campaigns[j].title,ctdOn:campaigns[j].ctdOn,campId:campaigns[j].campId,
                            createdBy:campaigns[j].userRel.name,cBy:campaigns[j].cBy})
                    }

                }
                i++;
            }

        }

        $scope.resultCamp = tempCamp;
    }



    $scope.getNlmByDt = function (dt) {

        //alert("dt  : "+dt);
        var date = new Date(dt);
        var date2Day = date.setHours(0,0,0,0);
        var id = $cookieStore.get("userid");

        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {
            $scope.preload = true;
            $scope.campaigns=[];
            var obj={"where":{"ctdOn":date2Day/1000,"or":[{"status":-1},{"status":-2},{"status":1}],"cType":"retarget"}};
            $http({
                method: 'POST',
                url: 'users/getNlmByDt',
                data:{url:"api/nlm/query?filter="+JSON.stringify(obj)}
            }).then(function successCallback(response) {
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1)
                {
                    window.location.href = "./";
                } else
                {
                    $scope.campaigns = response.data;
                    $scope.aggCamp = [];
                    //console.log("$scope.campaigns  getNlmByDt : "+JSON.stringify($scope.campaigns));
                    $scope.preload = false;
                    //console.log('check');
                    calculateCamp($scope.campaigns);

                }
            }, function errorCallback(response) {
                //alert('error' + response);
                console.log(response);
            });


        }

    }



 /*   if(campaignData0.getDate()!='')
    {
        $scope.startOn = $filter('date')(new Date(campaignData0.getDate()), 'yyyy-MM-dd');
        $scope.getNlmByDt(campaignData0.getDate());
    }
    else
    {
        $scope.getNlmByDt($scope.startOn);
    }*/



    if(campaignData0.getDate()!='' && campaignData0.getBack() !='')
    {
        if(campaignData0.getBack()){
            $scope.startOn = $filter('date')(new Date(campaignData0.getDate()), 'yyyy-MM-dd');
            $scope.getNlmByDt(campaignData0.getDate());
            campaignData0.setBack(false);
        }
        else
        {
            $scope.getNlmByDt($scope.startOn);
        }
    }
    else
    {
        $scope.getNlmByDt($scope.startOn);
    }


    //$scope.getNlmByDt($scope.startOn);




    $scope.selecteddvol=0;
    $scope.selectedpvol=0;


    $scope.getUserDomain = function(){

        $http({
            method: 'POST',
            url: 'users/getUserDomain'
        }).then(function successCallback(response) {
            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            } else {

                var obj=response.data;
                $scope.userDomains=obj.data;
                //console.log("getUserDomain:   ",$scope.userDomains);
                if($scope.userDomains == '' || $scope.userDomains == null)
                {
                    alert("No Domains alloted to you please contact admin");
                    $("#myModal").modal('hide');
                }
                else {
                    $("#myModal").modal('show');
                }
            }

        }, function errorCallback(response) {
            console.log('error');
            console.log(response);
        });

    }


    $scope.addToMineShow = function (x, dvol, pvol) {

        //$("#myModal").modal('hide');

        $scope.remaining = dvol - pvol;
        //alert(pvol+" and remaining is  :  "+$scope.remaining);
        if($scope.remaining<=0){
            alert("No remaining vol to sent campaign");
            //$("#myModal").modal('hide');
        }else{

            console.log(dvol);
            console.log(pvol);
            $scope.selecteddvol=dvol;
            $scope.selectedpvol=pvol;
            console.log(dvol - pvol);
            $scope.selected = parseInt(x);

            if (!isNaN($scope.remaining) && $scope.remaining > 0) {
                $scope.disableAdding = false;
            } else {
                console.log('cannot enable add button');
            }
        }

        $scope.getUserDomain();
    };

    $scope.addToMineClose = function () {
        $scope.disableAdding = false;
        $scope.selected = -1;
        /* $scope.volume = 0;
         $scope.selecteddvol=0;
         $scope.selectedpvol=0;*/
    };

    $scope.addToMine = function (vol, campid) {

        var id = $cookieStore.get("userid");
        //alert("addToMine userid  "+id);
        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
            window.location.href = "./";
        } else {
            var obj = {
                "userId": parseInt(id),
                "nlmId": parseInt($scope.selected),
                'pickVol': parseInt($scope.volume)
            }
            //console.log(obj);
            $http({
                method: 'POST',
                url: 'users/allotToMe',
                data: obj
            }).then(function successCallback(response) {
                //console.log(response);
                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    $scope.volume = 0;
                    if (response.data.error) {
                        //console.log(response.data.error)
                        alert(response.data.error);
                    } else if (response.data.success) {
                        //console.log(response.data.success)
                        alert("Campaign added Successfully");
                        $scope.loadToday();
                    } else {

                    }
                }
            },function errorCallback(response) {
                window.location.href = "./";
                /*alert('error1' + response);*/
            });
        }
    };

    $scope.updateNewsLetter = function(camp)
    {
        var obj = {cBy:loginId,newsId:camp.id,dVol:camp.altPush};
        console.log("obj : "+obj);
        alert(JSON.stringify(obj));
        $http({

            method:'POST',
            url : '/users/updateNews',
            data:obj
        }).then(function successCallBack(res) {

                //alert("res   :  "+JSON.stringify(res));
                if(res.data.statusCode == 200){

                    alert("Campaign Started Successfully");
                    $window.location = "#/users/campaigns"
                }
                else {
                    alert("something went wrong");
                }

            },
            function errorCallBack(res){
                alert("error updateNEws");
                console.log(res.data);
            })
    }


}]);


sampleApp.controller('data_controller', ['$interval','$rootScope', '$filter', '$window', 'socket', '$scope', '$cookies', '$cookieStore', '$http','$routeParams', function ($interval,$rootScope, $filter, $window, socket, $scope, $cookies, $cookieStore, $http,$routeParams) {
    var loginId = $cookieStore.get("userid");
    var userName = $cookieStore.get("userName");

    // alert(userName);
    $scope.loginId = loginId;
    $scope.userName = userName;

    $interval(function () {
        $scope.pushNotification();
    }, 120000);



    $scope.iconClick = function () {
        var element = document.getElementById("datePicker1");
        element.focus();
    }
    $scope.iconClick2 = function () {
        var element = document.getElementById("datePicker2");
        element.focus();
    }

    $scope.dataDom='Mail';
    $scope.dataDom1='Country';
    $scope.dataDom2='Cities';
    $scope.dataESP='ESP';
    $scope.dataMail='Mail';
    $scope.dataLocation='Location';

    $scope.space='';

    $scope.cities=[[]];
    $scope.citiesName=[[]];

    $http({
        method: 'POST',
        url: 'users/countryData/',
        data:{"ldata":$scope.dataLocation}
    }).then(function successCallback(response) {

            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                window.location.href = "./";
            }  else {
                if (typeof response.data.success != 'undefined')
                {
                    var myString = response.data.success;
                    $scope.DATA= myString;
                    for(i in $scope.DATA){
                        $scope.cities[i]=[];
                    }
                    for(i in $scope.DATA){
                        $scope.citiesName[i]=[];
                    }


                }
                else if (typeof response.data.error != 'undefined') {
                    alert(response.data.error);
                }
            }

        },

        function errorCallback(response) {
            // alert('deletenewsleter' + JSON.stringify(response));
        });




    $http({                                                        //For tags and brands

        method: 'POST',
        url: '/users/gettags/'

    }).then(
        function successCallBack(res) {

            $scope.getTags = res.data;
            $scope.getTagsBrands = [];
            $scope.getTags.forEach(function (obj) {
                if(obj.type!=3){
                    $scope.getTagsBrands.push({"text": obj.name, "id": obj.id});
                }
            });

            // alert(JSON.stringify($scope.getTagsBrands));

            $scope.loadTagsBrands = function ($query) {

                // alert("hi");
                return $scope.getTagsBrands.filter(function (tags) {

                    return tags.text.toLowerCase().indexOf($query.toLowerCase()) != -1;
                    /* /!* console.log($scope.tagsBrands);
                     console.log($scope.tagsBrands[0].text)*!/
                     $scope.tagsBrands1=[];
                     // $scope.tagsBrands1=$scope.tagsBrands;


                     for(i in $scope.tagsBrands) {

                     $scope.tagsBrands1.push($scope.tagsBrands[i].text);

                     /!* if(typeof $scope.tagsBrands != 'undefined') {
                     $scope.tagsBrands1.push(tagsBrands[i].text);
                     }*!/

                     }
                     $scope.checking();
                     */
                });
            };


        },
        function errorCallBack(res) {

            //alert("error");
            console.log("error in tags");

            return res.data;
        });


    $scope.$watch('tagsBrands',function(){       //$watch tags and brands
        //  console.log("$scope.tagsBrands  : ",$scope.tagsBrands);
        if(typeof $scope.tagsBrands != "undefined" && $scope.tagsBrands!='')
        {
            $scope.tagsBrandsId=[];
            $scope.tagsBrandsName=[];
            $scope.tagsBrands.forEach(function(obj)
            {
                if(typeof obj.id!="undefined" && $scope.tagsBrandsId.indexOf(obj.id)==-1)
                {
                    $scope.tagsBrandsId.push(obj.id);
                    $scope.tagsBrandsName.push(obj.text);
                    $scope.checking();
                }
            })
        }
        else
        {
            $scope.tagsBrandsName=null;
            $scope.checking();
        }    },true)






    /* $scope.clickTags=function(){
     alert(JSON.stringify($scope.tagsBrands));
     }*/

    $scope.setEspData=function(espdata,id)
    {
        $scope.dataDom=espdata;
        $scope.dataESP=espdata;
        $scope.dataMail=espdata;
        //$scope.dataDom1="";
        $scope.dataDom2="";
        $scope.espid=id;
        $scope.checking();

        /* $("#myModal1").modal('hide');*/
    }


    $scope.locationClick=function(){
        $scope.display=false;

        if($scope.espid==undefined || $scope.espid==null){
            alert("Please Select Esp");
            $scope.display=true;

        }
    }

    $scope.profilingClick=function(){
        $scope.display1=false;
        if(($scope.espid==undefined || $scope.espid==null)&&($scope.lid==undefined ||$scope.lid==null))
        {
            alert("Please Select Esp and Location");
            $scope.display1=true;
        }
        else if($scope.lid==undefined ||$scope.lid==null)
        {
            alert("Please Select Location");
            $scope.display1=true;

        }
    }



    $scope.setLocationData=function(locationdata,locationid,indexno)
    {
        $scope.countryIndex=indexno;
        $scope.dataDom1=locationdata;
        $scope.countryName=locationdata;
        $scope.space=",";


        $scope.searching="";

        $scope.dataLocation=locationdata;
        $scope.lid=locationid;
        $scope.dataDom2="";
        $scope.startCity="";

        $scope.checking();


        var lid=  $scope.lid;
        var obj = {"countryId": lid};
        $http({
            url: "users/getCities",
            method: "POST",
            data: obj
        }).then(function success(res) {

            // console.log("res  :", res.data.data);
            var citydata=res.data.data;

            var k=0;
            var ctData=[];
            for(i in citydata) {
                //alert(citydata[i].name);
                if (citydata[i].name!=null) {
                    ctData[k]=citydata[i];
                    k=k+1;
                }
            }


            $scope.resCityData = ctData;

        }, function error(res) {
            console.log("error   :", res.data.data);
        })
        $scope.cityData=$scope.cities[$scope.countryIndex];
        $scope.cityData1=$scope.citiesName[$scope.countryIndex];



    }


    $scope.setCityData=function(citydata,cityid)
    {
        $scope.cityLocation=$scope.dataLocation;
        $scope.dataDom2=citydata;
        $scope.cityId=cityid;

        if($scope.cities[$scope.countryIndex].indexOf(cityid)==-1 ){
            $scope.cities[$scope.countryIndex].push( $scope.cityId);
            $scope.citiesName[$scope.countryIndex].push( $scope.dataDom2);

        }

        $scope.closeCity=function(city)
        {
            var index=$scope.cities[$scope.countryIndex].indexOf(city);
            $scope.cities[$scope.countryIndex].splice(index,1);
            var index1=$scope.citiesName[$scope.countryIndex].indexOf(city);
            $scope.citiesName[$scope.countryIndex].splice(index1,1);
            //alert(JSON.stringify($scope.citiesName[$scope.countryIndex]));

        }
        $scope.checking();
    }


    var d = new Date();
    $scope.currentYear = d.getFullYear();

    $scope.checking=function() {
        //target JSON object

        if (typeof $scope.espid != 'undefined' || typeof $scope.lid != 'undefined' ||
            typeof $scope.countryName != 'undefined' || typeof $scope.cities[$scope.countryIndex] != 'undefined' ||
            typeof $scope.citiesName[$scope.countryIndex] != 'undefined' || typeof $scope.tagsBrandsId != 'undefined' ||
            typeof $scope.tagsBrandsName != 'undefined' || typeof $scope.selectedFromage != 'undefined' ||
            typeof $scope.selectedToage != 'undefined' ||typeof $scope.selectedGenderName!='undefined')


            if($scope.espid!=null || $scope.lid!=null ||  $scope.tagsBrandsName!=null ||
                $scope.selectedFromage!=null|| $scope.selectedToage !=null ||
                $scope.selectedGenderName!=null) {


                /*if(typeof $scope.selectedFromage == 'undefined')
                 {

                 $scope.age2=0;
                 }
                 */
                /*{
                 var query= {
                 "esp": $scope.espid,
                 "countryId": $scope.lid,
                 "countryName": $scope.countryName,
                 "cityId": $scope.cities[$scope.countryIndex],
                 "cityName": $scope.citiesName[$scope.countryIndex],
                 "tagId":$scope.tagsBrandsId,
                 "tagName":$scope.tagsBrandsName
                 }

                 {
                 "esp": $scope.espid,
                 "countryId": $scope.lid,
                 "countryName": $scope.countryName,
                 "cityId": $scope.cities[$scope.countryIndex],
                 "cityName": $scope.citiesName[$scope.countryIndex],
                 "tagId": $scope.tagsBrandsId,
                 "tagName": $scope.tagsBrandsName,
                 "genderId": $scope.selectedGender,
                 "genderName": $scope.selectedGenderName,
                 "age1": $scope.age1,
                 "age2": $scope.age2,
                 "ageFrom": $scope.selectedFromage,
                 "ageTo": $scope.selectedToage
                 }

                 }*/

                {
                    var target = {
                        "userId": $scope.loginId,
                        "query": {
                            "gender": $scope.selectedGender,
                            "eDomain": $scope.espid,
                            "city": $scope.cities[$scope.countryIndex],
                            "country":  $scope.lid,
                            "catTags": $scope.tagsBrandsId,
                            "age": {"from": $scope.currentYear-$scope.age1, "to": $scope.currentYear-$scope.age2},
                            //optional
                            "ctNames": $scope.citiesName[$scope.countryIndex],
                            "cyNames": $scope.countryName,
                            "tagNames":$scope.tagsBrandsName,
                            "genderName": $scope.selectedGenderName
                        }
                    }
                }
                // alert(JSON.stringify(target));
                $scope.target = target;                                              //sending data
                //var target = {"target": $scope.target};
                //alert(JSON.stringify(target));
            }
    }
    $scope.ageForm={
        selected1:null,
        selected2:null


    };
    $scope.requestHere=function() {
        if($scope.espid ==null && $scope.lid==null)
        {
            alert("Please Select ESP and Location");
            $scope.target=null;
        }
        else if($scope.lid==null)
        {
            alert("Please Select Location");
            $scope.target=null;
        }
        /*   alert("hi");*/
        $scope.startOn = $filter('date')(new Date(), 'yyyy-MM-dd');
        $scope.startOn2 = $filter('date')(new Date(), 'yyyy-MM-dd');

        /*   alert($scope.startOn);*/

        var target = {"target": $scope.target};
        /*  alert(JSON.stringify(target));*/
        //console.log("targets :  "+JSON.stringify(target));

        $http({
            method: 'POST',
            url: 'users/createTarget/',
            data: target
        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (typeof response.data.success != 'undefined') {
                        var myString = response.data.success;

                        $scope.dataESP="ESP";
                        $scope.espid=null;
                        $scope.dataDom='Mail';
                        $scope.dataLocation="Location";
                        $scope.dataDom1='Country';
                        $scope.lid=null;
                        $scope.countryName=null;
                        $scope.resCityData="";
                        $scope.citiesName[$scope.countryIndex]=null;
                        $scope.tagsBrands="";
                        $scope.tagsBrandsName=null;

                        document.getElementById("genderForm").reset();
                        document.getElementById("ageForm").reset();

                        $scope.ageForm.selected1=null;
                        $scope.ageForm.selected2=null;



                        /* document.getElementById("ageForm1").reset();
                         document.getElementById("ageForm2").reset();*/
                        $scope.selectedGender=0;
                        $scope.gender=null;
                        $scope.age=null;
                        $scope.selectedGenderName=null;
                        //alert($scope.selectedGenderName);
                        $scope.selectedFromage=null;
                        $scope.selectedToage=null;
                        $scope.age1=null;
                        $scope.age2=null;

                        //alert($scope.selectedToage);
                        $scope.cities=[[]];
                        for(i in $scope.DATA) {
                            $scope.cities[i] = [];
                        }

                        for(i in $scope.DATA){
                            $scope.citiesName[i]=[];
                        }
                        $scope.target=null;
                        $scope.arrayNumbers1=[];

                        //alert($scope.target);



                        //alert("hi"+JSON.stringify(target));
                        // alert("123"+JSON.stringify(target.target.query.ageFrom));
                        /* if(target.target.query.ageFrom!=null &&target.target.query.ageTo!=null)

                         {
                         $scope.target=target;

                         $scope.targetageFrom=target.target.query.ageFrom;
                         $scope.targetageTo=target.target.query.ageTo;
                         alert("based in age");
                         //alert("I have to do it");
                         $scope.ageAlldata();
                         $scope.ageFrom();



                         }
                         else {
                         alert("not based on age");*/
                        $scope.allDatatoday();
                        $scope.myRequesttoday();


                        /* $scope.dataESP=ESP;
                         $scope.dataLocation=Location;*/
                    }
                    else if (typeof response.data.error != 'undefined') {
                        //  alert(response.data.error);
                    }
                }

            },

            function errorCallback(response) {
                // alert('deletenewsleter' + JSON.stringify(response));
            });
    }


    $scope.finishEsp=function(){
        $("#myModal1").modal('hide');
    }
    $scope.searchForm={
        searchCities:""


    };
    $scope.finishCountry=function(){

        document.getElementById("searchForm").reset();
        $scope.searchForm.searchCities="";

        $("#myModal2").modal('hide');

        $scope.cities=[[]];
        for(i in $scope.DATA) {
            $scope.cities[i] = [];
        }
        for(i in $scope.DATA){
            $scope.citiesName[i]=[];
        }
        $scope.cities[$scope.countryIndex]=$scope.cityData;
        $scope.citiesName[$scope.countryIndex]=$scope.cityData1;

        $scope.searching="";


    }


    $scope.finishProfiling=function(){
        if($scope.age1!=null && (typeof $scope.age2== 'undefined' || $scope.age2==null))
        {
            alert("Please select 'To' age");
        }
        else {
            $("#myModal3").modal('hide');
        }

    }

    $scope.selectGender=function(gender)        //gender
    {
        $scope.gender=gender;
        $scope.age=0;

        //alert($scope.gender);
    }

    $scope.selectAge=function(age)        //age
    {
        $scope.age=age;
        $scope.gender=0;
        //alert($scope.age);
    }

    $scope.selectedMale=function (id,name) {
        $scope.id=id;
        $scope.selectedGender=id;
        $scope.selectedGenderName=name;
        $scope.checking();
    }

    $scope.selectedFemale=function (id,name) {
        $scope.selectedGender=id;
        $scope.selectedGenderName=name;
        $scope.checking();
    }
    $scope.selectedAll=function (id,name) {
        $scope.selectedGender=id;
        $scope.selectedGenderName=null;
        $scope.checking();
    }




    $scope.arrayNumbers=[];
    for(i=0;i<=100;i++)
    {
        $scope.arrayNumbers[i]=i;
    }
    /*$scope.arrayNumbers1=[];
     for(i=$scope.age1;i<=100;i++)
     {
     $scope.arrayNumbers1[i]=i;
     }*/


    $scope.selectedFrom=function(age1)
    {
        $scope.age1=age1;
        $scope.selectedToage=$scope.yearOnly-age1+1;
        selectedDate = $scope.selectedToage;

        // alert(selectedDate);
        var date = new Date(selectedDate + "");
        var selectedToage = date.setHours(0, 0, 0, 0) / 1000;
        $scope.selectedToage = selectedToage;
        $scope.arrayNumbers1 = [];
        //alert($scope.age1)
        k = 0;
        for (i = $scope.age1; i <= 100; i++) {
            $scope.arrayNumbers1[k] = i;
            k++;
        }
        $scope.checking();

    }


    $scope.checkFromAge=function(selected1){
        $scope.selected1=selected1;
        //alert($scope.selected1);
        if($scope.selected1==undefined || $scope.selected1==null){
            alert("select 'from' age");
        }
    }

    $scope.selectedTo=function(age2)
    {
        $scope.age2=age2;
        $scope.selectedFromage=$scope.yearOnly-age2;
        selectedDate=$scope.selectedFromage;
        if($scope.selectedFromage!=null){
            var date = new Date(selectedDate+"");
            var selectedFromage = date.setHours(0,0,0,0)/1000;
            $scope.selectedFromage=selectedFromage;
            //alert($scope.selectedFromage);
            $scope.checking();
        }
    }




    $scope.startOn = $filter('date')(new Date(), 'yyyy-MM-dd');
    $scope.startOn2 = $filter('date')(new Date(), 'yyyy-MM-dd');

    /*$scope.yearOnly=$filter('yyyy')(new Date(), 'yyyy-MM-dd');
     alert($scope.yearOnly);
     */


    $scope.yearOnly=(new Date().getFullYear());
    //alert($scope.yearOnly);

    //$scope.selectedDate=$scope.startOn;
    //alert($scope.selectedDate);

    var date = new Date($scope.startOn);
    var todayDate = date.setHours(0, 0, 0,0)/1000;
    $scope.todayDate=todayDate;
    //alert($scope.todayDate);
    $scope.allDatatoday=function() {
        $scope.preload=true;
        $scope.allData="";
        $http({                                             //displaying all data (today)
            method: 'POST',
            url: 'users/allDataToday/',
        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {


                    if (typeof response.data.success != 'undefined') {
                        var myString = response.data.success;
                        for (i in myString) {
                            if (myString[i].ctdOn != null) {
                                myString[i].ctdOn = ($filter('date')(myString[i].ctdOn * 1000, 'yyyy-MM-dd'));
                            }
                        }

                        for (i in myString) {
                            if (myString[i].ctdAt != null) {
                                myString[i].ctdAt = ($filter('date')(myString[i].ctdAt * 1000,'yyyy-MM-dd HH:mm:ss'));
                                //console.log("created date and time is"+myString[i].ctdAt);
                            }
                        }

                        for (i in myString) {
                            if(typeof myString[i].query!='undefined'){
                                if (typeof (myString[i].query.age) != 'undefined') {
                                    if(myString[i].query.age.from!=null) {
                                        myString[i].query.age.from = ($scope.yearOnly-myString[i].query.age.from);
                                        myString[i].query.age.to = ($scope.yearOnly-myString[i].query.age.to);
                                    }
                                }
                            }
                        }

                        $scope.myString = myString;
                        var myString = {"myString": $scope.myString};
                        //alert(JSON.stringify(myString));
                        $http({
                            method: 'POST',
                            url: 'users/getUserName/',
                            data: myString

                        }).then(function successCallback(response) {

                                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                                    window.location.href = "./";
                                } else {
                                    if (typeof response.data.success != 'undefined') {
                                        var datarr = response.data.success;
                                        $scope.preload=false;

                                        $scope.datarr = datarr;
                                        // alert($scope.datarr);
                                        for (i in $scope.myString) {
                                            $scope.myString[i].userId = datarr[i];
                                        }

                                        for(i = 0; i < $scope.myString.length / 2; i++)                //reversing the array of objects
                                        {
                                            temp = $scope.myString[i];
                                            $scope.myString[i] = $scope.myString[$scope.myString.length - i - 1];
                                            $scope.myString[$scope.myString.length - i - 1] = temp;


                                        }

                                        $scope.allData = $scope.myString;



                                    }
                                    else if (typeof response.data.error != 'undefined') {
                                        alert(response.data.error);
                                    }
                                }

                            },

                            function errorCallback(response) {
                                // alert('deletenewsleter' + JSON.stringify(response));
                            });

                        //ends here


                        //alert(JSON.stringify($scope.allData));

                    }
                    else if (typeof response.data.error != 'undefined') {
                        alert(response.data.error);
                    }
                }

            },

            function errorCallback(response) {
                //alert('deletenewsleter' + JSON.stringify(response));
            });

    }
    $scope.allDatatoday();


    $scope.myRequesttoday=function() {
        $scope.loading=true;
        $scope.myRequest="";

        $http({                                             //displaying myrequest (today)
            method: 'POST',
            url: 'users/myRequestToday/',
        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (typeof response.data.success != 'undefined') {

                        var myString = response.data.success;
                        $scope.loading=false;
                        for (i in myString) {
                            if (myString[i].ctdOn != null) {
                                myString[i].ctdOn = ($filter('date')(myString[i].ctdOn * 1000, 'yyyy-MM-dd'));
                            }
                        }
                        for (i in myString) {
                            if (myString[i].ctdAt != null) {
                                myString[i].ctdAt = ($filter('date')(myString[i].ctdAt * 1000,'yyyy-MM-dd HH:mm:ss'));
                            }
                        }

                        for (i in myString) {
                            if(typeof myString[i].query!='undefined'){
                                if (typeof (myString[i].query.age) != 'undefined') {
                                    if(myString[i].query.age.from!=null) {
                                        myString[i].query.age.from = ($scope.yearOnly-myString[i].query.age.from);
                                        myString[i].query.age.to = ($scope.yearOnly-myString[i].query.age.to);
                                    }
                                }
                            }
                        }
                        for(i = 0; i < myString.length / 2; i++)                //reversing the array of objects
                        {
                            temp = myString[i];
                            myString[i] = myString[myString.length - i - 1];
                            myString[myString.length - i - 1] = temp;
                        }


                        //alert(JSON.stringify(myString));

                        $scope.myRequest = myString;
                        //alert(JSON.stringify($scope.myRequest));

                    }
                    else if (typeof response.data.error != 'undefined') {
                        alert(response.data.error);
                    }
                }

            },

            function errorCallback(response) {
                //alert('deletenewsleter' + JSON.stringify(response));
            });
    }
    $scope.myRequesttoday();











    $scope.startToday=function(startOn) {
        $scope.startOn2=startOn;
        $scope.selectedDate = startOn;
        $scope.preload=true;
        $scope.loading=true;

        //alert($scope.selectedDate);
        var date = new Date($scope.selectedDate);
        var selectedDate = date.setHours(0, 0, 0, 0)/1000;
        /* $scope.convertedDate=$filter('date')(1482863400*1000,'yyyy-MM-dd')
         alert($scope.convertedDate);
         */         $scope.allData="";
        var temp=$filter('date')(new Date(), 'yyyy-MM-dd');

        var temp1 = new Date(temp);
        var temp2 = temp1.setHours(0, 0, 0, 0)/1000;
        if(selectedDate>temp2)
        {
            alert("No reguests won't be there after "+temp);
            $scope.startOn=temp;
            $scope.startOn2=temp;
            $scope.selectedDate=temp;
            var date = new Date($scope.selectedDate);
            var selectedDate = date.setHours(0, 0, 0, 0)/1000;
        }





        $scope.selectedDate1= selectedDate;
        //alert($scope.selectedDate);

        //var selectedDate = $scope.selectedDate;
        var obj = {"todayDate":$scope.selectedDate1,"selectedDate":$scope.selectedDate1};
        // alert(JSON.stringify(obj));
        $http({                                                //displaying all data based on time
            method: 'POST',
            url: 'users/allDataOntime/',
            data: obj

        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (typeof response.data.success != 'undefined') {
                        var myString = response.data.success;
                        if(myString=="") {
                            alert("No request on "+$scope.selectedDate);
                        }

                        for (i in myString) {
                            if(myString[i].ctdOn!=null) {
                                myString[i].ctdOn=($filter('date')(myString[i].ctdOn * 1000, 'yyyy-MM-dd'));
                            }
                        }
                        for (i in myString) {
                            if (myString[i].ctdAt != null) {
                                myString[i].ctdAt = ($filter('date')(myString[i].ctdAt * 1000,'yyyy-MM-dd HH:mm:ss'));
                            }
                        }
                        for (i in myString) {
                            if(typeof myString[i].query!='undefined'){
                                if (typeof (myString[i].query.age) != 'undefined') {
                                    if(myString[i].query.age.from!=null) {
                                        myString[i].query.age.from = ($scope.yearOnly-myString[i].query.age.from);
                                        myString[i].query.age.to = ($scope.yearOnly-myString[i].query.age.to);
                                    }
                                }
                            }
                        }

                        $scope.myString=myString;
                        //start here

                        var myString = {"myString":$scope.myString};
                        //alert(JSON.stringify(myString));

                        $http({
                            method: 'POST',
                            url: 'users/getUserName/',
                            data: myString

                        }).then(function successCallback(response) {

                                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                                    window.location.href = "./";
                                } else {
                                    if (typeof response.data.success != 'undefined') {
                                        var datarr = response.data.success;
                                        $scope.preload=false;


                                        $scope.datarr=datarr;
                                        //alert($scope.datarr);
                                        for(i in $scope.myString) {
                                            $scope.myString[i].userId=datarr[i];
                                        }
                                        /*for(i = 0; i < $scope.myString.length / 2; i++)                //reversing the array of objects
                                         {
                                         temp = $scope.myString[i];
                                         $scope.myString[i] = $scope.myString[$scope.myString.length - i - 1];
                                         $scope.myString[$scope.myString.length - i - 1] = temp;
                                         }*/


                                        $scope.allData = $scope.myString;

                                    }
                                    else if (typeof response.data.error != 'undefined') {
                                        alert(response.data.error);
                                    }
                                }

                            },

                            function errorCallback(response) {
                                // alert('deletenewsleter' + JSON.stringify(response));
                            });
                        // alert(JSON.stringify(myString[0].ctdOn));


                        //alert(JSON.stringify(myString[0].ctdOn));

                        // console.log("all data will be dispaly based on selected date");

                        //alert(JSON.stringify($scope.allData));

                    }
                    else if (typeof response.data.error != 'undefined') {
                        alert(response.data.error);
                    }
                }

            },

            function errorCallback(response) {
                // alert('deletenewsleter' + JSON.stringify(response));
            });
        $scope.myRequest="";

        $http({                                           // displaying requested data based on time
            method: 'POST',
            url: 'users/myRequestOntime/',
            data: obj

        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (typeof response.data.success != 'undefined') {
                        var myString = response.data.success;
                        $scope.loading=false;


                        /*
                         alert(JSON.stringify(myString[0].ctdOn));
                         */

                        for (i in myString) {
                            if(myString[i].ctdOn!=null) {
                                myString[i].ctdOn=($filter('date')(myString[i].ctdOn * 1000, 'yyyy-MM-dd'));
                            }
                        }
                        for (i in myString) {
                            if (myString[i].ctdAt != null) {
                                myString[i].ctdAt = ($filter('date')(myString[i].ctdAt * 1000,'yyyy-MM-dd HH:mm:ss'));
                            }
                        }
                        for (i in myString) {
                            if(typeof myString[i].query!='undefined'){
                                if (typeof (myString[i].query.age) != 'undefined') {
                                    if(myString[i].query.age.from!=null) {
                                        myString[i].query.age.from = ($scope.yearOnly-myString[i].query.age.from);
                                        myString[i].query.age.to = ($scope.yearOnly-myString[i].query.age.to);
                                    }
                                }
                            }
                        }

                        /*for(i = 0; i < myString.length / 2; i++)                //reversing the array of objects
                         {
                         temp = myString[i];
                         myString[i] = myString[myString.length - i - 1];
                         myString[myString.length - i - 1] = temp;
                         }*/


                        $scope.myRequest = myString;
                        // alert(JSON.stringify(myString[0].ctdOn));


                        //alert(JSON.stringify(myString[0].ctdOn));

                        //console.log("requested data will be dispaly based on selected date");

                        //alert(JSON.stringify($scope.allData));

                    }
                    else if (typeof response.data.error != 'undefined') {
                        alert(response.data.error);
                    }
                }

            },

            function errorCallback(response) {
                alert('deletenewsleter' + JSON.stringify(response));
            });
    }





    $scope.startToday2= function(startOn2) {
        $scope.startOn2 = startOn2;
        $scope.allData = "";
        $scope.preload = true;
        $scope.loading = true;

        var date1 = new Date($scope.startOn);
        var selectedDate1 = date1.setHours(0, 0, 0, 0) / 1000;
        $scope.selectedDate1 = selectedDate1;

        var date2 = new Date($scope.startOn2);
        var selectedDate2 = date2.setHours(0, 0, 0, 0) / 1000;
        $scope.selectedDate2 = selectedDate2;

        if ($scope.selectedDate1 > $scope.selectedDate2) {
            $scope.startOn2 = $scope.startOn;
            var date2 = new Date($scope.startOn2);
            var selectedDate2 = date2.setHours(0, 0, 0, 0) / 1000;
            $scope.selectedDate2 = selectedDate2;

        }
        var obj = {"selectedDate": $scope.selectedDate1, "todayDate": $scope.selectedDate2};


        $http({                                                //displaying all data based on time
            method: 'POST',
            url: 'users/allDataOntime/',
            data: obj

        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (typeof response.data.success != 'undefined') {
                        var myString = response.data.success;
                        if (myString == "") {
                            alert("No request between " + $scope.startOn + and + $scope.startOn2);
                        }

                        for (i in myString) {
                            if (myString[i].ctdOn != null) {
                                myString[i].ctdOn = ($filter('date')(myString[i].ctdOn * 1000, 'yyyy-MM-dd'));
                            }
                        }
                        for (i in myString) {
                            if (myString[i].ctdAt != null) {
                                myString[i].ctdAt = ($filter('date')(myString[i].ctdAt * 1000, 'yyyy-MM-dd HH:mm:ss'));
                            }
                        }
                        for (i in myString) {
                            if (typeof myString[i].query != 'undefined') {
                                if (typeof (myString[i].query.age) != 'undefined') {
                                    if (myString[i].query.age.from != null) {
                                        myString[i].query.age.from = ($scope.yearOnly - myString[i].query.age.from);
                                        myString[i].query.age.to = ($scope.yearOnly - myString[i].query.age.to);
                                    }
                                }
                            }
                        }

                        $scope.myString = myString;
                        //start here

                        var myString = {"myString": $scope.myString};
                        //alert(JSON.stringify(myString));

                        $http({
                            method: 'POST',
                            url: 'users/getUserName/',
                            data: myString

                        }).then(function successCallback(response) {

                                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                                    window.location.href = "./";
                                } else {
                                    if (typeof response.data.success != 'undefined') {
                                        var datarr = response.data.success;
                                        $scope.preload = false;


                                        $scope.datarr = datarr;
                                        //alert($scope.datarr);
                                        for (i in $scope.myString) {
                                            $scope.myString[i].userId = datarr[i];
                                        }
                                        /*for(i = 0; i < $scope.myString.length / 2; i++)                //reversing the array of objects
                                         {
                                         temp = $scope.myString[i];
                                         $scope.myString[i] = $scope.myString[$scope.myString.length - i - 1];
                                         $scope.myString[$scope.myString.length - i - 1] = temp;
                                         }*/


                                        $scope.allData = $scope.myString;

                                    }
                                    else if (typeof response.data.error != 'undefined') {
                                        alert(response.data.error);
                                    }
                                }

                            },

                            function errorCallback(response) {
                                // alert('deletenewsleter' + JSON.stringify(response));
                            });
                        // alert(JSON.stringify(myString[0].ctdOn));


                        //alert(JSON.stringify(myString[0].ctdOn));

                        console.log("all data will be dispaly based on selected date");

                        //alert(JSON.stringify($scope.allData));

                    }
                    else if (typeof response.data.error != 'undefined') {
                        alert(response.data.error);
                    }
                }

            },

            function errorCallback(response) {
                // alert('deletenewsleter' + JSON.stringify(response));
            });
        $scope.myRequest = "";

        $http({                                           // displaying requested data based on time
            method: 'POST',
            url: 'users/myRequestOntime/',
            data: obj

        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (typeof response.data.success != 'undefined') {
                        var myString = response.data.success;
                        $scope.loading = false;


                        /*
                         alert(JSON.stringify(myString[0].ctdOn));
                         */

                        for (i in myString) {
                            if (myString[i].ctdOn != null) {
                                myString[i].ctdOn = ($filter('date')(myString[i].ctdOn * 1000, 'yyyy-MM-dd'));
                            }
                        }
                        for (i in myString) {
                            if (myString[i].ctdAt != null) {
                                myString[i].ctdAt = ($filter('date')(myString[i].ctdAt * 1000, 'yyyy-MM-dd HH:mm:ss'));
                            }
                        }
                        for (i in myString) {
                            if (typeof myString[i].query != 'undefined') {
                                if (typeof (myString[i].query.age) != 'undefined') {
                                    if (myString[i].query.age.from != null) {
                                        myString[i].query.age.from = ($scope.yearOnly - myString[i].query.age.from);
                                        myString[i].query.age.to = ($scope.yearOnly - myString[i].query.age.to);
                                    }
                                }
                            }
                        }

                        /*for(i = 0; i < myString.length / 2; i++)                //reversing the array of objects
                         {
                         temp = myString[i];
                         myString[i] = myString[myString.length - i - 1];
                         myString[myString.length - i - 1] = temp;
                         }*/


                        $scope.myRequest = myString;
                        // alert(JSON.stringify(myString[0].ctdOn));


                        //alert(JSON.stringify(myString[0].ctdOn));

                        console.log("requested data will be dispaly based on selected date");

                        //alert(JSON.stringify($scope.allData));

                    }
                    else if (typeof response.data.error != 'undefined') {
                        alert(response.data.error);
                    }
                }

            },

            function errorCallback(response) {
                alert('deletenewsleter' + JSON.stringify(response));
            });


/////
        $http({                                                //displaying all data based on time
            method: 'POST',
            url: 'users/allDataOntime/',
            data: obj

        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (typeof response.data.success != 'undefined') {
                        var myString = response.data.success;
                        /*
                         alert(JSON.stringify(myString[0].ctdOn));
                         */

                        for (i in myString) {
                            if (myString[i].ctdOn != null) {
                                myString[i].ctdOn = ($filter('date')(myString[i].ctdOn * 1000, 'yyyy-MM-dd'));
                            }
                        }
                        for (i in myString) {
                            if (myString[i].ctdAt != null) {
                                myString[i].ctdAt = ($filter('date')(myString[i].ctdAt * 1000, 'yyyy-MM-dd HH:mm:ss'));
                            }
                        }
                        for (i in myString) {
                            if (typeof myString[i].query != 'undefined') {
                                if (typeof (myString[i].query.age) != 'undefined') {
                                    if (myString[i].query.age.from != null) {
                                        myString[i].query.age.from = ($scope.yearOnly - myString[i].query.age.from);
                                        myString[i].query.age.to = ($scope.yearOnly - myString[i].query.age.to);
                                    }
                                }
                            }
                        }

                        $scope.myString = myString;
                        //start here

                        var myString = {"myString": $scope.myString};
                        //alert(JSON.stringify(myString));

                        $http({
                            method: 'POST',
                            url: 'users/getUserName/',
                            data: myString

                        }).then(function successCallback(response) {

                                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                                    window.location.href = "./";
                                } else {
                                    if (typeof response.data.success != 'undefined') {
                                        var datarr = response.data.success;
                                        $scope.preload = false;


                                        $scope.datarr = datarr;
                                        //alert($scope.datarr);
                                        for (i in $scope.myString) {
                                            $scope.myString[i].userId = datarr[i];
                                        }
                                        /*for(i = 0; i < $scope.myString.length / 2; i++)                //reversing the array of objects
                                         {
                                         temp = $scope.myString[i];
                                         $scope.myString[i] = $scope.myString[$scope.myString.length - i - 1];
                                         $scope.myString[$scope.myString.length - i - 1] = temp;
                                         }*/


                                        $scope.allData = $scope.myString;

                                    }
                                    else if (typeof response.data.error != 'undefined') {
                                        alert(response.data.error);
                                    }
                                }

                            },

                            function errorCallback(response) {
                                // alert('deletenewsleter' + JSON.stringify(response));
                            });
                        // alert(JSON.stringify(myString[0].ctdOn));


                        //alert(JSON.stringify(myString[0].ctdOn));

                        console.log("all data will be dispaly based on selected date");

                        //alert(JSON.stringify($scope.allData));

                    }
                    else if (typeof response.data.error != 'undefined') {
                        alert(response.data.error);
                    }
                }

            },

            function errorCallback(response) {
                // alert('deletenewsleter' + JSON.stringify(response));
            });
        $scope.myRequest = "";

        $http({                                           // displaying requested data based on time
            method: 'POST',
            url: 'users/myRequestOntime/',
            data: obj

        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (typeof response.data.success != 'undefined') {
                        var myString = response.data.success;
                        $scope.loading = false;


                        /*
                         alert(JSON.stringify(myString[0].ctdOn));
                         */

                        for (i in myString) {
                            if (myString[i].ctdOn != null) {
                                myString[i].ctdOn = ($filter('date')(myString[i].ctdOn * 1000, 'yyyy-MM-dd'));
                            }
                        }
                        for (i in myString) {
                            if (myString[i].ctdAt != null) {
                                myString[i].ctdAt = ($filter('date')(myString[i].ctdAt * 1000, 'yyyy-MM-dd HH:mm:ss'));
                            }
                        }
                        for (i in myString) {
                            if (typeof myString[i].query != 'undefined') {
                                if (typeof (myString[i].query.age) != 'undefined') {
                                    if (myString[i].query.age.from != null) {
                                        myString[i].query.age.from = ($scope.yearOnly - myString[i].query.age.from);
                                        myString[i].query.age.to = ($scope.yearOnly - myString[i].query.age.to);
                                    }
                                }
                            }
                        }

                        /*for(i = 0; i < myString.length / 2; i++)                //reversing the array of objects
                         {
                         temp = myString[i];
                         myString[i] = myString[myString.length - i - 1];
                         myString[myString.length - i - 1] = temp;
                         }*/


                        $scope.myRequest = myString;
                        // alert(JSON.stringify(myString[0].ctdOn));


                        //alert(JSON.stringify(myString[0].ctdOn));

                        console.log("requested data will be dispaly based on selected date");

                        //alert(JSON.stringify($scope.allData));

                    }
                    else if (typeof response.data.error != 'undefined') {
                        alert(response.data.error);
                    }
                }

            },

            function errorCallback(response) {
                alert('deletenewsleter' + JSON.stringify(response));
            });

    }
    $scope.notifyId=[];
    $scope.pushNotification=function(){

        $http({
            method: 'POST',
            url: 'users/myRequestToday/',
        }).then(function successCallback(response) {

                if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                    window.location.href = "./";
                } else {
                    if (typeof response.data.success != 'undefined') {
                        var myString = response.data.success;
                        for(var i=0;i<myString.length;i++){

                            if(myString[i].status==2 && myString[i].notified==false){

                                $scope.allData="";
                                $scope.myRequest="";

                                $scope.allDatatoday();
                                $scope.myRequesttoday();


                                if(myString[i].query.eDomain==1)
                                {
                                    myString[i].query.eDomain="Gmail";
                                }
                                else if(myString[i].query.eDomain==2)
                                {
                                    myString[i].query.eDomain="Yahoo Mail";
                                }
                                else if(myString[i].query.eDomain==3)
                                {
                                    myString[i].query.eDomain="Hot Mail";
                                }
                                else if(myString[i].query.eDomain==4)
                                {
                                    myString[i].query.eDomain="Others";
                                }
                                var msg="For the Request ESP: " + myString[i].query.eDomain + " & Country: "+myString[i].query.cyNames+" ,Count is "+myString[i].count;
                                var date1 = new Date().toISOString().substr(0, 10);
                                var date = new Date(date1+" 00:00:00")
                                var now = date.getTime() / 1000;
                                var obj = {
                                    "msg": msg,
                                    "desc": msg,
                                    "src":msg,
                                    "type": "alert",
                                    "userIds":[myString[i].userId],
                                    "port": 2008,
                                    "ctdOn": now
                                }
                                var obj = {"obj": obj};
                                $scope.notifyId.push(myString[i].id);

                                $http({
                                    method: 'POST',
                                    url: 'users/putNotification/',
                                    data: obj
                                }).then(function successCallback(response) {

                                        if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                                            window.location.href = "./";
                                        } else {
                                            if (typeof response.data.success != 'undefined') {
                                                var resp = response.data.success;
                                                if(i==myString.length)
                                                {
                                                    var updateNotify={
                                                        "ids":$scope.notifyId,
                                                        "notified":true
                                                    }
                                                    $scope.updateNotify=updateNotify;
                                                    var obj={"obj":$scope.updateNotify};
                                                    $http({
                                                        method: 'POST',
                                                        url: 'users/notifyUpdate/',
                                                        data: obj
                                                    }).then(function successCallback(response) {

                                                            if (response.data === 'logout' || JSON.stringify(response.data).indexOf('logout') > -1) {
                                                                window.location.href = "./";
                                                            } else {
                                                                if (typeof response.data.success != 'undefined') {
                                                                    var myString = response.data.success;
                                                                    $scope.notifyId=[];

                                                                }
                                                                else if (typeof response.data.error != 'undefined') {
                                                                    //  alert(response.data.error);
                                                                }
                                                            }

                                                        },

                                                        function errorCallback(response) {
                                                            // alert('deletenewsleter' + JSON.stringify(response));
                                                        });


                                                }


                                            }
                                            else if (typeof response.data.error != 'undefined') {
                                                // alert(response.data.error);
                                            }
                                        }

                                    },

                                    function errorCallback(response) {
                                        // alert( JSON.stringify(response));
                                    });

                            }
                        }
                    }
                    else if (typeof response.data.error != 'undefined') {
                        //alert(response.data.error);
                    }
                }

            },

            function errorCallback(response) {
                alert( JSON.stringify(response));
            });
    }




}]);


