var express = require('express');
var router = express.Router();
var dateFormat = require('dateformat');
var aes = require('./aes.js');
var multer  = require('multer');
var fs = require("fs");
var request = require('request');
var unzip = require("unzip");
var cheerio = require("cheerio");

var conf=require("../db.json");
var apiurl=conf.apiurl;
//console.log("apiurl :: "+apiurl)
var htmlpath=conf.filepath;
var applicationurl=conf.applicationurl;
var retargetpath = conf.retargetpath;
var retargetpath1=conf.retargetpath1;

var bodyParser = require('body-parser');
router.use(bodyParser.urlencoded({ extended: false }));
router.use(multer({ dest: './temp/'}));

var utility = require('utility');

/* GET home page. */
router.get('/', function(req, res, next) {
    res.render('index', { title: 'Express' });
});


/*
 var app = express();
 var server = require('http').Server(app);
 var io = require('socket.io')(server);

 app.use(express.static(__dirname + '/public'));



 io.on('connection', function(socket) {
 console.log('new connection');

 socket.on('addNotification', function(customer) {
 io.emit('notification', {
 message: 'new customer',
 customer: customer
 });
 });
 });
 *//*
 server.listen(1111, function() {
 console.log('server up and running at 1111 port');
 });*!/
 */




router.post('/login', function (req, res) {
    var uname = req.body.email;
    var pwd = req.body.password;
  /*uname = 'admin@way2online.com';
   pwd = 'test@way2';*/
    //console.log(req.body);
    //console.log(req.body.email);
    //console.log(req.body.password);
    //var url = apiurl+"api/users/authenticate/"

    var obj = {
        "email": uname,
        "password": pwd
    }
    // console.log(obj);

    var credentials = {"credentials": obj}
    request({
        url: apiurl+"api/users/authenticate/",
        method: "POST",
        json: true,
        body: credentials
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
            res.send('failure');
        } else {
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                console.log('login failed ::: ' + response.statusCode);
                console.log(response.body.error.message);
                res.send("Invalid Username or Password");
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {

                // console.log('login success ::: ' + response.statusCode);
                res.cookie('userid', parseInt(response.body.data.id));
                res.cookie('userName',response.body.data.name);
                // res.cookie('userid', parseInt(response.body.data.id), {maxAge: 900000});
                res.send('success');

            }
            else {
                res.send('Invalid Username or Password');
            }

        }
    });

});



router.get('/activityLog/:limit', function (req, res) {
    //console.log('activityLog');
    var id = req.cookies.userid;
    var limit = req.params.limit;
    var obj = {"limit":limit};
    var url=apiurl+"api/notifications?filter="+JSON.stringify(obj);
    //console.log(url);
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        //console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @activityLog');
            } else {
                // console.log(response.body)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message);
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message);
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    //  console.log('activityLog no ::: ' + response.body.data.length);

                    res.send(response.body);

                } else {
                    res.send({"error": "API Error"});
                }

            }
        });


    }

});

router.post('/updateNotification', function (req, res) {

    var id = req.cookies.userid;
    var notifId = req.body.notifId;
    var date1 = new Date().toISOString().substr(0, 10);
    var date = new Date(date1+" 00:00:00");
    var unixtimes = date.getTime() / 1000;


    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var obj = {"notifId":notifId,"readOn":unixtimes};

        var url = apiurl+"api/notifications/update/user/"+id;
        // console.log(url);
        // console.log(obj);
        request({
            url: url,
            method: "POST",
            json: true,
            body: obj
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('failure');
            } else {
                // console.log(response.data)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('updateNotification failed ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message);
                        res.send({"error": "URL Not Found updateNotification" + url});
                    } else {
                        console.log(response.body.error.message);
                        res.send({"error": response.body.error.message});
                    }
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log('updateNotification success ::: ' + response.statusCode);
                    res.send({"success": 'updateNotification Succesfully'});
                } else {
                    res.send('unknown error from API updateNotification: ' + response.statusCode);
                }

            }
        });

    }

});


router.post('/updateDesktopNotify', function (req, res) {

    var id = req.cookies.userid;
    var notifId = req.body.notifId;
    var date1 = new Date().toISOString().substr(0, 10);


    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var obj = {"notifId":notifId,"readOn":1};

        var url = apiurl+"api/notifications/update/user/"+id;
        // console.log(url);
        // console.log(obj);
        request({
            url: url,
            method: "POST",
            json: true,
            body: obj
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('failure');
            } else {
                // console.log(response.data)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('updateNotification failed ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message);
                        res.send({"error": "URL Not Found updateNotification" + url});
                    } else {
                        console.log(response.body.error.message);
                        res.send({"error": response.body.error.message});
                    }
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log('updateNotification success ::: ' + response.statusCode);
                    res.send({"success": 'updateNotification Succesfully'});
                } else {
                    res.send('unknown error from API updateNotification: ' + response.statusCode);
                }

            }
        });

    }

});


router.post('/infoNotification', function (req, res) {

    //console.log('infoNotification');
    var id = req.cookies.userid;
    var type = req.body.type;
    var url=apiurl+"api/notifications/pending/user/"+id+"?type="+type;
    console.log(url);
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @alertNotification');
            } else {

                // console.log(response.body)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message);
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message);
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log('alertNotification no ::: ' + response.body.data.length);

                    res.send(response.body.data);

                } else {
                    res.send({"error": "alertNotification API Error"});
                }

            }
        });


    }

});


router.post('/getNlmAlloted', function (req, res) {

    //console.log('getNlmAlloted');
    var id = req.cookies.userid;

    var date1 = new Date().toISOString().substr(0, 10);
    var date = new Date(date1+" 00:00:00");
    var now = date.getTime() / 1000;

    var filter = {"where":{"userId":id,"status":2}};

    var url=apiurl+"api/nlmAllottedPush?filter="+JSON.stringify(filter);


    //console.log(url+" and obj getNlmAlloted  ");
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {

        // console.log('requesting getNlmAlloted');
        request({
            url: url,
            method: "GET",
            json: true

        }, function (err, response, body) {

            if (err) {
                console.log(err.stack);
                //res.send('Error while accessing API @getNlmAlloted');
            }

            else {

                // console.log(response.body)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    //console.log('error getNlmAlloted::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)

                        //res.send({"error": "URL Not Found " + url});

                    } else {
                        console.log(response.body.error.message);
                        res.send({"error getNlmAlloted": response.body.error.message});
                        //socket.emit('addNotification', response.body.error.message);
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201)
                {
                    // console.log('getNlmAlloted no ::: ' + JSON.stringify(response.body.data));
                    //   console.log(response.body.data.length);

                    var i=0;
                    processNotifica();
                    console.log("done all 0000status upate and pushing ");
                    function processNotifica() {
                        console.log("processNotifica called");
                        if (i < response.body.data.length) {
                            console.log("done al33333l status upate and pushing ");
                            var idd=response.body.data[i].id;

                            var altPush = response.body.data[i].altPush;
                            var nlmId = response.body.data[i].nlmId;
                            var alotDate = response.body.data[i].date;
                          /* console.log("nlmId :  " + response.body.data[i].nlmId);
                           console.log("altPush : " + response.body.data[i].altPush);
                           console.log("alotDate  : " + response.body.data[i].date);*/

                            request({

                                method: 'GET',
                                url: apiurl + 'api/nlm/' + parseInt(response.body.data[i].nlmId)

                            }, function (error, response, then) {
                                if (error) {
                                    console.log(error.stack);
                                }
                                else {
                                    //console.log("else newslettername");
                                    if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                        console.log('NEws error newslettername ' + response.statusCode);
                                        // console.log(JSON.parse(response.body.toString()).error);

                                        // res.send(response.body.error);
                                    }
                                    else if (response.statusCode === 200 || response.statusCode === 201) {

                                        console.log('Getting news newslettername: ' + JSON.parse(response.body).data.title);

                                        var newsName = JSON.parse(response.body).data.title;
                                        //res.send(response.body);

                                        var msg = "Requested vol of " + altPush + " is done for " + newsName + " successfully";
                                        // console.log("msg : " + msg);
                                        var objAlert = {
                                            "msg": msg,
                                            "desc": msg,
                                            "src": msg,
                                            "type": "alert",
                                            "userIds": [parseInt(id)],
                                            "port": 2008,
                                            "ctdOn": now
                                        };
                                        // console.log("objAlert  :  " + JSON.stringify(objAlert));

                                        request({

                                            url: apiurl + "api/notifications/insert",
                                            method: "POST",
                                            json: true,
                                            body: objAlert

                                        }, function (err, response, body) {
                                            if (err) {
                                                console.log(err.stack);
                                            } else {
                                                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                                    console.log('Requested vol updateNews error ' + response.statusCode);

                                                    // console.log(response.body.error)
                                                    res.send(response.body.error);
                                                }
                                                else if (response.statusCode === 200 || response.statusCode === 201) {

                                                    //  console.log('Requested vol updateNews Created  : ');
                                                    //  console.log(apiurl + 'api/nlmAllottedPush/update?nlmId=' + parseInt(nlmId) + '&date=' + alotDate);
                                                    request({

                                                        method: 'POST',
                                                        url: apiurl + 'api/nlmAllottedPush/update/'+idd,
                                                        body: {"status": 3},
                                                        json: true
                                                    }, function (error, response, then) {
                                                        if (error) {
                                                            console.log(error.stack);
                                                        }
                                                        else {
                                                            // console.log("else response nlmAllottedPush/update");
                                                            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                                                console.log('NEws error nlmAllottedPush/update ' + response.statusCode);

                                                                res.send(response.body.error);
                                                            }
                                                            else if (response.statusCode === 200 || response.statusCode === 201) {
                                                                // console.log('Getting news nlmAllottedPush/update: ');
                                                                // console.log("updated nlmAllottedPush   " + response.body.data);

                                                                i++;
                                                                setImmediate(processNotifica);


                                                                //res.send(response.body);
                                                            }
                                                            else {
                                                                res.send('unknown error from API  nlmAllottedPush/update: ' + response.statusCode);
                                                            }
                                                        }

                                                    })


                                                    // res.send(response.body);
                                                } else {
                                                    console.log("line484");
                                                    //console.log("updatenews : " + JSON.stringify(response.body));
                                                    //res.send('unknown error from API  updateNews : ' + response.statusCode);
                                                }
                                            }
                                        });


                                    }
                                    else {
                                        console.log("done all1111 status upate and pushing ");
                                        res.send('unknown error from API  newslettername: ' + response.statusCode);
                                    }
                                }

                            })
                        }
                        else {
                            console.log("done all status upate and pushing ");
                            res.send("No Data");
                        }


                    }


                } else
                {
                    res.send({"error": "getNlmAlloted API Error"});
                }

            }
        });


    }

});


router.post('/alertNotification', function (req, res) {

    //console.log('alertNotification');
    var id = req.cookies.userid;
    var type = req.body.type;
    var url=apiurl+"api/notifications/pending/user/"+id+"?type="+type;
    //console.log(url);
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        //console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @alertNotification');
            } else {

                //  console.log(response.body)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    //console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        //res.send({"error": "URL Not Found " + url});

                    } else {
                        console.log(response.body.error.message);
                        res.send({"error": response.body.error.message});
                        //socket.emit('addNotification', response.body.error.message);
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201)
                {
                    //  console.log('alertNotification no ::: ' + response.body.data.length);

                    res.send(response.body.data);

                } else
                {
                    res.send({"error": "alertNotification API Error"});
                }

            }
        });


    }

});


/*
router.post('/putNotification', function (req, res) {

    // console.log('putNotification');
    var id = req.cookies.userid;


    var date1 = new Date().toISOString().substr(0, 10);
    var date = new Date(date1+" 00:00:00")
    var now = date.getTime() / 1000;

    var url=apiurl+"api/notifications/insert";
    var obj = {
        "msg": req.body.msg,
        "desc": req.body.desc,
        "src":req.body.src,
        "type": req.body.type,
        "userIds":[id],
        "port": 2008,
        "ctdOn": now
    }

    // console.log(url+" and obj putNotification  "+obj);
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {

        console.log('requesting putNotification');
        request({
            url: url,
            method: "POST",
            json: true,
            body:obj
        }, function (err, response, body) {

            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @putNotification');
            } else {

                //console.log(response.body)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    console.log('error putNotification::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        //res.send({"error": "URL Not Found " + url});

                    } else {
                        console.log(response.body.error.message);
                        res.send({"error putNotification": response.body.error.message});
                        //socket.emit('addNotification', response.body.error.message);
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201)
                {
                    //console.log('putNotification no ::: ' + response.body.data.length);
                    res.send(response.body.data);

                } else
                {
                    res.send({"error": "putNotification API Error"});
                }

            }
        });


    }

});

*/


router.post('/getPermissions', function (req, res) {
    // console.log('getting');
    //var id = req.cookies.userid;
    var id = req.body.id;
    //console.log("id  :  ",id);

    var url=apiurl+"api/users/permission/main/"+id;
    // console.log(url);
    var result = [];
    var mainArr = [];
    var subArr = [];
    var names = {};
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        // console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetPermissions');
            } else {
                //console.log(response.body)

                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message);
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message);
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log('no of permissions ::: ' + response.body.data.length);
                    //console.log(response.body);
                    if(response.body.data != null) {
                        for (i = 0; i < response.body.data.length; i++) {
                            names[response.body.data[i].name] = parseInt(response.body.data[i].id);
                            response.body.data[i].selected = false;
                            mainArr.push(response.body.data[i]);

                        }
                    }
                    //console.log(mainArr)
                    result.push(mainArr);
                    result.push(names);
                    res.send({"success": result});

                } else {
                    res.send({"error": "API Error"});
                }
            }
        });
    }

});


router.post('/getMainPermissions', function (req, res) {

    var id = req.cookies.userid;
    var url = apiurl+"api/permissions/main/";
    //console.log(url);
    var result = [];
    var mainArr = [];
    var names = {};
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        //console.log('if failed');
        res.send('logout');
    } else {
        //console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true
        }, function (err, response, body) {
            if (err) {
                //console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    //console.log('getting permissions list failed ::: ' + response.statusCode);
                    if (response.statusCode === 404) {

                    }
                    console.log(response.body.error.message);
                    res.send(response.body.error.message);
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {

                    // console.log('no of main permissions ::: ' + response.body.length);

                    if(response.body.data != null){
                        for (i = 0; i < response.body.data.length; i++) {
                            names[response.body.data[i].name] = parseInt(response.body.data[i].id);
                            mainArr.push(response.body.data[i].name)
                        }
                    }
                  /*  console.log('mainARR '+mainArr)
                   console.log('names '+names)*/
                    result.push(mainArr);
                    result.push(names);
                    res.send(result);
                }
            }
        });
    }
});
router.post('/getUsers', function (req, res) {
    var id = req.cookies.userid;
    var url = apiurl+"api/users/" + Number(id) + "/subUsers";
    // console.log(url)
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        request({
            url: url,
            method: "GET",
            json: true
        }, function (err, response, body) {
            if (err) {
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    //console.log('getting user details failed ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message);
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message);
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    var arr = [];
                    for (i = 0; i < response.body.data.length; i++) {
                        arr.push(response.body.data[i])
                        //console.log(response.body.data[i].name)
                    }
                    //console.log(arr);
                    res.send({"success": arr});
                } else {
                    res.send('unknown error from API : ' + response.statusCode);
                }

            }
        });

    }

});
router.post('/getUser', function (req, res) {
    var id = req.cookies.userid;
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var userid = parseInt(req.body.id);
        var url = apiurl+"api/users/" + Number(userid);
        // console.log(url);
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    res.send({"success": response.body.data});
                } else {
                    res.send({"error": "API Error"});
                }

            }
        });
    }


});


router.post('/deleteNewsletter', function (req, res) {
    var id = req.cookies.userid;
    var newsId = req.body.newsId;
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var url = apiurl+"api/nlm/delete/"+newsId;
        // console.log(url);
        request({
            url: url,
            method: "POST",
            json: true,
            body: {"cBy":parseInt(id)}
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('failure');
            } else {
                // console.log(response.data)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('updation deleteNewsletter failed ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not deleteNewsletter Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log('updation deleteNewsletter success ::: ' + response.statusCode);
                    res.send({"success": 'Deleted Succesfully'});
                } else {
                    res.send('unknown error from API : ' + response.statusCode);
                }

            }
        });

    }

});



router.post('/updateUser', function (req, res) {
    var id = req.cookies.userid;
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var obj = req.body;
        var userid = parseInt(obj.id);
        var url = apiurl+"api/users/update/"+userid;
        // console.log(url);
        delete obj.id;
        // console.log(obj);
        request({
            url: url,
            method: "POST",
            json: true,
            body: obj
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('failure');
            } else {
                // console.log(response.data)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('updation failed ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log('updation success ::: ' + response.statusCode);
                    res.send({"success": 'Updated Succesfully'});
                } else {
                    res.send('unknown error from API : ' + response.statusCode);
                }

            }
        });

    }

});
router.post('/addUser', function (req, res) {
    var id = req.cookies.userid;
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        // console.log();
        var obj = req.body;
        // console.log(obj);
        var url = apiurl+"api/users/create/"
        request({
            url: url,
            method: "POST",
            json: true,
            body: obj
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('failure');
            } else {
                //console.log(response.body)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    //console.log(response.body.message);
                    // console.log('adding success ::: ' + response.statusCode);
                    res.send({"success": response.body.message});
                } else {
                    res.send({"error": "API Error"});
                }

            }
        });
    }
});
router.post('/getSubPermissions', function (req, res) {
    var id = req.cookies.userid;
    //console.log(req.body)
    var mainid = parseInt(req.body.mainId);
    var allotId = parseInt(req.body.allotId);
    //var url = apiurl+"api/users/permission/sub/"+allotId+"?mainId="+mainid;
    var url=apiurl+"api/permissions/main/"+mainid+"/subs";
    //console.log(url);
    var result = [];
    var subArr = [];
    var names = {};
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        // console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log('no of sub permissions ::: ' + response.body.data.length);

                    for (i = 0; i < response.body.data.length; i++) {
                        names[response.body.data[i].name] = parseInt(response.body.data[i].id);
                        subArr.push(response.body.data[i]);
                        //subArr.push(response.body.data[i].name)
                    }
                    result.push(subArr);
                    result.push(names);
                  /*console.log(subArr);
                   console.log(names);
                   console.log(result);*/
                    res.send({"success": result});
                } else {
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});

router.post('/getAllotPermissions', function (req, res) {
    var id = req.cookies.userid;
    //console.log(req.body)
    var mainid = parseInt(req.body.mainId);
    var allotId = parseInt(req.body.allotId);

    var url=apiurl+"api/permissions/main/"+mainid+"/subs";
    //console.log(url);
    var result = [];
    var subArr = [];
    var names = {};
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log('no of sub permissions ::: ' + response.body.data.length);
                    for (i = 0; i < response.body.data.length; i++) {
                        names[response.body.data[i].name] = parseInt(response.body.data[i].id);
                        subArr.push(response.body.data[i]);
                        //subArr.push(response.body.data[i].name)
                    }
                    result.push(subArr);
                    result.push(names);


                    var result1 = [];
                    var subArr1 = [];
                    var names1 = {};
                  /*var url=apiurl+"api/permissions/main/"+mainid+"/subs";*/
                    var url = apiurl+"api/users/permission/sub/"+allotId+"?mainId="+mainid;
                    request({
                        url: url,
                        method: "GET",
                        json: true,
                    }, function (err, response, body) {
                        if (err) {
                            console.log(err.stack);
                            res.send('Error while accessing API @GetMainPermissions');
                        } else {
                            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                                if (response.statusCode === 404) {
                                    console.log(response.body.error.message)
                                    res.send({"error": "URL Not Found " + url});
                                } else {
                                    console.log(response.body.error.message)
                                    res.send({"error": response.body.error.message});
                                }

                            }
                            else if (response.statusCode === 200 || response.statusCode === 201) {
                                // console.log('no of sub permissions ::: ' + response.body.data.length);
                                for (i = 0; i < response.body.data.length; i++) {
                                    names1[response.body.data[i].name] = parseInt(response.body.data[i].id);
                                    subArr1.push(response.body.data[i]);
                                    //subArr.push(response.body.data[i].name)
                                }
                                result1.push(subArr1);
                                result1.push(names1);

                                // res.send();
                                res.send({"success2": result,"success": result1});
                            } else {
                                res.send({"error": "API Error main "});
                            }
                        }
                    });

                } else {
                    res.send({"error": "API Error main alloted user"});
                }
            }
        });
    }
});

router.post('/getTasks', function (req, res) {
    var id = req.cookies.userid;
    // console.log(req.body);
    var subid = parseInt(req.body.subId);

    var url = apiurl+"api/permissions/sub/" + subid + "/tasks";
    // console.log(url);
    var result = [];
    var subArr = [];
    var names = {};
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        //  console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log('no of tasks::: ' + response.body.data.length);
                    //console.log(response.body.data);
                    for (i = 0; i < response.body.data.length; i++) {
                        names[response.body.data[i].name] = parseInt(response.body.data[i].id);
                        subArr.push(response.body.data[i]);
                        //subArr.push(response.body.data[i].name)
                    }
                    result.push(subArr);
                    result.push(names);
                  /*console.log(subArr);
                   console.log(names);
                   console.log(result);*/
                    res.send({"success": result});
                } else {
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});

router.post('/getInnerCampaignsR', function (req, res) {
    var id = req.cookies.userid;
  /*var url = apiurl+"api/nlm";*/
    var url = apiurl+req.body.url
    console.log("getInnerCampaigns  :  "+url);
    var result = [];
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log("response.body.data :: "+JSON.stringify(response.body.data));
                    // console.log("response.body.data.length :: "+response.body.data.length);
                    res.send(response.body.data);

                } else {
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});

router.post('/getInnerCampaigns', function (req, res) {
    var id = req.cookies.userid;
  /*var url = apiurl+"api/nlm";*/
    var url = apiurl+req.body.url
    console.log("getInnerCampaigns  :  "+url);
    var result = [];
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log("response.body.data :: "+JSON.stringify(response.body.data));
                    // console.log("response.body.data.length :: "+response.body.data.length);

                    var finaldatasend=[];
                    var tempdatasend=[];
                    var f=0;
                    getReqstatus();
                    function getReqstatus()
                    {
                        if(f<response.body.data.length)
                        {

                            tempdatasend=response.body.data[f];
                            var nlmid=response.body.data[f].id;
                            var datess=response.body.data[f].ctdOn;
                            // console.log("nlmid :: "+nlmid+ "datess :: "+datess);

                            console.log(apiurl+"api/nlmAllottedPush/byNlmIdDate?nlmId="+nlmid+"&date="+datess);

                            request({
                                url: apiurl+"api/nlmAllottedPush/byNlmIdDate?nlmId="+nlmid+"&date="+datess,
                                method: "GET",
                                json: true
                            }, function (err, response, body) {
                                if (err) {
                                    console.log(err.stack);
                                    res.send('Error while accessing API @GetMainPermissions');
                                } else {
                                    if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                                        if (response.statusCode === 404) {
                                            console.log(response.body.error.message)
                                            res.send({"error": "URL Not Found " + url});
                                        } else {
                                            console.log(response.body.error.message)
                                        }
                                    }
                                    else if (response.statusCode === 200 || response.statusCode === 201) {

                                        //  console.log("MY RESPONSE "+JSON.stringify(response));
                                        if(response.body.data.length>0)
                                        {
                                            var reqPush=response.body.data[0].reqPush;
                                            var altPush=response.body.data[0].altPush;
                                            var status=response.body.data[0].status;
                                            tempdatasend["reqPush"]=reqPush;
                                            tempdatasend["altPush"]=altPush;
                                            tempdatasend["statusreq"]=status;
                                            //console.log("tempdatasend :: "+tempdatasend)
                                            finaldatasend.push(tempdatasend);
                                        }

                                        f++;
                                        setImmediate(getReqstatus);

                                    } else {
                                    }
                                }
                            });

                        }
                        else {



                            // console.log("done finaldatasend :: "+JSON.stringify(finaldatasend));
                            res.send(finaldatasend);

                        }



                    }







                } else {
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});

router.post('/getTodaysCampaigns', function (req, res) {
    var id = req.cookies.userid;
    // var url = apiurl+"api/nlm/today";
    var url = apiurl+req.body.url;
    // console.log(url);
    var result = [];
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log(response.body)
                    result.push(response.body.data);
                    var date1 = new Date().toISOString().substr(0, 10);
                    var date = new Date(date1+" 00:00:00")
                    var unixtimes = date.getTime() / 1000;
                    var url1 = apiurl+"api/userNLMs/allPickedVol?date=" + unixtimes;
                    // console.log("1212121212 :: "+url1);
                    request({
                        url: url1,
                        method: "GET",
                        json: true,
                    }, function (err, resp, body) {
                        if (err) {
                            console.log(err.stack);
                            res.send('Error while accessing API @GetMainPermissions');
                        } else {
                            if (resp.statusCode === 400 || resp.statusCode === 401 || resp.statusCode === 500 || resp.statusCode === 404) {
                                if (resp.statusCode === 404) {
                                    console.log("HIIIIIII :: "+resp.body.error.message)
                                    res.send({"error": "URL Not Found " + url});
                                } else {

                                    console.log("BIIIII   "+resp.body.error.message)
                                    res.send({"error": resp.body.error.message});
                                }

                            }
                            else if (resp.statusCode === 200 || resp.statusCode === 201) {
                                //  console.log(resp.body);
                                //  console.log(resp.body.data);
                                result.push(resp.body.data);

                                res.send({"success": result});
                            } else {
                                res.send({"error": "API Error"});
                            }
                        }
                    });

                } else {
                    res.send({"error": "API Error"});
                }
            }
        });

        //dummy data
      /*

       var sn1 = ["camp1-sender1", "camp1-sender2"];
       var sn2 = ["camp2-sender1", "camp2-sender2"];
       var sub1 = ["camp1-subj1", "camp1-subj2"];
       var sub2 = ["camp2-subj1", "camp2-subj2"];

       var arr = [];
       var obj = {
       "SN": sn1,
       "SL": sub1,
       "cBy": "Anil",
       "title": "News Letter 1",
       "sent_volume": 20,
       "total_volume": 20,
       "type": "Click",
       "id": 1,
       };
       var obj1 = {
       "SN": sn2,
       "SL": sub2,
       "cBy": "Kumar",
       "title": "News Letter 2",
       "type": "Open",
       "sent_volume": 18,
       "total_volume": 20,
       "id": 3,
       }
       var obj2 = {
       "SN": sn2,
       "SL": sub2,
       "cBy": "Kumar",
       "title": "News Letter 2",
       "type": "Open",
       "sent_volume": 18,
       "total_volume": 20,
       "id": 7,
       }
       arr.push(obj);
       arr.push(obj1);
       arr.push(obj2);
       console.log('check here');
       for (var obj in arr) {
       arr[obj].remaining_volume = parseInt(arr[obj].total_volume) - parseInt(arr[obj].sent_volume);
       console.log(arr[obj])
       }
       console.log(arr)
       res.send(arr);

       */
    }
});

router.post('/getNewsLetter', function (req, res) {
    var id = req.cookies.userid;
    //console.log(req.body);
    var nlid = parseInt(req.body.nlId);

    var url = apiurl+"api/nlm/" + nlid;
    // console.log(url);
    var result = [];
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    //  console.log(response.body.data);
                    if (response.body.data != null && response.body.data != undefined) {

                        //   console.log('before : ' + response.body.data.startOn + "    " + response.body.data.endOn);
                        response.body.data.startOn = getTime(response.body.data.startOn);
                        response.body.data.endOn = getTime(response.body.data.endOn);
                        //   console.log('after : ' + response.body.data.startOn + "    " + response.body.data.endOn);

                        var date1 = new Date().toISOString().substr(0, 10);
                        var date = new Date(date1+" 00:00:00")
                        var unixtimes = date.getTime() / 1000;
                        //filter = {nlmId:1, date:1470614400, userId:208}
                        var reqObj = {"nlmId": nlid, date: unixtimes};
                        var url1 = apiurl+"api/userNLMs/pickedVol?filter="+JSON.stringify(reqObj);
                        //  console.log(url1);
                        var result = response.body.data;
                        request({
                            url: url1,
                            method: "GET",
                            json: true,
                        }, function (err, resp, body) {
                            if (err) {
                                console.log(err.stack);
                                res.send('Error while accessing API @GetMainPermissions');
                            } else {
                                if (resp.statusCode === 400 || resp.statusCode === 401 || resp.statusCode === 500 || resp.statusCode === 404) {
                                    if (resp.statusCode === 404) {
                                        console.log(resp.body.error.message)
                                        res.send({"error": "URL Not Found " + url});
                                    } else {
                                        console.log(resp.body.error.message)
                                        res.send({"error": resp.body.error.message});
                                    }

                                }
                                else if (resp.statusCode === 200 || resp.statusCode === 201) {
                                    if (resp.body.data.totalPicked != undefined && resp.body.data.totalPicked != null) {
                                        result.picked_volume = parseInt(resp.body.data.totalPicked);
                                    } else {
                                        result.picked_volume = 0;
                                    }
                                    res.send({"success": result});
                                } else {
                                    res.send({"error": "API Error"});
                                }
                            }
                        });


                    } else {
                        res.send({"error": "Campaign Not Found"});
                    }


                } else {
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});
router.post('/allotToMe', function (req, res) {
    var id = req.cookies.userid;
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var obj = req.body;
        //  console.log(obj);
        var userid = parseInt(obj.id);
        var url = apiurl+"api/userNLMs/addNlm";
        // console.log(url);
        //console.log(obj);

        request({
            url: url,
            method: "POST",
            json: true,
            body: {"userId":obj.userId,"pickVol":obj.pickVol,"nlmId":obj.nlmId}
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send({"error": 'failure'});
            } else {
                console.log('allotTome result')
                //  console.log(response.data)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('updation failed ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {

                    var msg=obj.campRelName+"  "+obj.pickVol+" picked by "+obj.agentName;
                    //  console.log("msg :: "+msg);

                    var objAlert = {
                        "msg": msg,
                        "desc": msg,
                        "src": msg,
                        "type": "alert",
                        "userIds": [obj.userRelId],
                        "port": 2008,
                        "ctdOn":parseInt(Math.floor(new Date().getTime() / 1000))
                    }

                    //  console.log("objAlert for today  : "+JSON.stringify(objAlert)+"  userRelId : "+obj.userRelId);
                    desktopNotifiction(objAlert);

                    res.send({"success": 'Updated Succesfully'});
                } else {
                    res.send('unknown error from API : ' + response.statusCode);
                }
            }
        });

    }

});




router.post('/uploadFileR', function (req, res) {
    // console.log("22222");
    var countI=0;
    var countH=0;
    var filenamesList=[];
    var userid = req.cookies.userid;
    // console.log("new upload ",req);
    //fs.createReadStream(req.files.file.path).pipe(unzip.Extract({ path: '/home/sys198/Desktop/I' }));
    //var readStream = fs.createReadStream(req.files.file.path);

    fs.createReadStream(req.files.file.path)
        .pipe(unzip.Parse())
        .on('entry', function (entry) {
            var fileName = entry.path;
            var type = entry.type; // 'Directory' or 'File'
            var size = entry.size;

            var now = new Date();
            console.log("filename : ", fileName);
            if (type === 'File') {
                console.log("file type  :  ");

                if (fileName.indexOf('.gif')!=-1 || fileName.indexOf('.jpg')!=-1 || fileName.indexOf('.jpeg')!=-1 || fileName.indexOf('.png')!=-1) {
                    countI++;
                    console.log(fileName + '  &  count is ' + countI);
                    var str = fileName;
                    var index = str.lastIndexOf('/');
                    var oldImg = str.slice(index + 1, str.length);

                    var str12 = oldImg.indexOf('.');
                    var ext = oldImg.slice(str12 + 1, oldImg.length);

                    var dr = dateFormat(new Date(), "dMHmmss");
                    //console.log("newIMg  : "+dr+userid+countI+'.'+ext);

                    var newImg = dr + userid + countI + '.' + ext;
                    var jsonVar = {};
                    jsonVar[oldImg] = newImg;
                    filenamesList.push(jsonVar);
                    entry.pipe(fs.createWriteStream(retargetpath + newImg));
                    entry.pipe(fs.createWriteStream(htmlpath + newImg));
                    entry.pipe(fs.createWriteStream(retargetpath1 + newImg));

                    //console.log(filenamesList);

                }
            }

        })
        .on('close',function(closeEle){
            // console.log("on close called");
            // console.log(filenamesList);
            fs.createReadStream(req.files.file.path)
                .pipe(unzip.Parse())
                .on('entry', function (entry) {
                    var fileName = entry.path;
                    var type = entry.type; // 'Directory' or 'File'
                    var size = entry.size;

                    var now = new Date();
                    //  console.log("filename : ", fileName);
                    if (type === 'File') {

                        if(fileName.indexOf('.htm')!=-1 || fileName.indexOf('.html')!=-1 || fileName.indexOf('.HTML')!=-1 ||fileName.indexOf('.HTM')!=-1)
                        {
                            countH++;
                            var str11 = fileName;
                            var index1 = str11.lastIndexOf('/');
                            var htmlfile = str11.slice(index1+1, str11.length);
                            var srchString = "2271226107_1.jpg";
                            var newString = "83318085521.jpg";


                            var writeComplete = entry.pipe(fs.createWriteStream(retargetpath+htmlfile));
                            var writeComplete1 = entry.pipe(fs.createWriteStream(htmlpath+htmlfile));
                            var writeComplete2 = entry.pipe(fs.createWriteStream(retargetpath1+htmlfile));

                            writeComplete.on('close', function() {

                                var newContents = readFileR(htmlfile,filenamesList);
                                // console.log(newContents);
                                res.send(newContents);

                            });

                            writeComplete1.on('close', function() {

                            });
                            writeComplete2.on('close', function() {

                            });

                            // console.log(htmlfile+'  &  count is '+countH);
                        }

                    }

                    if (type === "this IS the file I'm looking for") {
                        entry.pipe(fs.createWriteStream('output/path'));

                    } else {
                        entry.autodrain();
                    }
                })

        });


    function readFileR(htmlfile,srchString)
    {

        // console.log("inside readFIle");
        // console.log(srchString);


        var contents = fs.readFileSync(retargetpath+htmlfile, 'utf8');
        // console.log("data from readFIle");
        //console.log(contents);


        for (var k in srchString){
            if (srchString.hasOwnProperty(k)) {
                for (var key in srchString[k]){
                    if (srchString[k].hasOwnProperty(key)) {

                        //  console.log("Key is " + key + ", value is" + srchString[k][key]);

                        var subIndex = contents.indexOf(key);
                        var searchContent = contents.slice(0,subIndex);
                        var lastSrc = searchContent.lastIndexOf("src");
                        var compLen =subIndex+key.length;
                        var replaceContent = contents.slice(lastSrc,compLen+1);
                        //  console.log(lastSrc+"  "+key.length);
                        var newContent ="src=\""+applicationurl+srchString[k][key]+'\"';

                        var changeContent = contents.replace(replaceContent,newContent);
                        //  console.log("after replace : "+replaceContent+"     "+newContent);
                        //  console.log(contents.localeCompare(changeContent));

                        contents = changeContent;
                        //console.log(changeContent);
                    }}
            }
        }

        return contents;
    }

});

router.post('/uploadFile', function (req, res) {
    //console.log("22222");
    var countI=0;
    var countH=0;
    var filenamesList=[];
    var userid = req.cookies.userid;
    //console.log("new upload ",req);
    //fs.createReadStream(req.files.file.path).pipe(unzip.Extract({ path: '/home/sys198/Desktop/I' }));
    //var readStream = fs.createReadStream(req.files.file.path);

    fs.createReadStream(req.files.file.path)
        .pipe(unzip.Parse())
        .on('entry', function (entry) {
            var fileName = entry.path;
            var type = entry.type; // 'Directory' or 'File'
            var size = entry.size;

            var now = new Date();
            // console.log("filename : ", fileName);
            if (type === 'File') {
                //  console.log("file type  :  ");

                if (fileName.indexOf('.gif')!=-1 || fileName.indexOf('.jpg')!=-1 || fileName.indexOf('.jpeg')!=-1 || fileName.indexOf('.png')!=-1) {
                    countI++;
                    //   console.log(fileName + '  &  count is ' + countI);
                    var str = fileName;
                    var index = str.lastIndexOf('/');
                    var oldImg = str.slice(index + 1, str.length);

                    var str12 = oldImg.indexOf('.');
                    var ext = oldImg.slice(str12 + 1, oldImg.length);

                    var dr = dateFormat(new Date(), "dMHmmss");
                    //console.log("newIMg  : "+dr+userid+countI+'.'+ext);

                    var newImg = dr + userid + countI + '.' + ext;
                    var jsonVar = {};
                    jsonVar[oldImg] = newImg;
                    filenamesList.push(jsonVar);
                    entry.pipe(fs.createWriteStream(htmlpath + newImg));

                    //console.log(filenamesList);

                }
            }

        })
        .on('close',function(closeEle){
            //  console.log("on close called");
            //   console.log(filenamesList);
            fs.createReadStream(req.files.file.path)
                .pipe(unzip.Parse())
                .on('entry', function (entry) {
                    var fileName = entry.path;
                    var type = entry.type; // 'Directory' or 'File'
                    var size = entry.size;

                    var now = new Date();
                    //  console.log("filename : ", fileName);
                    if (type === 'File') {

                        if(fileName.indexOf('.htm')!=-1 || fileName.indexOf('.html')!=-1 || fileName.indexOf('.HTML')!=-1 ||fileName.indexOf('.HTM')!=-1)
                        {
                            countH++;
                            var str11 = fileName;
                            var index1 = str11.lastIndexOf('/');
                            var htmlfile = str11.slice(index1+1, str11.length);
                            var srchString = "2271226107_1.jpg";
                            var newString = "83318085521.jpg";


                            var writeComplete = entry.pipe(fs.createWriteStream(htmlpath+htmlfile));

                            writeComplete.on('close', function() {

                                var newContents = readFile(htmlfile,filenamesList);
                                //  console.log(newContents);
                                res.send(newContents);
                              /*   var contents = fs.readFileSync('/home/sys198/Desktop/I/'+htmlfile, 'utf8');
                               console.log("data from readFIle");
                               console.log(contents);
                               var subIndex = contents.indexOf(srchString);
                               var searchContent = contents.slice(0,subIndex);
                               var lastSrc = searchContent.lastIndexOf("src");
                               var compLen =subIndex+srchString.length;
                               var replaceContent = contents.slice(lastSrc,compLen+1);
                               console.log(lastSrc+"  "+srchString.length);
                               var newContent ="src=\"/home/sys198/Desktop/I/"+newString+'\"';
                               var changeContent = contents.replace(replaceContent,newContent);
                               console.log("after replace : "+replaceContent+"     "+newContent);
                               console.log(contents.localeCompare(changeContent));
                               console.log(changeContent);
                               res.send(changeContent);*/

                            });

                            //  console.log(htmlfile+'  &  count is '+countH);
                        }

                    }

                    if (type === "this IS the file I'm looking for") {
                        entry.pipe(fs.createWriteStream('output/path'));

                    } else {
                        entry.autodrain();
                    }
                })

        });


    function readFile(htmlfile,srchString)
    {

        // console.log("inside readFIle");
        //console.log(srchString);


        var contents = fs.readFileSync(htmlpath+htmlfile, 'utf8');
        console.log("data from readFIle");
        //console.log(contents);


        for (var k in srchString){
            if (srchString.hasOwnProperty(k)) {
                for (var key in srchString[k]){
                    if (srchString[k].hasOwnProperty(key)) {

                        // console.log("Key is " + key + ", value is" + srchString[k][key]);

                        var subIndex = contents.indexOf(key);
                        var searchContent = contents.slice(0,subIndex);
                        var lastSrc = searchContent.lastIndexOf("src");
                        var compLen =subIndex+key.length;
                        var replaceContent = contents.slice(lastSrc,compLen+1);
                        //console.log(lastSrc+"  "+key.length);
                        var newContent ="src=\""+applicationurl+srchString[k][key]+'\"';

                        var changeContent = contents.replace(replaceContent,newContent);
                        // console.log("after replace : "+replaceContent+"     "+newContent);
                        // console.log(contents.localeCompare(changeContent));

                        contents = changeContent;
                        //console.log(changeContent);
                    }}
            }
        }

        return contents;
    }

});



router.post('/getMyCampaigns', function (req, res) {
    var id = req.cookies.userid;


    var obj ={"userId":parseInt(req.body.id),"date":req.body.dt};
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {

        request({
            url: apiurl+"api/userNLMs/myCampaigns?filter="+JSON.stringify(obj),
            method: "GET"
        }, function (err, response, body) {
            if (err) {
                //console.log(err.stack);
                res.send('failure');
            } else {

                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {


                    console.log(JSON.parse(response.body.toString()).error);
                    console.log(JSON.parse(response.body.toString()).error.message);

                    res.send(response.body.error);
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    var obj=JSON.parse(response.body);

                    // console.log(obj.data);
                    res.send(obj.data.response);
                } else {
                    res.send('unknown error from API : ' + response.statusCode);
                }

            }
        });

    }
});

router.post('/pushVol', function (req, res) {
    var id = req.cookies.userid;
    var date = parseInt(Math.floor(new Date(req.body.dateStamp).getTime() / 1000));
    var nlmId = parseInt(req.body.nlmId);
    var userId = parseInt(req.body.userId);
    var pushVol = parseInt(req.body.pushVol);
    var url =apiurl+"api/userNLMs/update?nlmId="+nlmId+"&userId="+userId+"&date="+date;
    //console.log("pushVol  : ",pushVol);
    // console.log("pushVol   :   "+url);
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        request({
            url: url,
            method: "POST",
            json: true,
            body: {pushVol:pushVol}
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send({"error": 'failure'});
            } else {
                console.log('pushVol result')
                console.log(response.data)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log(JSON.parse(response.body.toString()).error);
                    console.log(JSON.parse(response.body.toString()).error.message);
                    console.log('pushVol updation failed ::: ' + response.statusCode);
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    console.log('updation success pushVol ' + response.statusCode+"  res.data   :  "+response.body.data);
                    res.send(response.data);
                } else {
                    res.send('unknown error from API : ' + response.statusCode);
                }
            }
        });

    }

});

//old statsLocation call
router.post('/statsLocation', function (req, res) {
    console.log("statsLocation");
    var id = req.cookies.userid;
    var date = parseInt(Math.floor(new Date(req.body.startOn).getTime() / 1000));
    var campId = parseInt(req.body.campId);
    var userId = parseInt(req.body.userId);
    var nlmId = parseInt(req.body.nlmId);

    //var url =apiurl+"api/statsLocation/campaign?userId="+id+"&campId="+campId+"&groupBy=city";
    var url =apiurl+"api/statsLocation/nlm?nlmId="+nlmId;

    console.log("url   :  ",url);

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        request({
            url: url,
            method: "GET"
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send({"error": 'failure'});
            } else {
                console.log('statsLocation result')
                console.log(response.data)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {

                    console.log('statsLocation updation failed ::: ' + response.statusCode);
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    console.log('updation success statsLocation ' + response.statusCode+"  res.data   :  "+response.body);
                    //res.send(response.body);



                    var cityObj=JSON.parse(response.body).data;

                    var i=0;
                    var datarr=[];
                    getcityname();
                   // console.log("cityObj.length :: "+cityObj.length);
                    function getcityname() {
                        if (i < cityObj.length) {

                            var cId = cityObj[i]._id.cityId;
                            //console.log("CITYID : "+cId);
                            var mjson= {open:cityObj[i].uOpen,click:cityObj[i].uClick}

                            if(parseInt(cId)!=0){
                            request({
                                url: apiurl + 'api/cities/' + parseInt(cId),
                                method: 'GET'
                            }, function (err, response, body) {
                                if (err) {
                                    console.log(err.stack);
                                    res.send('Error getStatsCity while accessing API');
                                } else {
                                    if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                        console.log('step6 getStatsCity get error ' + response.statusCode);
                                       console.log(JSON.stringify(response.body));
                                        res.send(response.body);
                                    }
                                    else if (response.statusCode === 200 || response.statusCode === 201) {

                                        var tempObj = JSON.parse(response.body).data;
                                        mjson.name=tempObj.name;
                                        datarr.push(mjson);
                                        //console.log("datarr getStatsCity LL  "+JSON.stringify(datarr));
                                        i++;
                                        setImmediate(getcityname);

                                    } else {
                                        res.send('unknown error from API getStatsCity : ' + response.statusCode);
                                    }
                                }
                            });}else{

                                mjson.name='';
                                datarr.push(mjson);
                                //console.log("city with id 0  "+JSON.stringify(datarr));
                                i++;
                                setImmediate(getcityname);
                            }

                        }
                        else
                        {
                            //console.log("DATARRA getStatsCity :: "+JSON.stringify(datarr));
                            res.send(datarr);

                        }

                    }

                } else {
                    res.send('unknown error from API : ' + response.statusCode);
                }
            }
        });

    }

});

//new statsLocation Call
/*router.post('/statsLocation', function (req, res) {
 console.log("statsLocation");
 var id = req.cookies.userid;
 var date = parseInt(Math.floor(new Date(req.body.startOn).getTime() / 1000));
 var campId = parseInt(req.body.campId);
 var userId = parseInt(req.body.userId);


 //var url =apiurl+"api/statsLocation/campaign?userId="+id+"&campId="+campId+"&groupBy=city";
 var url =apiurl+"api/statsLocation/nlm?nlmId="+campId;

 console.log("url   :  ",url);

 if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
 res.send('logout');
 } else {
 var output =[];
 output[-1]=[{open:'',click:'',name:''}]
 request({
 url: url,
 method: "GET"
 }, function (err, response, body) {
 if (err) {
 console.log(err.stack);
 res.send({"error": 'failure'});
 } else {
 console.log('statsLocation result')
 console.log(response.data)
 if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {

 console.log('statsLocation updation failed ::: ' + response.statusCode);
 }
 else if (response.statusCode === 200 || response.statusCode === 201) {
 console.log('updation success statsLocation ' + response.statusCode+"  res.data   :  "+response.body);
 // res.send(response.body);
 var obj = response.body.data;
 console.log("response.body.data  :  "+response.body.data)
 output = obj;
 var citiesNames = [];
 console.log("JSON obj "+JSON.stringify(obj));
 var cityIds = [];
 for(var i = 0;i<response.body.data.length;i++) {

 var cityObj= obj[i]._id;
 cityIds.push(cityObj.cityId);
 }


 request({
 url: apiurl + 'api/cities/ids?ids='+cityIds,
 method: 'GET'
 }, function (err, response, body) {
 if (err) {
 console.log(err.stack);
 res.send('Error getCityById while accessing API');
 } else {
 if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
 console.log('step6 getCityById get error ' + response.statusCode);
 console.log(response.body.error);
 res.send(response.body);
 }
 else if (response.statusCode === 200 || response.statusCode === 201) {
 console.log('step6 getCityById get : ');
 // res.send(response.body);
 for(var i = 0;i<response.body.data.length;i++) {
 output[i].name=response.body.name;
 }


 } else {
 res.send('unknown error from API getCityById : ' + response.statusCode);
 }
 }
 });

 }
 console.log("output  : "+JSON.stringify(output));
 res.send(output);


 } else {
 res.send('unknown error from API : ' + response.statusCode);
 }
 }
 });

 }

 });*/


//old statsdomain

router.post('/statsDomains', function (req, res) {
    console.log("statsDomains");
    var id = req.cookies.userid;
    //var fromTime = parseInt(req.body.sentOn);
    var date1 = new Date().toISOString().substr(0, 10);
    var sentOn = Math.round((new Date(date1 + " 00:00:00")).getTime() / 1000);

    var fromTime=1;
    console.log("req.body.sentOn   :  ",req.body.sentOn);
    var campId = parseInt(req.body.campId);
    var nlmId = parseInt(req.body.nlmId);
    // var toTime = parseInt(req.body.sentOn);
    var tosent=parseInt(Math.floor(new Date().getTime() / 1000));
    var toTime = tosent;

    var url =apiurl+"api/StatsDomains/domainWise?userId="+id+"&nlmId="+nlmId+"&campId="+campId+"&fromTime="+fromTime+"&toTime="+toTime;

    console.log("url   :  ",url);

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        request({
            url: url,
            method: "GET"
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send({"error": 'failure'});
            } else {
                console.log(response.data)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {

                    console.log('statsDomains updation failed ::: ' + response.statusCode);
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    console.log('updation success statsDomains ' + response.statusCode+"  res.data   :  "+response.body);

                    var domObj=JSON.parse(response.body).data;
                    var i=0;
                    var datarr=[];
                    getdomainname();
                    // console.log("domObj.length :: "+domObj.length);
                    function getdomainname() {
                        if (i < domObj.length) {



                            var dId = domObj[i]._id.dId;
                            var mjson={id:dId,open:domObj[i].uOpen,click:domObj[i].uClick,unSub:domObj[i].unSub,spam:domObj[i].spam,sent:domObj[i].sent,dlvrd:domObj[i].dlvrd,dOpen:domObj[i].dOpen,dClick:domObj[i].dClick,mOpen:domObj[i].mOpen,mClick:domObj[i].mClick,tOpen:domObj[i].tOpen,tClick:domObj[i].tClick,otherOpen:domObj[i].otherOpen,otherClick:domObj[i].otherClick};


                            request({
                                url: apiurl + 'api/domains/' + parseInt(dId),
                                method: 'GET'
                            }, function (err, response, body) {
                                if (err) {
                                    console.log(err.stack);
                                    res.send('Error getEdomainById while accessing API');
                                } else {
                                    if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                        console.log('step6 getEdomainById get error ' + response.statusCode);
                                        console.log(JSON.stringify(response.body));
                                        res.send(response.body);
                                    }
                                    else if (response.statusCode === 200 || response.statusCode === 201) {

                                        var tempObj = JSON.parse(response.body).data;
                                        mjson.name=tempObj.name;
                                        datarr.push(mjson);
                                        // console.log("datarr LL  "+JSON.stringify(datarr));
                                        i++;
                                        setImmediate(getdomainname);

                                    } else {
                                        res.send('unknown error from API getEdomainById : ' + response.statusCode);
                                    }
                                }
                            });

                        }
                        else
                        {
                            // console.log("DATARRA :: "+JSON.stringify(datarr));
                            res.send(datarr);

                        }

                    }





                } else {
                    res.send('unknown error from API : ' + response.statusCode);
                }
            }
        });

    }

});


//new statsdomain

/*router.post('/statsDomains', function (req, res) {
 console.log("statsDomains");
 var id = req.cookies.userid;
 //var fromTime = parseInt(req.body.sentOn);
 var date1 = new Date().toISOString().substr(0, 10);
 var sentOn = Math.round((new Date(date1 + " 00:00:00")).getTime() / 1000);

 var fromTime=1;
 console.log("req.body.sentOn   :  ",req.body.sentOn);
 var campId = parseInt(req.body.campId);
 var nlmId = parseInt(req.body.nlmId);
 // var toTime = parseInt(req.body.sentOn);
 var tosent=parseInt(Math.floor(new Date().getTime() / 1000));
 var toTime = tosent;

 var url =apiurl+"api/StatsDomains/domainWise?userId="+id+"&nlmId="+nlmId+"&campId="+campId+"&fromTime="+fromTime+"&toTime="+toTime;

 console.log("url   :  ",url);

 if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
 res.send('logout');
 } else {
 request({
 url: url,
 method: "GET"
 }, function (err, response, body) {
 if (err) {
 console.log(err.stack);
 res.send({"error": 'failure'});
 } else {
 //console.log(response.data)
 if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {

 console.log('statsDomains updation failed ::: ' + response.statusCode);
 }
 else if (response.statusCode === 200 || response.statusCode === 201) {
 console.log('updation success statsDomains ' + response.statusCode+"  res.data   :  "+response.body);
 // res.send(response.body);

 var domObj = JSON.parse(response.body).data;
 console.log("JSON.STRINGIFY(domObj)  :  "+domObj);
 console.log("JSON.STRINGIFY(domObj)  :  "+JSON.stringify(domObj));
 var domNames = [];
 var dNames =[];
 for(var x = 0;x<domObj.length+1;x++) {

 if(x<domObj.length){
 var i = x;
 var dId = domObj[i]._id.dId;
 domNames[i]={id:dId,open:domObj[i].uOpen,click:domObj[i].uClick,unSub:domObj[i].unSub,spam:domObj[i].spam,sent:domObj[i].sent,dlvrd:domObj[i].dlvrd};
 console.log("dId : "+JSON.stringify(domNames[i]));

 request({
 url: apiurl + 'api/domains/'+parseInt(dId),
 method: 'GET'
 }, function (err, response, body) {
 if (err) {
 console.log(err.stack);
 res.send('Error getEdomainById while accessing API');
 } else {
 if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
 console.log('step6 getEdomainById get error ' + response.statusCode);
 console.log(JSON.stringify(response.body));
 res.send(response.body);
 }
 else if (response.statusCode === 200 || response.statusCode === 201) {

 var tempObj = JSON.parse(response.body).data;
 console.log('step6 getEdomainById get : '+JSON.stringify(tempObj));
 console.log('tempObj.name : '+tempObj.name);
 dNames.push({id:tempObj.id,name:tempObj.name});

 } else {
 res.send('unknown error from API getEdomainById : ' + response.statusCode);
 }
 }
 });

 }
 console.log("x==domObj.length : "+x==domObj.length)
 if(x==domObj.length)
 {
 alignValues(domNames,dNames);
 }

 }
 var result = [];
 var j=0;
 function alignValues(domNames,dNames) {
 console.log("dNames.length  :  "+dNames.length)
 for(var i=0;i<dNames.length+1;i++)
 {
 if(i==dNames.length)
 {
 console.log("res.send(result)  :  "+JSON.stringify(result));
 res.send(result);
 }
 else if(i<dNames.length){
 console.log("dNAMES ELSEIF  :  "+dNames[i].id==domNames[i].id);
 if(dNames[i].id==domNames[i].id)
 { j++;
 result[j]=domNames[i];
 result[j].name=dNames[i].name;
 }
 }
 }

 }

 } else {
 res.send('unknown error from API : ' + response.statusCode);
 }
 }
 });

 }

 });*/



//new CreateTEstNews
router.post('/createTestNews', function (req, res) {


    var id = req.cookies.userid;
    var dateStamp = parseInt(Math.floor(new Date().getTime() / 1000));

    //console.log("createTestNews : obj ::  "+JSON.stringify(req.body));
    var notiObj = {"newsName":req.body.newsName,"agentName":req.body.agentName,"userRelId":req.body.userRelId
        ,"pushVol":req.body.tempVol};


    var obj = {
        campId: parseInt(req.body.campId),
        nlmId: parseInt(req.body.nlmId),
        SN: req.body.SN,
        SL: req.body.SL,
        creative: req.body.creative,
        startAt: dateStamp,
        userId: parseInt(req.body.userId),
        totalVol: parseInt(req.body.totalVol),
        domainWise: req.body.domainWise,
        tempVol: parseInt(req.body.tempVol),
        cType:"direct"
    }

    /*console.log("createTestNews object : "+JSON.stringify(obj));*/

    var tIds=[];


    if (req.body.emails != undefined) {
        var emailsstr=[];
        emailsstr=req.body.emails;
        console.log(emailsstr);
        var emailsarr=emailsstr[0].split(",");
        console.log("emailsarr :: "+emailsarr.length);

        var s=0;
        processemailids();
        function processemailids()
        {
            console.log("smtpObjecsssssst :: ");
            if(s<emailsarr.length)
            {
                console.log("smtpObjecsssssst :: "+ emailsarr[s]);
                var smtpObject={
                    "email": aes.encrypt(emailsarr[s].replace(/' '/g, '')),
                    "name":  emailsarr[s].substring(0,emailsarr[s].indexOf('@'))
                };
                var url =apiurl+"api/test-subscriber/create";
                console.log("smtpObject :: "+JSON.stringify(smtpObject));
                console.log("url  : "+url);
                request({
                    url: url,
                    method: "POST",
                    json: true,
                    body: smtpObject
                }, function (err, response) {
                    console.log("hello smtpRESPONSE");
                    if (err) {
                        res.send({'error':'Problem in sending Mail,plz try again later'});
                        console.log(err.stack);

                    } else {
                        console.log("1111");
                        if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                            console.log('  error ' + response.statusCode+' error message  '+JSON.stringify(response));

                            console.log("response.body.error.details.id :: "+response.body.error.details.id);
                            // res.send({'error':'Problem in sending Mail,plz try again later'});
                            s++;
                            if(typeof response.body.error.details.id != 'undefined')
                            {
                                tIds.push(response.body.error.details.id);
                                setImmediate(processemailids);
                                console.log("got subids");
                            }
                        }
                        else if (response.statusCode === 200 || response.statusCode === 201) {
                            if(response.body.data.id!=undefined)
                            {
                                console.log("response.body.data.id :: "+response.body.data.id)
                                s++;
                                tIds.push(response.body.data.id);
                                setImmediate(processemailids);
                                console.log("got subids");
                            }
                            else {

                            }

                        } else {
                            res.send({'error':'Problem in sending Mail,plz try again later'});
                            console.log('there is a problem in gettin subids');
                        }
                    }
                });

            }
            else {

                console.log("smtpObjectfdsdgfs :: ");
                if(tIds.length>0)
                {
                    obj["tIds"]=tIds;

                    console.log(obj);
                    procesdsCampfd();
                }
                else {
                    console.log(obj);
                    res.send({'error':'Problem in sending Mail,plz try again later'});

                }
                console.log("done all getting subids");

            }



        }
    }
    else {

        console.log("errrrorrrr");

        procesdsCampfd();
    }


    function procesdsCampfd() {


        console.log("obj :: "+obj);

        var nlmId1 = parseInt(req.body.nlmId);
        var userId1 = parseInt(req.body.userId);
        var pushVol = parseInt(req.body.tempVol);

        var usnlmsvolume = 0;
        if(obj.tIds!=undefined)
        {
            usnlmsvolume=0;
        }
        else {
            usnlmsvolume=pushVol;
        }
        var date1 = new Date().toISOString().substr(0, 10);
        var daystart = Math.round((new Date(date1 + " 00:00:00")).getTime() / 1000)
        var url = apiurl + "api/userNLMs/update?nlmId=" + nlmId1 + "&userId=" + userId1 + "&date=" + daystart;

        console.log("pushVol  : ", pushVol);
        console.log("pushVol   :   " + url);
        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
            res.send('logout');
        } else {
            request({
                url: url,
                method: "POST",
                json: true,
                body: {pushVol: usnlmsvolume}
            }, function (err, response, body) {
                if (err) {
                    console.log(err.stack);
                    res.send({'error':'Problem in sending Mail,plz try again later'});
                } else {
                    console.log('pushVol result');
                    console.log(response.data)
                    if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                        res.send({'error':'Problem in sending Mail,plz try again later'});

                        console.log(JSON.stringify(response.body));
                    }
                    else if (response.statusCode === 200 || response.statusCode === 201) {
                        console.log('updation success pushVol ' + response.statusCode + "  res.data   :  " + response.data);


                        var url = apiurl + "api/newsletters/create";

                        console.log("newsCreate  : ", obj, " totalVolNew  : ", parseInt(req.body.tempVol));

                        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
                            res.send('logout');
                        } else {
                            request({
                                url: url,
                                method: "POST",
                                json: true,
                                body: obj
                            }, function (err, response, body) {
                                if (err) {
                                    res.send({'error':'Problem in sending Mail,plz try again later'});
                                    console.log(err.stack);
                                } else {
                                    if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                        res.send({'error':'Problem in sending Mail,plz try again later'});

                                        console.log('  error ' + response.statusCode + ' error message  ' + JSON.stringify(response));
                                    }
                                    else if (response.statusCode === 200 || response.statusCode === 201) {

                                        console.log("success newscreate  ", response.statusCode);
                                        console.log("response.data  ", JSON.stringify(response.body.data));
                                        var nlId = response.body.data.id;
                                        var sentOn = parseInt(Math.floor(new Date().getTime() / 1000));

                                        var newobj = {
                                            "campId": parseInt(req.body.campId),
                                            "nlmId": parseInt(req.body.nlmId),
                                            "nlId": nlId,
                                            "userId": parseInt(req.body.userId),
                                            "sentOn": sentOn,
                                            "totalVol": pushVol
                                        };

                                        console.log("newobj   :  ", newobj);
                                        request({
                                            url: apiurl + "api/statsNl/create",
                                            method: "POST",
                                            json: true,
                                            body: newobj
                                        }, function (err, response, body) {
                                            if (err) {
                                                //console.log(err.stack);
                                                res.send({'error':'Problem in sending Mail,plz try again later'});
                                            } else {

                                                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                                    res.send({'error':'Problem in sending Mail,plz try again later'});

                                                    console.log("statsNI   :" + response.statusCode);
                                                    console.log(response.body);
                                                }
                                                else if (response.statusCode === 200 || response.statusCode === 201) {
                                                    var domainWise = req.body.domainWise;

                                                    console.log("domainWise  :  "+JSON.stringify(domainWise));
                                                    if (domainWise.length > 0) {
                                                        var dd = 0;
                                                        domainsinsert();

                                                        function domainsinsert() {
                                                            if (dd < domainWise.length) {

                                                                var dId = domainWise[dd].id;

                                                                var objdomain = {
                                                                    campId: parseInt(req.body.campId),
                                                                    nlmId: parseInt(req.body.nlmId),
                                                                    nlId: nlId,
                                                                    userId: parseInt(req.body.userId),
                                                                    dId: parseInt(dId),
                                                                    sentOn: sentOn,
                                                                    totalVol: pushVol,
                                                                    status:0
                                                                };

                                                                console.log("inserDomainstats obj  :   ", objdomain, "   domainId   :  ", dId,"  domainWise.length  : ",domainWise.length);
                                                                request({
                                                                    url: apiurl + "api/StatsDomains/create",
                                                                    method: "POST",
                                                                    json: true,
                                                                    body: objdomain
                                                                }, function (err, response, body) {
                                                                    if (err) {
                                                                        res.send({'error':'Problem in sending Mail,plz try again later'});

                                                                        console.log(err.stack);

                                                                    } else {
                                                                        if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                                                            res.send({'error':'Problem in sending Mail,plz try again later'});
                                                                            console.log('  error ' + response.statusCode + ' error message  ' + JSON.stringify(response));
                                                                        }
                                                                        else if (response.statusCode === 200 || response.statusCode === 201) {
                                                                            var filterObj = {'fields': ['id']};
                                                                            console.log("success StatsDomains  ", dId);
                                                                            request({
                                                                                url: apiurl + "api/ips/domain/" + dId + "?filter=" + JSON.stringify(filterObj),
                                                                                method: "GET"
                                                                            }, function (err, response, body) {
                                                                                if (err) {
                                                                                    res.send({'error':'Problem in sending Mail,plz try again later'});
                                                                                    console.log(err.stack);
                                                                                } else {

                                                                                    if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                                                                        res.send({'error':'Problem in sending Mail,plz try again later'});
                                                                                        console.log("smtpID   :" + response.statusCode);
                                                                                    }
                                                                                    else if (response.statusCode === 200 || response.statusCode === 201) {

                                                                                        console.log("HHHH :: " + JSON.parse(response.body))
                                                                                        //console.log("response stmpId :  ",response.body);
                                                                                        // console.log("response stmpId :  ",typeof response.body);
                                                                                        console.log("response stmpId :  ", JSON.parse(response.body).data);
                                                                                        var data = JSON.parse(response.body).data;

                                                                                        // console.log("response stmpId :  ",typeof response.body.data);
                                                                                        if (data.length > 0) {


                                                                                            var dfx = 0;
                                                                                            insertsntpids();
                                                                                            function insertsntpids() {

                                                                                                if (dfx < data.length) {

                                                                                                    var smtpId = data[dfx].id;

                                                                                                    var smtpObject = objdomain;
                                                                                                    smtpObject["ipId"] = smtpId;
                                                                                                    request({
                                                                                                        url: apiurl + "api/StatsIps/create",
                                                                                                        method: "POST",
                                                                                                        json: true,
                                                                                                        body: smtpObject
                                                                                                    }, function (err, response, body) {
                                                                                                        if (err) {
                                                                                                            res.send({'error':'Problem in sending Mail,plz try again later'});
                                                                                                            console.log(err.stack);

                                                                                                        } else {
                                                                                                            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                                                                                                res.send({'error':'Problem in sending Mail,plz try again later'});
                                                                                                                console.log('  error ' + response.statusCode + ' error message  ' + JSON.stringify(response));
                                                                                                            }
                                                                                                            else if (response.statusCode === 200 || response.statusCode === 201) {
                                                                                                                dfx++;
                                                                                                                setImmediate(insertsntpids);
                                                                                                                console.log("inserted smtp callls");
                                                                                                            } else {
                                                                                                                res.send({'error':'Problem in sending Mail,plz try again later'});
                                                                                                                console.log('there is a problem in statsDOMAIN');
                                                                                                            }
                                                                                                        }
                                                                                                    });
                                                                                                }
                                                                                                else {
                                                                                                    dd++;
                                                                                                    setImmediate(domainsinsert);
                                                                                                }

                                                                                            }
                                                                                        }
                                                                                        else {
                                                                                            res.send({'error':'Problem in sending Mail,plz try again later'});
                                                                                            console.log("no smtpis present");
                                                                                        }
                                                                                    }
                                                                                }
                                                                            });
                                                                        } else {
                                                                            res.send({'error':'Problem in sending Mail,plz try again later'});
                                                                            console.log('there is a problem in statsDOMAIN');
                                                                        }
                                                                    }
                                                                });

                                                            }
                                                            else {

                                                                console.log("stats insert.......");
                                                                statsInsert(req.body.creative, req.body.campId, req.body.nlmId, nlId, req.body.userId, sentOn, res);

                                                            }

                                                        }
                                                    }
                                                } else {
                                                    res.send({'error':'Problem in sending Mail,plz try again later'});
                                                    console.log("response  :  ", response.body);

                                                }
                                            }
                                        });

                                    } else {
                                        res.send({'error':'Problem in sending Mail,plz try again later'});
                                        console.log('there is a problem in emailopen deviceinfo');
                                    }
                                }
                            });
                        }

                    } else {
                        res.send({'error':'Problem in sending Mail,plz try again later'});
                        res.send('unknown error from API : ' + response.statusCode);
                    }
                }
            });
        }
    }





    function statsInsert(Temphtmlbody,campId,nlmId,nlId,userId,sentOn,res)
    {
        var totalVolNew=parseInt(req.body.tempVol);
        console.log("statsInsert    :    ",Temphtmlbody,"  campId  ",campId,"  nlmId  ",nlmId,"  nlId  ",nlId," userId ",userId,"sentOn ",sentOn);
        // console.log("res   :  ",res);
        var Mlinksa = [];
        var xc=0;
        function parselinks(callback) {
            var parsedHTML = cheerio.load(Temphtmlbody)
            parsedHTML('a').map(function (x, link) {
                console.log("link :"+link);
                var href = cheerio(link).attr('href');
                console.log("href :"+href);
                Mlinksa.push(href);
            });
            parsedHTML=null;
            return callback(Mlinksa);
        }

        parselinks(function (Mlinksa) {
            parselinksarea(Mlinksa, insertnlIdlinks);
        });

        function parselinksarea(Mlinksa, callback) {

            var parsedHTML = cheerio.load(Temphtmlbody)
            parsedHTML('area').map(function (x, link) {
                var href = cheerio(link).attr('href')
                //  console.log(href);
                Mlinksa.push(href);
            });
            parsedHTML=null;
            return callback(Mlinksa);

        }




        function insertnlIdlinks() {
            console.log("xc :: " + xc + " Mlinksa.length ::  " + Mlinksa.length)
            console.log("mlinks :: " + xc < Mlinksa.length)

            if (xc < Mlinksa.length) {
                console.log("aaaaaaaaaa 2916    ");
                var link = Mlinksa[xc];
                if(typeof link != 'undefined'){
                console.log("aaaaaaaaaa link" + link);
                var linkobj = {
                    "link": link,
                    "campId": campId,
                    "nlmId": nlmId,
                    "nlId": nlId,
                    "userId": userId,
                    "type": 0,
                    "sentOn": sentOn
                };
                console.log("linkobj :: " + JSON.stringify(linkobj));
                request({
                    url: apiurl + "api/StatsLinkWise/create",
                    method: "POST",
                    json: true,
                    body: linkobj
                }, function (err, response, body) {
                    if (err) {
                        res.send({'error': 'Problem in sending Mail,plz try again later'});
                        console.log(err.stack);

                    } else {
                        if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                            res.send({'error': 'Problem in sending Mail,plz try again later'});
                            console.log('links error  ' + response.statusCode);
                            console.log('links error all ' + JSON.stringify(response.body));
                        }
                        else if (response.statusCode === 200 || response.statusCode === 201) {
                            console.log("dome inserted linksss");
                            xc++;
                            setImmediate(insertnlIdlinks);

                        } else {
                            res.send({'error': 'Problem in sending Mail,plz try again later'});
                            console.log('there is a problem in emailopen deviceinfo');
                        }
                    }
                });

            }else {
                console.log("link skipped due to undefined 2959");
                    xc++;
                    setImmediate(insertnlIdlinks);
            }
        }
            else {

                request({
                    url: apiurl+"api/newsletters/update/"+nlId,
                    method: "POST",
                    json: true,
                    body: {status:0}
                }, function (err, response, body) {
                    if (err) {
                        console.log(err.stack);
                        res.send({'error':'Problem in sending Mail,plz try again later'});
                    } else {
                        console.log('newsletters/update result')
                        console.log(response.body.data)
                        if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                            res.send({'error':'Problem in sending Mail,plz try again later'});
                            console.log('newsletters/update updation failed ::: ' + response.statusCode);
                        }
                        else if (response.statusCode === 200 || response.statusCode === 201) {


                            var msg=notiObj.newsName+"  "+notiObj.pushVol+" picked by "+notiObj.agentName;
                            console.log("msg :: "+msg);

                            var objAlert = {
                                "msg": msg,
                                "desc": msg,
                                "src": msg,
                                "type": "alert",
                                "userIds": [notiObj.userRelId],
                                "port": 2008,
                                "ctdOn":parseInt(Math.floor(new Date().getTime() / 1000))
                            }

                            //console.log("objAlert for today  : "+JSON.stringify(objAlert)+"  userRelId : "+notiObj.userRelId);
                            desktopNotifiction(objAlert);


                            console.log('updation success newsletters/update ' + response.statusCode+"  res.data   :  "+response.body.data);
                            res.send({'error':'campaign sent successfully !'});
                            console.log("done inserting all logs.....");
                        } else {
                            res.send({'error':'Problem in sending Mail,plz try again later'});
                        }
                    }
                });


                //res.send("campaign sent successfully....");
                //console.log("done inserting all logs.....");

            }

        }
    }

    function inserDomainstats(obj,domainId)
    {

    }

});


router.get('/allDomainDetail', function (req, res) {
    var id = req.cookies.userid;

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {

        request({
            url: apiurl+'api/domains/',
            method: 'GET'
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error getEdomainById while accessing API');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                    console.log('step line:3040 getEdomainById get error ' + response.statusCode);
                    console.log(JSON.stringify(response.body));
                    res.send(response.body);
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {

                res.send(response.body);

                } else {
                    res.send('unknown error line:3054 from API getEdomainById : ' + response.statusCode);
                }
            }
        });

    }
});


router.post('/addesp', function (req, res) {
    var id = req.cookies.userid;
    var DataEsp=req.body.dataEsp;
    var NameCount={"name":req.body.nameCount};
    console.log(DataEsp+"----"+JSON.stringify(NameCount));
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var url1=apiurl+"api/domains/count?where="+JSON.stringify(NameCount);
        var url2=apiurl+"api/domains/create";
        console.log(url1+"-"+url2);
        request({
            url: url1,
            method: "GET"
        }, function (err, response, body) {
            var result=JSON.parse(response.body);
            //console.log("RESPONSE--------------"+JSON.stringify(result.data));

            //console.log("response.body.data--------------"+JSON.stringify(result.data));
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url1});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});

                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    if(JSON.stringify(result.data) != undefined){

                        var data_f=result.data.count;
                        console.log(result.data.count);
                        if(result.data.count==0) {
                            request({
                                url: url2,
                                method: "POST",
                                json: true,
                                body:DataEsp

                            }, function (err, response, body) {
                                console.log(JSON.stringify(response.body));
                                if (err) {
                                    console.log(err.stack);
                                    res.send('Error while accessing API ');
                                } else {
                                    if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                                        console.log('error ::: ' + response.statusCode);
                                        if (response.statusCode === 404) {
                                            console.log(response.body.error.message);
                                            res.send({"error": "URL Not Found " + url2});
                                        } else {
                                            console.log(response.body.error.message)
                                            res.send({"error": response.body.error.message});

                                        }

                                    }
                                    else if (response.statusCode === 200 || response.statusCode === 201) {
                                        if(response.body.data != undefined){
                                            var data_s=response.body.data;
                                            var data_fands=data_f+"^"+data_s;
                                            res.send({"success": data_fands});
                                        }
                                        else{
                                            res.send({"error":response.body.data});
                                        }


                                    } else {
                                        res.send({"error":response.body.data});
                                    }

                                }
                            });
                        }else if(result.data.count==1){
                            res.send({"success": result.data.count});
                        }

                    }
                    else{
                        res.send({"error": "API error"});
                    }


                } else {
                    res.send({"error": response.body.data});
                }

            }
        });

    }


});






router.post('/checkDomain', function (req, res) {

    var id = req.cookies.userid;
    var datetime = parseInt(Math.floor(new Date(req.body.sentOn).getTime() / 1000));
    var query={"where":{"userId":req.body.userId,"nlmId":req.body.nlmId}};
    var url =apiurl+"api/StatsDomains?filter="+JSON.stringify(query);
    console.log(url);
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {

        request({
            url: url,
            method: "GET",
            json: true
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send({"error": 'failure'});
            } else {
                console.log('checkDomain result')
                //console.log(response.data)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    console.log(JSON.parse(response.body.toString()).error);
                    console.log(JSON.parse(response.body.toString()).error.message);
                    console.log('updation failed ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }
                }
                else if (response.statusCode === 200 || response.statusCode === 201)
                {
                    console.log('checkDomain success ::: ' + response.statusCode+response.body.data);
                    res.send(response.body.data);
                }
                else
                {
                    res.send('unknown error from API : ' + response.statusCode);
                }
            }
        });

    }

});
/*router.post('/checkDomain', function (req, res) {
 var id = req.cookies.userid;
 var datetime = parseInt(Math.floor(new Date(req.body.sentOn).getTime() / 1000));
 var query={"where":{"userId":req.body.userId,"nlmId":req.body.nlmId,"sentOn":datetime}};
 var url =apiurl+"api/StatsDomains?filter="+JSON.stringify(query);
 console.log("checkDomain   :   "+url);
 if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
 res.send('logout');
 } else {

 request({
 url: url,
 method: "GET",
 json: true,
 body: obj
 }, function (err, response, body) {
 if (err) {
 console.log(err.stack);
 res.send({"error": 'failure'});
 } else {
 console.log('checkDomain result')
 console.log(response.data)
 if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
 {
 console.log(JSON.parse(response.body.toString()).error);
 console.log(JSON.parse(response.body.toString()).error.message);
 console.log('checkDomain updation failed ::: ' + response.statusCode);
 }
 else if (response.statusCode === 200 || response.statusCode === 201)
 {
 console.log('updation success checkDomain ' + response.statusCode+"  res.data   :  "+response.data);
 res.send(response.data);
 } else
 {
 res.send('unknown error from API : ' + response.statusCode);
 }
 }
 });

 }

 });*/

router.post('/sendTestMail', function (req, res) {
    var id = req.cookies.userid;
    var url =apiurl+"api/TestMails/create";
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        console.log('/sendTestMail');

        console.log(req.body);
        console.log('success');
        res.send({"success": "success"});
        var obj = {
            "nlmId": parseInt(req.body.nlmId),
            "campId": parseInt(req.body.campId),
            "userId": parseInt(req.body.userId),
            "SN": req.body.SN,
            "SL": req.body.SL,
            "creative": req.body.creative,
            "domains": req.body.domains,
            "emails": req.body.emails
        }

        console.log("obj sendTestMail  ",obj);
        request({
            url: url,
            method: "POST",
            json: true,
            body: obj
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send({"error": 'failure'});
            } else {
                console.log('sendTestMail result')
                console.log(response.data)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log(JSON.parse(response.body.toString()).error);
                    console.log(JSON.parse(response.body.toString()).error.message);
                    console.log('sendTestMail updation failed ::: ' + response.statusCode);
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    console.log('updation success sendTestMail ' + response.statusCode+"  res.data   :  "+response.data);
                    res.send(response.data);
                } else {
                    res.send('unknown error from API : ' + response.statusCode);
                }
            }
        });
    }

});

router.post('/allDomainsR', function (req, res) {
    var id = req.cookies.userid;
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var filterObj = {"fields": ["id","name"]};
        var url = apiurl+"api/domains?filter=" + JSON.stringify(filterObj);
        console.log(url);
        request({
            url: url,
            method: "GET",
            json: true
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send({"error": 'failure'});
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    console.log('updation success ::: ' + response.statusCode);
                    res.send(response.body.data);
                } else {
                    res.send('unknown error from API : ' + response.statusCode);
                }
            }
        });

    }

});


router.post('/getNLIDR', function (req, res) {
    var id = req.cookies.userid;
    var SN = req.body.SN;
    var SL = req.body.SL;
    var creative = req.body.creative;

    console.log("SN : "+SN+" SL : "+SL+" creative : "+creative);
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var filterObj = {"where":{"cType":"retarget"}};
        var url = apiurl+"api/newsletters/ref/"+req.body.newsId+"?filter=" + JSON.stringify(filterObj);
        console.log(url);
        request({
            url: url,
            method: "GET",
            json: true
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send({"error": 'failure'});
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    console.log('updation success innerEDIT::: ' + response.statusCode);
                    //res.send(response.body.data);
                    console.log("response.body.data innerEDIT 3346  :  "+JSON.stringify(response.body.data));
                    var tempObj = JSON.stringify(response.body.data[0]);
                    console.log(JSON.parse(tempObj).id);

                    var nlId = JSON.parse(tempObj).id;
                    var url = apiurl+"api/newsletters/update/"+parseInt(nlId);
                    var result = [];

                        console.log('requesting  url update 3355 : '+url);
                        var objNL = {"SN":SN[0],"SL":SL[0],"creative":creative};
                        console.log(" objNL 3360 : "+JSON.stringify(objNL));
                        request({
                            url: url,
                            method: "post",
                            json: true,
                            body:objNL
                        }, function (err, response, body) {
                            if (err) {
                                console.log(err.stack);
                                res.send('Error while accessing API @nlUpdate');
                            } else {
                                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                                {
                                    if (response.statusCode === 404) {
                                        console.log(" nlUpdate innerEDIT error : "+response.statusCode);
                                        console.log(response.body.error.message)
                                        res.send({"error": "nlUpdate innerEDIT Not Found " + url});
                                    } else {
                                        console.log(response.body.error.message)
                                        res.send({"error nlUpdate innerEDIT ": response.body.error.message});
                                    }

                                }
                                else if (response.statusCode === 200 || response.statusCode === 201) {
                                    // console.log('nlUpdate length::: ' + response.body.data.length);
                                    console.log("nlUpdate response innerEDIT :::"+JSON.stringify(response.body.data));
                                    result=response.body.data;
                                    console.log("success nlUpdate innerEDIT : "+result);
                                    res.send(result);
                                } else {
                                    console.log("api error nlUpdate" );
                                    res.send({"error nlUpdate innerEDIT": "API Error"});
                                }
                            }
                        });




                } else {
                    res.send('unknown error from API : ' + response.statusCode);
                }
            }
        });

    }

});



router.post('/getNLOnNlm', function (req, res) {
    var id = req.cookies.userid;
    var SN = req.body.SN;
    var SL = req.body.SL;
    var creative = req.body.creative;

    console.log("SN : "+SN+" SL : "+SL+" creative : "+creative);
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var filterObj = {"where":{"cType":"retarget"}};
        var url = apiurl+"api/newsletters/ref/"+req.body.newsId+"?filter=" + JSON.stringify(filterObj);
        console.log(url);
        request({
            url: url,
            method: "GET",
            json: true
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send({"error": 'failure'});
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    console.log('updation success innerEDIT::: ' + response.statusCode);
                    //res.send(response.body.data);
                    console.log("response.body.data innerEDIT 3346  :  "+JSON.stringify(response.body.data));
                    var tempObj = JSON.stringify(response.body.data[0]);
                    console.log(JSON.parse(tempObj).id);

                    var nlId = JSON.parse(tempObj).id;
                    var url = apiurl+"api/newsletters/update/"+parseInt(nlId);
                    var result = [];

                    console.log('requesting  url update 3355 : '+url);
                    var objNL = {"SN":SN[0],"SL":SL[0],"creative":creative};
                    console.log(" objNL 3360 : "+JSON.stringify(objNL));
                    request({
                        url: url,
                        method: "post",
                        json: true,
                        body:objNL
                    }, function (err, response, body) {
                        if (err) {
                            console.log(err.stack);
                            res.send('Error while accessing API @nlUpdate');
                        } else {
                            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                            {
                                if (response.statusCode === 404) {
                                    console.log(" nlUpdate innerEDIT error : "+response.statusCode);
                                    console.log(response.body.error.message)
                                    res.send({"error": "nlUpdate innerEDIT Not Found " + url});
                                } else {
                                    console.log(response.body.error.message)
                                    res.send({"error nlUpdate innerEDIT ": response.body.error.message});
                                }

                            }
                            else if (response.statusCode === 200 || response.statusCode === 201) {
                                // console.log('nlUpdate length::: ' + response.body.data.length);
                                console.log("nlUpdate response innerEDIT :::"+JSON.stringify(response.body.data));
                                result=response.body.data;
                                console.log("success nlUpdate innerEDIT : "+result);
                                res.send(result);
                            } else {
                                console.log("api error nlUpdate" );
                                res.send({"error nlUpdate innerEDIT": "API Error"});
                            }
                        }
                    });




                } else {
                    res.send('unknown error from API : ' + response.statusCode);
                }
            }
        });

    }

});

router.post('/allotToMe', function (req, res) {
    var id = req.cookies.userid;
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var obj = req.body;
        console.log(obj);
        var userid = parseInt(obj.id);
        var url = apiurl+"api/userNLMs/addNlm";
        console.log(url);
        console.log(obj);
        request({
            url: url,
            method: "POST",
            json: true,
            body: obj
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send({"error": 'failure'});
            } else {
                console.log('allotTome result')
                console.log(response.data)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log(JSON.parse(response.body.toString()).error);
                    console.log(JSON.parse(response.body.toString()).error.message);
                    console.log('updation failed ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    console.log('updation success ::: ' + response.statusCode);
                    res.send({"success": 'Updated Succesfully'});
                } else {
                    res.send('unknown error from API : ' + response.statusCode);
                }
            }
        });

    }

});


function getTime(UNIX_timestamp) {
    var a = new Date(UNIX_timestamp * 1000);
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var year = a.getFullYear();
    var month = months[a.getMonth()];
    var date = a.getDate();
    var hour = a.getHours();
    var min = a.getMinutes();
    var sec = a.getSeconds();
    var time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec;
    return time;
}









router.post('/getMenu', function(req, res) {


    var id = req.cookies.userid;
    request({
        url: apiurl+"api/users/permission/main/"+id,
        method: "GET"
    }, function (err, response, body) {
        if (err) {
            res.send('failure');
        } else {

            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log(JSON.parse(response.body.toString()).error);
                console.log(JSON.parse(response.body.toString()).error.message);
                res.send(response.body.error);
            }else if (response.statusCode === 200 || response.statusCode === 201) {
                var obj=JSON.parse(response.body);
                console.log(obj.data);
                res.send(obj.data);
            }else {
                res.send('unknown error from API : ' + response.statusCode);
            }

        }
    });



});

//code to addleftMenu

router.post('/leftMenu/:menuType', function(req, res) {

    //console.log("leftmenu : "+req.params.menuType);
  /*

   var url="http://tp.app.com/user/getMenuTYPE/TYPE=menuType";
   console.log("menuTYpe  :  ",req.params.menuType);


   var menuHierarchy = [{ name: "Dash Board", count: 0,url:'#/dashboard'}, { name: "View Main", count: 2,url:'#/viewMain'},{name:"View Sub", count:3,url:'#/subMenu'},
   { name: "Reports", count: 4,url:'#/reports'}, { name: "Draft", count: 10,url:'#/drafts'},{name:"Stopped", count:0,url:'#/stopped'},
   { name: "Archieve", count: 10 ,url:'#/archieve'},{name:"Replys", count:20,url:'#/replys'}];

   res.send(menuHierarchy);
   */

    var id = req.cookies.userid;
    console.log("apiurl :: "+apiurl+" id :: "+id+" menuType :: "+req.params.menuType);
    request({
        url: apiurl+"api/users/permission/sub/"+id+"?mainId="+req.params.menuType,
        method: "GET"

    }, function (err, response, body) {
        if (err) {
            //console.log("err.stack");
            res.send('failure');
        } else {
            //console.log('top mENU success ::: '+response.statusCode);

            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
            {
                //console.log('TOPMENU failed ::: ' + response.statusCode);
                //console.log(response);
              /* console.log(JSON.parse(response.body.toString()).error);
               console.log(JSON.parse(response.body.toString()).error.message);*/
                var obj = JSON.parse(response.body);
                console.log(response.body.error);
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                //console.log('TOPMENU success ::: ' + response.statusCode);
                //console.log("res body  : ",response.body);
                var obj = JSON.parse(response.body);
                //console.log("objdata : ",obj.data);
                res.send(obj.data);
            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }

        }


    });
});


//code to addMenu
router.post('/addMenu/:newMenu', function(req, res) {

    //console.log("addMEnu node : ",req.params.newMenu);

  /*
   var url="http://tp.app.com/user/create/menu="+req.params.newMenu;

   //if executed successfully
   var urlGEt="getURl"
   var menuData = [{ name: "Mailing", id: 1 }, { name: "Data", id: 2 },{name:"Domain", id:3}];
   if(req.params.newMenu)
   {
   var menuData = [{ name: "Mailing", id: 1 }, { name: "Data", id: 2 },{name:"Domain", id:3},{name:req.params.newMenu,id:4}];
   }

   res.send(menuData);*/
    var obj = {
        "name":req.params.newMenu
    }
    var credentials = {"credentials": obj}
    //console.log("menu credentials : ",credentials);
    request({
        url: apiurl+"api/permissions/create/main",

        method: "POST",
        json: true,   // <--Very important!!!
        body: obj
    }, function (err, response, body) {
        if (err) {
            //console.log(err.stack);
        } else {
            //console.log('Created success ::: '+response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                //console.log('MENU INSERTED failed ::: ' + response.statusCode);
                console.log(response.body.error.message)
              /*console.log(JSON.parse(response.body.toString()).error);
               console.log(JSON.parse(response.body.toString()).error.message);*/
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                //console.log('createdMenu success ::: ' + response.statusCode);
                res.send('success');
            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }
        }
    });

});

// edit Main

router.post('/editMenu',function(req,res){
    //console.log("inside req ",req.params.menuOb);
    //console.log(req.body);
    //console.log(JSON.stringify(req.params, null, 5));
// console.log(req.params.menuOb);
    var jsonObject = req.body.menuId;
    //console.log("inside router jsonObject ",jsonObject);

    var menuId = jsonObject.id;
    var menuName = jsonObject.name;
    var obj ={
        name: menuName
    }
    //console.log("obj  : ",obj);

    request({
        url: apiurl+"api/permissions/update/main/"+menuId,
        method: "POST",
        json: true,   // <--Very important!!!
        body: obj
    }, function (err, response, body) {
        if (err) {
            //console.log(err.stack);
            res.send('failure');
        } else {
            //console.log('top mENU success ::: '+response.statusCode);

            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                //console.log('TOPMENU failed ::: ' + response.statusCode);
                // console.log(response.body.error.message)
                console.log(JSON.parse(response.body.toString()).error);
                console.log(JSON.parse(response.body.toString()).error.message);
                res.send(response.body.error.message);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                // console.log('TOPMENU success ::: ' + response.statusCode);
                //console.log(response.body);
                res.send(response.body);

            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }

        }
    });



});

//delete Main

router.post('/deleteMenu/:menuId',function(req,res) {

    //console.log("inside req ",req.params.menuId);

    var menuId = req.params.menuId;
    request({
        url: apiurl+"api/permissions/main/"+menuId,
        method: "DELETE"
    }, function (err, response, body) {
        if (err) {

            res.send('failure');
        } else {


            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log(JSON.parse(response.body.toString()).error);
                console.log(JSON.parse(response.body.toString()).error.message);
                res.send(response.body.error.message);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                // console.log('TOPMENU success ::: ' + response.statusCode);
                //console.log(response.body);
                res.send(response.body);

            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }

        }
    });

});


//code to addSUb
router.post('/addSub', function(req, res) {

    var url =req.body.newSub.toLowerCase();
    console.log("addSub got called  :",req.body.menuId);
    var obj = {
        "name":req.body.newSub,
        "mainId":req.body.menuId,
        "url":"/users/"+url,
        "order":req.body.order
    }

    console.log("menu obj : ",obj);
    request({
        url: apiurl+"api/permissions/create/sub",
        method: "POST",
        json: true,   // <--Very important!!!
        body: obj
    }, function (err, response, body) {
        if (err) {
            //console.log(err.stack);
        } else {
            console.log('CreatedSub success ::: '+response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('subMenu INSERTED failed ::: ' + response.statusCode);
                console.log(response.body.error.message)

                res.send(response.body.error.message);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                //console.log('subMenu success ::: ' + response.statusCode);
                res.send('success');
            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }
        }
    });


});


//edit sub


router.post('/editSub',function(req,res){
    //console.log("inside req ",req.params.menuOb);
    //console.log(req.body);
    //console.log(JSON.stringify(req.params, null, 5));
// console.log(req.params.menuOb);
    var jsonObject = req.body.subObj;
    //console.log("inside router jsonObject ",jsonObject);

    var subId = jsonObject.id;
    var obj = jsonObject;
    //console.log("obj  : ",obj);

    request({
        url: apiurl+"api/permissions/update/sub/"+subId,
        method: "POST",
        json: true,   // <--Very important!!!
        body: obj
    }, function (err, response, body) {
        if (err) {
            //console.log(err.stack);
            res.send('failure');
        } else {
            //console.log('top mENU success ::: '+response.statusCode);

            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                //console.log('TOPMENU failed ::: ' + response.statusCode);
                // console.log(response.body.error.message)
                console.log(JSON.parse(response.body.toString()).error);
                console.log(JSON.parse(response.body.toString()).error.message);
                res.send(response.body.error.message);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                // console.log('TOPMENU success ::: ' + response.statusCode);
                //console.log(response.body);
                res.send(response.body);

            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }

        }
    });

});

//delete Sub

router.post('/deleteSub',function(req,res) {

    var subId = req.body.subId;
    //console.log("inside req  :  ",subId);

    request({
        url: apiurl+'/api/permissions/sub/'+subId,
        method: "DELETE",
        data:subId
    }, function (err, response, body) {
        if (err) {

            res.send('failure');
        } else {


            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {

                res.send(response.body.error.message);
                console.log(JSON.parse(response.body.toString()).error);
                console.log(JSON.parse(response.body.toString()).error.message);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                // console.log('TOPMENU success ::: ' + response.statusCode);
                //console.log(response.body);
                res.send(response.body);

            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }

        }
    });

});

//code to get Create Campaign


router.post('/createCamp', function(req, res) {

    console.log("Add Campaign  ");


    var obj = {
        "name": req.body.camp,
        "cBy": parseInt(req.body.userId)
    }

    console.log(obj);
    request({
        url: apiurl+"api/campaigns/create",
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            console.log('else campaign error : '+response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('Campaign error ' + response.statusCode);
                console.log(response.body.error.message);

                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('Campaign Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }
        }
    });

});

// edit Camp
router.post('/editCamp',function(req,res){

    var obj = {
        "name": req.body.campName,"cBy": parseInt(req.body.userId)
    };
    var campId = parseInt(req.body.campId);

    console.log(obj, "  ",campId);
    request({
        url: apiurl+"api/campaigns/update/"+campId,
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            console.log('else campaignEDIT error : '+response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('CampaignEDIT error ' + response.statusCode);
                console.log(response.body.error.message);
              /*        console.log(JSON.parse(response.body.toString()).error);
               console.log(JSON.parse(response.body.toString()).error.message);*/
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('CampaignEDIT Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API EDIT : ' + response.statusCode);
            }
        }
    });


})


//GET Drafts

router.post('/drafts',function(req,res){

    var campId = req.params.campId;
    console.log("drafts  : ");
    request({

        method:'GET',
        url:apiurl+'api/nlm/draft'

    },function(error,response,then){
        if(error)
        {
            console.log(error.stack);
        }
        else{
            console.log("else drafts response");
            if(response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500){
                console.log('drafts error ' + response.statusCode);
                console.log(response.body);
              /*     console.log(JSON.parse(response.body.toString()).error);
               console.log(JSON.parse(response.body.toString()).error.message);*/
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201){
                console.log('Getting drafts : ');
                console.log(response.body);
                res.send(response.body);
            }
            else
            {
                res.send('unknown error from drafts API  : ' + response.statusCode);
            }
        }

    })

})



// GET campaign


router.post('/getStep1/:campId',function(req,res){

    var campId = req.params.campId;
    console.log("getStep1  : "+apiurl+'api/campaigns/'+campId);
    request({

        method:'GET',
        url:apiurl+'api/campaigns/'+campId

    },function(error,response,then){
        if(error)
        {
            console.log(error.stack);
        }
        else{
            console.log("else response");
            if(response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500){
                console.log('Campaign error ' + response.statusCode);
                console.log(response.body);
              /*     console.log(JSON.parse(response.body.toString()).error);
               console.log(JSON.parse(response.body.toString()).error.message);*/
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201){
                console.log('Getting campaign : ');
                console.log(response.body);
                res.send(response.body);
            }
            else
            {
                res.send('unknown error from API  : ' + response.statusCode);
            }
        }

    })

})

// GET NEWSLETTER
router.post('/getStep2/:newsId',function(req,res){

    var newsId = req.params.newsId;
    request({

        method:'GET',
        url:apiurl+'api/nlm/'+newsId

    },function(error,response,then){
        if(error)
        {
            console.log(error.stack);
        }
        else{
            console.log("else response news");
            if(response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500){
                console.log('NEws error STEP2 ' + response.statusCode);
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201){
                console.log('Getting news STEP2: ');
                res.send(response.body);
            }
            else
            {
                res.send('unknown error from API  NEws: ' + response.statusCode);
            }
        }

    })

})


// create newsletter


router.post('/createNews', function(req, res) {

    console.log("Create NEwsletter  ");

    var bodyObj = req.body.news;
    console.log("bodyObj "+JSON.stringify(bodyObj));

    var campId = req.body.campId;
    var cBy = req.body.cBy;

    var startOn= parseInt(req.body.startOn);
    var endOn =parseInt(req.body.endOn);

    if(bodyObj.roi != null || bodyObj.roi!='undefined'){
        var roi = bodyObj.roi;}



    var newsId = parseInt(req.body.newsId);
    var date1 = new Date().toISOString().substr(0, 10);
    var date = new Date(date1+" 00:00:00")
    var unixtimes = date.getTime() / 1000;

    console.log(startOn);
    console.log(endOn);
    console.log(bodyObj.title,"  ",bodyObj.type);
  /*var date = new Date('2016-08-04 00:00:00'.split(' ').join('T'))
   var unixtimes=date.getTime() / 1000;*/
    var obj = {"campId":campId,
        "cBy": cBy,
        "title": bodyObj.title,
        "type": bodyObj.type,
        "startOn": startOn,
        "endOn": endOn,
        "status": -6,
        "cType":"direct",
        "roi": roi,
    }

    console.log(obj);

    request({
        url: apiurl+"api/nlm/create",
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            console.log('else newsletter error : '+response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('Newsletter error ' + response.statusCode);
                console.log(response.body.error.message);
              /*  console.log(JSON.parse(response.body.toString()).error);
               console.log(JSON.parse(response.body.toString()).error.message);*/
               /* res.send({data:response.body.error.details});*/
                res.send({data:response.body.error.message});
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('NewsLetter Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }
        }
    });


});


// edit News
router.post('/editNews',function(req,res){

    console.log(req.body.campId);
    var date = new Date('2016-08-04 00:00:00'.split(' ').join('T'))
    var unixtimes=date.getTime() / 1000;
    var startOn= parseInt(req.body.startOn);
    var endOn =parseInt(req.body.endOn);
    var obj = {
        "creative":'hello',"roi":req.body.roi,"status":-6,"title": req.body.title,"cBy": parseInt(req.body.cBy),"campId":parseInt(req.body.campId),"type":req.body.type,
        "startOn":startOn,"endOn":endOn}

    var newsId = parseInt(req.body.newsId);

    console.log(obj, "  ",newsId);
    request({
        url: apiurl+"api/nlm/update/"+newsId,
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            console.log('else nEWSEDIT error : '+response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('NEWSEDIT error ' + response.statusCode);
                console.log(response.body.error.message);
              /*        console.log(JSON.parse(response.body.toString()).error);
               console.log(JSON.parse(response.body.toString()).error.message);*/
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('nEWSEDIT Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API NEWS : ' + response.statusCode);
            }
        }
    });


})


//UPDATE STEP3

router.post('/updateStep3',function(req,res){

    console.log(req.body.SL);
    var obj = {"SN": req.body.SN,"cBy": parseInt(req.body.cBy),"SL":req.body.SL,"creative":req.body.creative}

    if(req.body.status != '')
    {
        obj.status=parseInt(req.body.status);
    }

    var newsId = parseInt(req.body.newsId);

    console.log(obj, "  ",newsId);
  /*  res.send("success");*/
    request({
        url: apiurl+"api/nlm/update/"+newsId,
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            console.log('step3 nEWSEDIT error : '+response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('step3 NEWSEDIT error ' + response.statusCode);
                console.log(response.body.error)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('step3 nEWSEDIT Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API step3 : ' + response.statusCode);
            }
        }
    });


})

router.post('/updateStep4',function(req,res){



    var obj = {"cBy":req.body.cBy,"tags": req.body.tags,status:-4}



    if(req.body.tBrands != ''){
        obj.tBrands=req.body.tBrands;
    }
    if(req.body.tPR !=''){
        obj.tPR=req.body.tPR;
    }

    console.log("updateStep4 obj  : "+JSON.stringify(obj))
    var newsId = parseInt(req.body.newsId);

    console.log(obj, "  ",newsId);
  /*  res.send("success");*/
    request({
        url: apiurl+"api/nlm/update/"+newsId,
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('step4 NEWSEDIT error ' + response.statusCode);
              /* console.log(JSON.parse(response.body.toString()).error);
               console.log(JSON.parse(response.body.toString()).error.message);*/
                console.log(response.body.error)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('step4 nEWSEDIT Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API step4 : ' + response.statusCode);
            }
        }
    });


})

router.post('/updateStep5',function(req,res){


    var reqObj = {"eDomain":parseInt(req.body.eDomain),"country":parseInt(req.body.countries)}

    if(typeof req.body.gender !="undefined" && parseInt(req.body.gender) !== 0){
        reqObj.gender=parseInt(req.body.gender);
    }
    if(typeof req.body.source !="undefined" && parseInt(req.body.source) !== ''){
        reqObj.source={"srId":parseInt(req.body.source)};
    }
    if(typeof req.body.age.from !="undefined" && req.body.age.from != null  && req.body.age.from != ''){
        if(typeof req.body.age.to !="undefined" && req.body.age.to != null && req.body.age.from != ''){
            var age1={from:parseInt(req.body.age.from),to:parseInt(req.body.age.to)}
            reqObj.age=age1;
        }
    }
    if(typeof req.body.cities !="undefined"){
        if(req.body.cities!=='' && req.body.cities.toString() !== '')
        {
            reqObj.city = req.body.cities;
        }
    }
    if(typeof req.body.catTags !="undefined" && req.body.catTags.toString()!==''){
        reqObj.catTags=req.body.catTags;
    }

    var newsId = parseInt(req.body.newsId);
    var obj = {"status":-3,"targets":reqObj,"dVol":parseInt(req.body.dVol),"cBy":req.body.cBy};
    console.log(obj, "  ",newsId);
  /*  res.send("success");*/
    request({
        url: apiurl+"api/nlm/update/"+newsId,
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('step5 NEWSEDIT error ' + response.statusCode);
              /*       console.log(JSON.parse(response.body.toString()).error);
               console.log(JSON.parse(response.body.toString()).error.message);*/
                console.log(response.body.error)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('step5 nEWSEDIT Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API step5 : ' + response.statusCode);
            }
        }
    });


})


/*router.post('/countSub', function (req, res) {
 var id = req.cookies.userid;
 console.log(req.body);

 var reqObj = {"eDomain":parseInt(req.body.esp),"gender": parseInt(req.body.gender),"countries":req.body.countries,"cities":req.body.cities,"catTags":req.body.catTags}

 var newsId = parseInt(req.body.newsId);
 var obj = {"status":-2,"targets":reqObj,"dVol":parseInt(req.body.dVol),"cBy":req.body.cBy};
 var url = apiurl+"api/subscribers/data/count";
 console.log(url);
 var result = [];

 if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
 console.log('if failed');
 res.send('logout');
 } else {
 console.log('requesting');
 request({
 url: url,
 method: "POST",
 json: true,
 body:reqObj
 }, function (err, response, body) {
 if (err) {
 console.log(err.stack);
 res.send('Error while accessing API @GetMainPermissions');
 } else {
 if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
 if (response.statusCode === 404) {
 console.log(response.body.error.message)
 res.send({"error": "URL Not Found " + url});
 } else {
 console.log(response.body.error.message)
 res.send({"error": response.body.error.message});
 }

 }
 else if (response.statusCode === 200 || response.statusCode === 201) {
 console.log('count body:: ' + JSON.stringify(response.body));
 console.log(response.body.data);
 result=response.body;
 console.log("countSub success"+JSON.stringify(result));
 res.send(result);
 } else {
 console.log("api error" );
 res.send({"error": "API Error"});
 }
 }
 });
 }
 });*/

router.post('/countSub', function (req, res) {
    var id = req.cookies.userid;
    console.log(req.body);
    var reqObj={};

    console.log("reqObj1  :  ",reqObj);

    if(typeof req.body.age !="undefined"){
        if(typeof req.body.age !="undefined"){
            if(req.body.age.from != '' && req.body.age.to != ''){
                var age1={from:parseInt(req.body.age.from),to:parseInt(req.body.age.to)}
                reqObj.age=age1;
            }
        }}

    if(typeof req.body.source !="undefined"){
        if(typeof req.body.source !="undefined"){
            if(req.body.source != ''){

                reqObj.source={"srId":req.body.source};
            }
        }}

    console.log("reqObj 2 :  ",reqObj);

    if(typeof req.body.esp !="undefined"){
        if(req.body.esp != ''){
            reqObj.eDomain=parseInt(req.body.esp);
        }}

    console.log("reqObj3  :  ",reqObj);

    if(typeof req.body.gender !="undefined" && parseInt(req.body.gender) !== 0){
        if(req.body.gender != ''){
            reqObj.gender=parseInt(req.body.gender);
        }}


    console.log("reqObj4  :  ",reqObj);
    if(typeof req.body.countries !="undefined" && req.body.countries != -1){
        if(req.body.countries != ''){
            reqObj.country=parseInt(req.body.countries);}
    }

    console.log("reqObj 5 :  ",reqObj);

    if(typeof req.body.cities !="undefined"){
        if(req.body.cities!=='' && req.body.cities.toString() !== '')
        {
            if(req.body.cities != ''){
                reqObj.city = req.body.cities;
            }}
    }

    console.log("reqObj6  :  ",reqObj);

    if(typeof req.body.catTags !="undefined" && req.body.catTags.toString() !== ''){
        if(req.body.catTags != ''){
            reqObj.catTags=req.body.catTags;
        }}

    console.log("reqObj 7 :  ",reqObj);
    var newsId = parseInt(req.body.newsId);
    var obj = {"status":-3,"targets":reqObj,"dVol":parseInt(req.body.dVol),"cBy":req.body.cBy};

    var url = apiurl+"api/Subscriber/data/count";
    console.log(url);
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "POST",
            json: true,
            body:reqObj
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                console.log("err.stack    :  ",err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    if (response.statusCode === 404) {
                        console.log("response.statusCode === 404  :  ",response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log("response.body.error  400: ",response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    console.log(response.body.count);
                    console.log("response Json  :  "+JSON.stringify(response.body))
                    res.send(response.body);
                } else {
                    console.log("api error" );
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});





router.post('/updateStep6',function(req,res){


    var newsId = parseInt(req.body.newsId);
    var date1 = new Date().toISOString().substr(0, 10);
    var date = new Date(date1+" 00:00:00")
    var unixtimes = date.getTime() / 1000;

    var obj ={ "cBy":req.body.cBy,"status":-2};
    console.log(obj, "  ",newsId);


    request({
        url: apiurl+"api/nlm/update/"+newsId,
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('step6 updateStep6 error ' + response.statusCode);

                console.log(response.body.error)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('step6 updateStep6 Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API step6 updateStep6 : ' + response.statusCode);
            }
        }
    });


})

router.post('/updateNews',function(req,res){


    var newsId = parseInt(req.body.newsId);
    var obj ={ "cBy":req.body.cBy,"dVol":req.body.dVol,"status":-1};
    console.log(obj, " updateNews  ",newsId);

    request({
        url: apiurl+"api/nlm/update/"+newsId,
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {

            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500)
            {
                console.log('step6 updateNews error ' + response.statusCode);
                console.log(response.body.error)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201)
            {
                console.log('step6 updateNews Created  : ');

                request({

                    url: apiurl + "api/nlm/"+newsId,
                    method: "GET",
                    json: true

                }, function (err, resp, body) {
                    if (err)
                    {
                        console.log(err.stack);
                    } else
                    {
                        if (resp.statusCode === 400 || resp.statusCode === 401 || resp.statusCode === 500) {
                            console.log('Requested vol updateNews error ' + resp.statusCode);
                            console.log(resp.body.error)
                        }
                        else if (resp.statusCode === 200 || resp.statusCode === 201)
                        {
                            console.log("inseted succefullyyyy desktop notification");
                            if(resp.body.data!=null)
                            {
                                if(resp.body.data.userRel!=undefined)
                                {
                                    var cbyname=resp.body.data.userRel.name;
                                    var title=resp.body.data.title;

                                    request({

                                        url: apiurl + "api/users",
                                        method: "POST",
                                        json: true

                                    }, function (err, response, body) {
                                        if (err) {
                                            console.log(err.stack);
                                        } else {
                                            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                                console.log('Requested vol updateNews error ' + response.statusCode);

                                                console.log(response.body.error)
                                            }
                                            else if (response.statusCode === 200 || response.statusCode === 201) {
                                                if(response.body.data!=undefined)
                                                {

                                                    var userdata=response.body.data;
                                                    console.log("length of user data :: "+userdata.length);
                                                    var x=0;
                                                    var userids=[];
                                                    getUserids();
                                                    function getUserids()
                                                    {
                                                        if(x<userdata.length)
                                                        {
                                                            userids.push(userdata[x].id);
                                                            x++;
                                                            setImmediate(getUserids);
                                                        }
                                                        else {

                                                            console.log("userids :: "+JSON.stringify(userids));
                                                            var msg=cbyname+" created a campaign "+title;
                                                            console.log("msg :: "+msg);
                                                            var objAlert = {
                                                                "msg": msg,
                                                                "desc": msg,
                                                                "src": msg,
                                                                "type": "alert",
                                                                "userIds": userids,
                                                                "port": 2008,
                                                                "ctdOn":parseInt(Math.floor(new Date().getTime() / 1000))
                                                            }

                                                            desktopNotifiction(objAlert);


                                                        }
                                                    }
                                                }
                                                console.log("inseted succefullyyyy desktop notification");

                                            }
                                        }
                                    });

                                }
                            }
                        }
                    }
                });

                res.send(response.body);
            } else {
                res.send('unknown error from API  updateNews : ' + response.statusCode);
            }
        }
    });


})



function desktopNotifiction(objAlert)
{

    request({

        url: apiurl + "api/notifications/insert",
        method: "POST",
        json: true,
        body: objAlert

    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('Requested vol updateNews error ' + response.statusCode);

                console.log(response.body.error)
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log("inseted succefullyyyy desktop notification");

            }
        }
    });


}





router.post('/updateNewsR',function(req,res){


    var newsId = parseInt(req.body.newsId);
    var obj ={ "cBy":req.body.cBy,
        "dVol":parseInt(req.body.dVol),"status":-1,"reTarget":{"device":parseInt(req.body.device),"domType":req.body.domType,"retType":parseInt(req.body.retType),"resTime":req.body.resTime,countries:req.body.countries,cities:req.body.cities}};
    console.log(obj, " updateNewsR  ",newsId);

    request({
        url: apiurl+"api/nlm/update/"+newsId,
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {

            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500)
            {
                console.log('step6 updateNewsR error ' + response.statusCode);
                console.log(response.body.error)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201)
            {
                var urlAllot = apiurl+"api/userNLMs/addNlm";
                request({
                    url: urlAllot,
                    method: "POST",
                    json: true,
                    body: {"userId":req.body.cBy,"pickVol":parseInt(req.body.dVol),"nlmId":parseInt(req.body.newsId)}
                }, function (err, response, body) {
                    console.log("api/userNLMs/addNlmR");
                    if (err) {
                        console.log(err.stack);
                        res.send({"error": 'failure'});
                    } else {
                        console.log('allotTomeR result')
                        console.log(response.data)
                        if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                            console.log('updation failed ::: ' + response.statusCode);
                            if (response.statusCode === 404) {
                                console.log(response.body.error.message)
                                res.send({"error": "URL Not Found " + url});
                            } else {
                                console.log(response.body.error.message)
                                res.send({"error": response.body.error.message});
                            }
                        }
                        else if (response.statusCode === 200 || response.statusCode === 201) {


                            console.log('updation success pushVol ' + response.statusCode + "  res.data   :  " + response.data);


                            var url = apiurl + "api/newsletters/create";

                            console.log("newsCreate  : ", obj, " totalVolNew  : ", parseInt(req.body.tempVol));


                            var newsobj = {
                                campId: parseInt(req.body.campId),
                                nlmId: newsId,
                                SN: req.body.SN[0],
                                SL: req.body.SL[0],
                                creative: req.body.creative,
                                startAt: req.body.startOn,
                                userId: parseInt(req.body.cBy),
                                totalVol: parseInt(req.body.dVol),
                                domainWise: [{id:'',vol:''}],
                                tempVol: parseInt(req.body.dVol),
                                cType:"retarget"
                            }
                            console.log("newsobj  : "+JSON.stringify(newsobj));
                            var id = req.cookies.userid;
                            if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
                                res.send('logout');
                            } else {
                                request({
                                    url: url,
                                    method: "POST",
                                    json: true,
                                    body: newsobj
                                }, function (err, response, body) {
                                    if (err) {
                                        res.send({'error':'Problem in sending Mail,plz try again later'});
                                        console.log(err.stack);
                                    } else {
                                        if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                            res.send({'error':'Problem in sending Mail,plz try again later'});

                                            console.log('  error ' + response.statusCode + ' error message  ' + JSON.stringify(response));
                                        }
                                        else if (response.statusCode === 200 || response.statusCode === 201) {

                                            console.log("success newscreate  ", response.statusCode);
                                            console.log("response.data  ", JSON.stringify(response.body.data));
                                            var nlId = response.body.data.id;
                                            var sentOn = parseInt(Math.floor(new Date().getTime() / 1000));

                                            var newobj = {
                                                "campId": parseInt(req.body.campId),
                                                "nlmId": newsId,
                                                "nlId": nlId,
                                                "userId": req.body.cBy,
                                                "sentOn": sentOn,
                                                "totalVol": req.body.dVol
                                            };

                                            console.log("newobj   :  ", newobj);
                                            request({
                                                url: apiurl + "api/statsNl/create",
                                                method: "POST",
                                                json: true,
                                                body: newobj
                                            }, function (err, response, body) {
                                                if (err) {
                                                    //console.log(err.stack);
                                                    res.send({'error':'Problem in sending Mail,plz try again later'});
                                                } else {

                                                    if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                                        res.send({'error':'Problem in sending Mail,plz try again later'});

                                                        console.log("statsNI   :" + response.statusCode);
                                                        console.log(response.body);
                                                    }
                                                    else if (response.statusCode === 200 || response.statusCode === 201) {


                                                        statsInsert(req.body.creative, req.body.campId, req.body.nlmId, nlId, req.body.userId, sentOn, res);



                                                        function statsInsert(Temphtmlbody,campId,nlmId,nlId,userId,sentOn,res)
                                                        {
                                                            var totalVolNew=parseInt(req.body.tempVol);
                                                            console.log("statsInsert    :    ",Temphtmlbody,"  campId  ",campId,"  nlmId  ",nlmId,"  nlId  ",nlId," userId ",userId,"sentOn ",sentOn);
                                                            // console.log("res   :  ",res);
                                                            var Mlinksa = [];
                                                            var xc=0;
                                                            function parselinks(callback) {
                                                                var parsedHTML = cheerio.load(Temphtmlbody)
                                                                parsedHTML('a').map(function (x, link) {
                                                                    console.log("link :"+link);
                                                                    var href = cheerio(link).attr('href');
                                                                    console.log("href :"+href);
                                                                    Mlinksa.push(href);
                                                                });
                                                                parsedHTML=null;
                                                                return callback(Mlinksa);
                                                            }

                                                            parselinks(function (Mlinksa) {
                                                                parselinksarea(Mlinksa, insertnlIdlinks);
                                                            });

                                                            function parselinksarea(Mlinksa, callback) {

                                                                var parsedHTML = cheerio.load(Temphtmlbody)
                                                                parsedHTML('area').map(function (x, link) {
                                                                    var href = cheerio(link).attr('href')
                                                                    //  console.log(href);
                                                                    Mlinksa.push(href);
                                                                });
                                                                parsedHTML=null;
                                                                return callback(Mlinksa);

                                                            }




                                                            function insertnlIdlinks()
                                                            {
                                                                console.log("xc :: "+xc+" Mlinksa.length ::  "+Mlinksa.length)
                                                                console.log("mlinks :: "+xc<Mlinksa.length)

                                                                if(xc<Mlinksa.length) {
                                                                    console.log("aaaaaaaaaa");
                                                                    var link = Mlinksa[xc];
                                                                    if(typeof link != 'undefined'){
                                                                    console.log("aaaaaaaaaa link" + link);
                                                                    var linkobj = {
                                                                        "link": link,
                                                                        "campId": campId,
                                                                        "nlmId": nlmId,
                                                                        "nlId": nlId,
                                                                        "userId": userId,
                                                                        "type": 0,
                                                                        "sentOn": sentOn
                                                                    };
                                                                    console.log("linkobj :: " + JSON.stringify(linkobj));
                                                                    request({
                                                                        url: apiurl + "api/StatsLinkWise/create",
                                                                        method: "POST",
                                                                        json: true,
                                                                        body: linkobj
                                                                    }, function (err, response, body) {
                                                                        if (err) {
                                                                            res.send({'error': 'Problem in sending Mail,plz try again later'});
                                                                            console.log(err.stack);

                                                                        } else {
                                                                            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                                                                res.send({'error': 'Problem in sending Mail,plz try again later'});
                                                                                console.log('links error  ' + response.statusCode);
                                                                                console.log('links error all ' + JSON.stringify(response.body));
                                                                            }
                                                                            else if (response.statusCode === 200 || response.statusCode === 201) {
                                                                                console.log("dome inserted linksss");
                                                                                xc++;
                                                                                setImmediate(insertnlIdlinks);

                                                                            } else {
                                                                                res.send({'error': 'Problem in sending Mail,plz try again later'});
                                                                                console.log('there is a problem in emailopen deviceinfo');
                                                                            }
                                                                        }
                                                                    });
                                                                }
                                                                else{console.log("skipped a link due to undefined ");
                                                                        xc++;
                                                                        setImmediate(insertnlIdlinks);}
                                                                }
                                                                else {

                                                                    request({
                                                                        url: apiurl+"api/newsletters/update/"+nlId,
                                                                        method: "POST",
                                                                        json: true,
                                                                        body: {status:0}
                                                                    }, function (err, response, body) {
                                                                        if (err) {
                                                                            console.log(err.stack);
                                                                            res.send({'error':'Problem in sending Mail,plz try again later'});
                                                                        } else {
                                                                            console.log('newsletters/update result')
                                                                            console.log(response.body.data)
                                                                            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                                                                                res.send({'error':'Problem in sending Mail,plz try again later'});
                                                                                console.log('newsletters/update updation failed ::: ' + response.statusCode);
                                                                            }
                                                                            else if (response.statusCode === 200 || response.statusCode === 201) {
                                                                                res.send({'error':'Retargetcampaign sent successfully !'});
                                                                                console.log("done inserting all logs.....");
                                                                            } else {
                                                                                res.send({'error':'Problem in sending Mail,plz try again later'});
                                                                            }
                                                                        }
                                                                    });


                                                                    //res.send("campaign sent successfully....");
                                                                    //console.log("done inserting all logs.....");

                                                                }

                                                            }
                                                        }


                                                    } else {
                                                        res.send({'error':'Problem in sending Mail,plz try again later'});
                                                        console.log("response  :  ", response.body);

                                                    }
                                                }
                                            });

                                        } else {
                                            res.send({'error':'Problem in sending Mail,plz try again later'});
                                            console.log('there is a problem in emailopen deviceinfo');
                                        }
                                    }
                                });
                            }



                        } else {
                            res.send('unknown error from API : ' + response.statusCode);
                        }
                    }
                });

                //res.send(response.body);
            } else {
                res.send('unknown error from API  updateNews : ' + response.statusCode);
            }
        }
    });


})





router.post('/getCountriesById',function(req,res){

    request({
        url:apiurl+'api/countries/'+parseInt(req.body.countryId),
        method:'GET'
    },function(err,response,body){
        if (err) {
            console.log(err.stack);
            res.send('Error getCountriesById while accessing API');
        }else{
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('step6 getCountriesById get error ' + response.statusCode);
                console.log(response.body.error);
                res.send(response.body);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('step6 getCountriesById get : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API getCountriesById : ' + response.statusCode);
            }}
    });

})

router.post('/getEdomainById',function(req,res){

    request({
        url:apiurl+'api/domains/'+parseInt(req.body.eDomain),
        method:'GET'
    },function(err,response,body){
        if (err) {
            console.log(err.stack);
            res.send('Error getEdomainById while accessing API');
        }else{
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('step6 getEdomainById get error ' + response.statusCode);
                console.log(response.body.error);
                res.send(response.body);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('step6 getEdomainById get : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API getEdomainById : ' + response.statusCode);
            }}
    });

})

router.post('/getCityById',function(req,res){

    request({
        url:apiurl+'api/cities/'+parseInt(req.body.cityId),
        method:'GET'
    },function(err,response,body){
        if (err) {
            console.log(err.stack);
            res.send('Error getCityById while accessing API');
        }else {
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('step6 getCityById get error ' + response.statusCode);
                console.log(response.body.error);
                res.send(response.body);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('step6 getCityById get : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API getCityById : ' + response.statusCode);
            }
        }
    });

})

router.post('/getCityByIds',function(req,res){
    var ids = [];
    console.log("req.body.cityIds :  "+parseInt(req.body.cityIds[0]));
    for(var i=0;i<req.body.cityIds.length;i++)
        ids.push(parseInt(req.body.cityIds[i]));
    var url =apiurl+'api/cities/ids?ids='+[JSON.stringify(req.body.cityIds)];
    console.log("url : "+url);
    request({
        url:url,
        method:'GET'
    },function(err,response,body){
        if (err) {
            console.log(err.stack);
            res.send('Error getCityByIdss while accessing API');
        }else {
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('step6 getCityByIdss get error ' + response.statusCode);
                console.log(response.body.error);
                res.send(response.body);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('getCityByIdss get : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API getCityByIdss : ' + response.statusCode);
            }
        }
    });

})


router.post('/getCountries',function(req,res){

    request({
        url:apiurl+'api/countries',
        method:'GET'
    },function(err,response,body){
        if (err) {
            console.log(err.stack);
            res.send('Error countries while accessing API');
        }else{
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('step6 getCountries get error ' + response.statusCode);
                console.log(JSON.parse(response.body.toString()).error);
                console.log(JSON.parse(response.body.toString()).error.message);
                console.log(response.body.error);
                res.send(response.body );
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('step6 getCountries get : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API step6 getCountries : ' + response.statusCode);
            }
        }
    });

})


router.post('/getCities',function(req,res){

    var countryId = parseInt(req.body.countryId);
    console.log("countryId  : ",parseInt(countryId));
    request({
        url:apiurl+'api/cities/cyId/'+countryId,
        method:'GET'
    },function(err,response,body){
        if (err) {
            console.log(err.stack);
            res.send('Error cities while accessing API');
        }else{
            console.log("response  :  ",JSON.stringify(response));
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('step6 getCIties get error ' + response.statusCode);
                console.log(JSON.parse(response.body.toString()).error);
                console.log(JSON.parse(response.body.toString()).error.message);
                console.log(response.body.error);
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('step6 getCIties get : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API step6 getCIties: ' + response.statusCode);
            }}
    });

})
router.post('/getTagsOnly', function (req, res) {
    var id = req.cookies.userid;
    console.log(req.body);
    var url = apiurl+"api/tags/tags";
    console.log(url);
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error getTagsOnly while accessing API');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error getTagsOnly": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error getTagsOnly": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log('no of getTagsOnly::: ' + response.body.data.length);
                    console.log(response.body.data);
                    result=response.body.data;

                    console.log("success getTagsOnly"+result);
                    res.send(result);
                } else {
                    console.log("api error" );
                    res.send({"error getTagsOnly": "API Error"});
                }
            }
        });
    }
});

router.post('/getBrandsOnly', function (req, res) {
    var id = req.cookies.userid;
    console.log(req.body);
    var url = apiurl+"api/tags/brands";
    console.log(url);
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error getBrandsOnly while accessing API');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error getBrandsOnly": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error getBrandsOnly": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log('no of getBrandsOnly::: ' + response.body.data.length);
                    console.log(response.body.data);
                    result=response.body.data;

                    console.log("success getBrandsOnly"+result);
                    res.send(result);
                } else {
                    console.log("api error" );
                    res.send({"error getBrandsOnly": "API Error"});
                }
            }
        });
    }
});

router.post('/gettags', function (req, res) {
    var id = req.cookies.userid;
    console.log(req.body);
    var url = apiurl+"api/tags";
    console.log(url);
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log('no of tasksfsdfdsfds::: ' + response.body.data.length);
                    console.log(response.body.data);
                    result=response.body.data;

                    console.log("success"+result);
                    res.send(result);
                } else {
                    console.log("api error" );
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});

router.post('/createTagsBrands', function(req, res) {

    console.log("Create Tags  ");

    var name = req.body.name;

    console.log(name);
  /*var date = new Date('2016-08-04 00:00:00'.split(' ').join('T'))
     var unixtimes=date.getTime() / 1000;*/
    var obj = {
        "name": name,
        "type": 1
    }

    console.log(obj);

    request({
        url: apiurl+"api/tags/create",
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            console.log('else create error : ' + response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('create error ' + response.statusCode);
                console.log(response.body.error.message)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('tags Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }
        }
    });
})

//code by ramu
//commented createTags
/*router.post('/createTags', function(req, res) {

 console.log("Create Tags  ");

 var id = req.body.id;

 var name = req.body.name;

 var type=req.body.type;

 var from = parseInt(req.body.from);

 var to = req.body.to;

 console.log(id);
 console.log(name);
 console.log(from);
 console.log(to);
 /!*var date = new Date('2016-08-04 00:00:00'.split(' ').join('T'))
 var unixtimes=date.getTime() / 1000;*!/
 var obj = {
 "id": id,
 "name": name,
 "type": type,
 "from": from,
 "to": to
 }

 console.log(obj);

 request({
 url: apiurl+"api/tags/create",
 method: "POST",
 json: true,
 body: obj
 }, function (err, response, body) {
 if (err) {
 console.log(err.stack);
 } else {
 console.log('else create error : ' + response.statusCode);
 if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
 console.log('create error ' + response.statusCode);
 console.log(response.body.error.message)
 res.send([]);
 }
 else if (response.statusCode === 200 || response.statusCode === 201) {
 console.log('tags Created  : ');
 res.send(response.body);
 } else {
 res.send('unknown error from API : ' + response.statusCode);
 }
 }
 });
 })*/

router.post('/createTags', function(req, res) {

    console.log("Create Tags  ");

    var id = req.body.id;

    var name = req.body.name;

    var type=1;

    var from = parseInt(req.body.from);

    var to = req.body.to;

    console.log(id);
    console.log(name);
    console.log(from);
    console.log(to);
  /*var date = new Date('2016-08-04 00:00:00'.split(' ').join('T'))
   var unixtimes=date.getTime() / 1000;*/
    var obj = {
        "id": id,
        "name": name.toLowerCase(),
        "type": type,
        "from": from,
        "to": to
    }

    console.log(obj);

    request({
        url: apiurl+"api/tags/create",
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            console.log('else create error : ' + response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('create error ' + response.statusCode);
                console.log(response.body.error.message);
                if(typeof response.body.error.details.id != "undefined"){
                    console.log("response.body.error.details   : "+JSON.stringify(response.body.error.details))

                    res.send({data:response.body.error.details});

                }else{
                    res.send(response.body.error);}
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('tags Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }
        }
    });
})

router.post('/createBrands', function(req, res) {

    console.log("Create brands  ");

    var id = req.body.id;

    var name = req.body.name;

    var type=2;

    var from = parseInt(req.body.from);

    var to = req.body.to;

    console.log(id);
    console.log(name);
    console.log(from);
    console.log(to);
  /*var date = new Date('2016-08-04 00:00:00'.split(' ').join('T'))
   var unixtimes=date.getTime() / 1000;*/
    var obj = {
        "id": id,
        "name": name.toLowerCase(),
        "type": type,
        "from": from,
        "to": to
    }

    console.log(obj);

    request({
        url: apiurl+"api/tags/create",
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            console.log('else create error : ' + response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('create error ' + response.statusCode);
                console.log(response.body.error.message);
                if(typeof response.body.error.details.id != "undefined"){
                    console.log("response.body.error.details   : "+JSON.stringify(response.body.error.details))

                    res.send({data:response.body.error.details});

                }else{
                    res.send(response.body.error);}
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('tags Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }
        }
    });
})

router.post('/createPrice', function(req, res) {

    console.log("Create Tags  ");

    var id = req.body.id;

    var name = req.body.name;

    var type=3;

    var from = parseInt(req.body.from);

    var to = req.body.to;

    console.log(id);
    console.log(name);
    console.log(from);
    console.log(to);
  /*var date = new Date('2016-08-04 00:00:00'.split(' ').join('T'))
   var unixtimes=date.getTime() / 1000;*/
    var obj = {
        "id": id,
        "name": name,
        "type": type,
        "from": from,
        "to": to
    }

    console.log(obj);

    request({
        url: apiurl+"api/tags/create",
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            console.log('else create error : ' + response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('create error ' + response.statusCode);
                console.log(response.body.error.message);
                if(typeof response.body.error.details.id != "undefined"){
                    console.log("response.body.error.details   : "+JSON.stringify(response.body.error.details))

                    res.send({data:response.body.error.details});

                }else{
                    res.send(response.body.error);}
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('tags pricerange  : '+JSON.stringify(response.body));
                res.send(response.body);
            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }
        }
    });
})

router.post('/gettags', function (req, res) {
    var id = req.cookies.userid;
    console.log(req.body);
    var url = apiurl+"api/tags";
    console.log(url);
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log('no of tasksfsdfdsfds::: ' + response.body.data.length);
                    console.log(response.body.data);
                    result=response.body.data;

                    console.log("success"+result);
                    res.send(result);
                } else {
                    console.log("api error" );
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});


//code for getNewTags step6

router.get('/getNewsTags/:newsTagId', function (req, res) {
    var id = req.cookies.userid;
    var newsTagId=req.params.newsTagId;
    console.log(req.body);
    var url = apiurl+"api/nlm/"+newsTagId;
    console.log(url);
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    if(response.body.data!=null)
                    {


                        //  console.log('no of newstags::: ' + response.body.data.length);
                        console.log(response.body.data);
                        result=response.body.data;

                        console.log("success"+result);
                        res.send(result);
                    }
                    else {
                        res.send(result);
                    }

                } else {
                    console.log("api error" );
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});
router.get('/getNewsTags1/:news1Tags', function (req, res) {
    var id = req.cookies.userid;
    var news1Tags=req.params.news1Tags;
    console.log("getNewsTags1"+req.body);
    var url = apiurl+"api/tags/"+parseInt(news1Tags);
    console.log(url);
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log('no of newstags::: ' + response.body.data.length);
                    console.log("getNewsTags1 response:::"+JSON.stringify(response.body.data));
                    result=response.body.data;

                    console.log("success"+result);
                    res.send(result);
                } else {
                    console.log("api error" );
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});

//end of code step6

router.post('/nlUpdate', function (req, res) {

    var id = req.cookies.userid;
    var url = apiurl+"api/newsletters/update/"+parseInt(req.body.nlId);
    console.log(url);
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        var obj = {"status": req.body.status}
        request({
            url: url,
            method: "post",
            json: true,
            body:obj
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @nlUpdate');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "nlUpdate Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error nlUpdate": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log('nlUpdate length::: ' + response.body.data.length);
                    console.log("nlUpdate response:::"+JSON.stringify(response.body.data));
                    result=response.body.data;
                    console.log("success nlUpdate  : "+result);
                    res.send(result);
                } else {
                    console.log("api error nlUpdate" );
                    res.send({"error nlUpdate": "API Error"});
                }
            }
        });
    }
});

//new getReports
router.post('/getNlDetail', function (req, res) {

    var id = req.cookies.userid;
    var statsNlObj = {"where":{"nlId":req.body.nlId}};
    var url = apiurl+"api/statsNl?filter="+JSON.stringify(statsNlObj);
    //console.log(url);
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    //  console.log('Reports length::: ' + response.body.data.length);
                    //  console.log("reports response:::"+JSON.stringify(response.body.data));
                    result=response.body.data;

                    // console.log("success reports  : "+result);
                    res.send(result);
                } else {
                    console.log("api error" );
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});



router.get('/getCampaignsR', function (req, res) {

    var id = parseInt(req.cookies.userid);
    var obj = {"where":{"cType":"retarget"}};

    var url = apiurl+"api/nlm/cBy/"+id+"/drafts?filter="+JSON.stringify(obj);
    console.log(url);
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log('getCampaignsR length::: ' + response.body.data.length);
                    console.log("getCampaignsR response:::"+JSON.stringify(response.body.data));
                    result=response.body.data;
                    console.log("success getCampaignsR  : "+result);
                    res.send(result);
                } else {
                    console.log("api error" );
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});

router.post('/getCampaigns', function (req, res) {

    var id = parseInt(req.cookies.userid);

    var obj = req.body.draftObj;
    console.log("DRAFTS obj : "+JSON.stringify(obj));
    var url = apiurl+"api/nlm/cBy/"+id+"/drafts?filter="+JSON.stringify(obj);
    console.log(url);
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log('getCampaigns length::: ' + response.body.data.length);
                    // console.log("getCampaigns response:::"+JSON.stringify(response.body.data));
                    result=response.body.data;
                    console.log("success getCampaigns  : "+result);
                    res.send(result);
                } else {
                    console.log("api error" );
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});


router.post('/getReports', function (req, res) {

    var id = parseInt(req.cookies.userid);

  /* var date = new Date();
   var date2Day = date.setHours(0, 0, 0,0);*/
    var date2Day = req.body.date2Day;
    console.log("date2Day  ",date2Day);
    var startOn = parseInt(Math.round(date2Day/1000));
    console.log("dat2Dat :: "+startOn);
    var dayend=parseInt(startOn)+86400;
    console.log("id :: "+id);

    var url = apiurl+"api/statsNl/nlmWise?fromTime="+startOn+"&toTime="+dayend;
    console.log(url);
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    console.log('Reports length::: ' + response.body.data.length);
                    console.log("reports response 12121212 :::"+JSON.stringify(response.body.data));
                    result=response.body.data;

                    console.log("success reports  : "+result);
                    res.send(result);
                } else {
                    console.log("api error" );
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});


//old getReports
/*router.post('/getReports', function (req, res) {

 var id = parseInt(req.cookies.userid);

 /!* var date = new Date();
 var date2Day = date.setHours(0, 0, 0,0);*!/
 var date2Day = req.body.date2Day;
 console.log("date2Day  ",date2Day);
 var startOn = parseInt(Math.round(date2Day/1000));

 var url = apiurl+"api/statsNl/nlmWise?userId="+id+"&sentOn="+startOn;
 console.log(url);
 var result = [];

 if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
 console.log('if failed');
 res.send('logout');
 } else {
 console.log('requesting');
 request({
 url: url,
 method: "GET",
 json: true,
 }, function (err, response, body) {
 if (err) {
 console.log(err.stack);
 res.send('Error while accessing API @GetMainPermissions');
 } else {
 if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
 {
 if (response.statusCode === 404) {
 console.log(response.body.error.message)
 res.send({"error": "URL Not Found " + url});
 } else {
 console.log(response.body.error.message)
 res.send({"error": response.body.error.message});
 }

 }
 else if (response.statusCode === 200 || response.statusCode === 201) {
 console.log('Reports length::: ' + response.body.data.length);
 console.log("reports response:::"+JSON.stringify(response.body.data));
 result=response.body.data;

 console.log("success reports"+result);
 res.send(result);
 } else {
 console.log("api error" );
 res.send({"error": "API Error"});
 }
 }
 });
 }
 });*/



router.post('/getNlmByDt', function (req, res) {
    var id = parseInt(req.cookies.userid);
    var url = apiurl+req.body.url;
    console.log(url);

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @getNlmByDt');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL getNlmByDt Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error getNlmByDt": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    console.log('Reports length::: ' + response.body.data.length);
                    console.log("getNlmByDt response :"+JSON.stringify(response.body.data));
                    result=response.body.data;

                    console.log("success getNlmByDt"+result);
                    res.send(result);
                } else {
                    console.log("getNlmByDt error" );
                    res.send({"error getNlmByDt": "API Error"});
                }
            }
        });
    }
});

router.post('/getNlmNamesR', function (req, res) {

    var id = parseInt(req.cookies.userid);
    var nlmIds = req.body.nlmIds;
    console.log("getNlmNamesR  :  ",nlmIds);
    console.log("req.body :  ",nlmIds[0]);

    var filter = { "where":{"id":{"in":nlmIds},"cType":'retarget'}, "fields":["id","title","SN"] };
    var url = apiurl+"api/nlm/query?filter="+JSON.stringify(filter);
    console.log(url);
    console.log("filterR :  "+JSON.stringify(filter));
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    console.log('Reports length::: ' + response.body.data.length);
                    console.log("getReportNames response :"+JSON.stringify(response.body.data));
                    result=response.body.data;

                    console.log("success reportNames"+result);
                    res.send(result);
                } else {
                    console.log("api error" );
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});




router.post('/getDataSrc', function (req, res) {

    var id = parseInt(req.cookies.userid);
    var url = apiurl+"api/sources";
    console.log("getDataSrc   "+url);
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET"
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @getDataSrc');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found getDataSrc " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error getDataSrc": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    console.log("response.body  : "+response.body);
                    result=response.body;
                    res.send(result);

                } else {
                    console.log("api error" );
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});





router.post('/getNlmNames', function (req, res) {

    var id = parseInt(req.cookies.userid);
    var nlmIds = req.body.nlmIds;
    console.log("getNlmNames  :  ",nlmIds);
    console.log("req.body :  ",nlmIds[0]);

    var filter = { "where":{"id":{"in":nlmIds},"cType":"direct"},"fields":["id","title","SN"] };
    var url = apiurl+"api/nlm/query?filter="+JSON.stringify(filter);
    console.log(url);
    console.log("filter : "+JSON.stringify(filter));
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    console.log('Reports length::: ' + response.body.data.length);
                    console.log("getReportNames response :"+JSON.stringify(response.body.data));
                    result=response.body.data;

                    console.log("success reportNames"+result);
                    res.send(result);
                } else {
                    console.log("api error" );
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});


http://localhost:3000/api/newsletters?filter={ "where":{"id":{"in":[1,2,3]}}, "fields":["id","SN","SL","pickId"] }

    router.post('/getNlmReports', function (req, res) {

        var id = parseInt(req.cookies.userid);

        var nlmId = parseInt(req.body.nlmId);

        var date2Day = req.body.date2Day;
        console.log("date2Day  ",date2Day);
        var startOn = parseInt(Math.round(date2Day/1000));
        var dayend = startOn+86400;

        console.log("startOn  :  ",startOn," and nlmId  : ",nlmId);
       var statsNlObj =  {"where":{  "nlmId":nlmId,"sentOn":{"gte":startOn},"sentOn":{"lte":dayend}}};
        var url = apiurl+"api/statsNl?filter="+JSON.stringify(statsNlObj);
       // var url = apiurl+"api/statsNl/nlWise?nlmId="+nlmId+"&fromTime="+startOn+"&toTime="+dayend;

      /* var url = apiurl+"api/statsNl/nlWise?nlmId="+nlmId+"&sentOn="+startOn;*/
        console.log(url);
        var result = [];

        if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
            console.log('if failed');
            res.send('logout');
        } else {
            console.log('requesting');
            request({
                url: url,
                method: "GET",
                json: true,
            }, function (err, response, body) {
                if (err) {
                    console.log(err.stack);
                    res.send('Error while accessing API @GetMainPermissions');
                } else {
                    if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                    {
                        if (response.statusCode === 404) {
                            console.log(response.body.error.message)
                            res.send({"error": "URL Not Found " + url});
                        } else {
                            console.log(response.body.error.message)
                            res.send({"error": response.body.error.message});
                        }

                    }
                    else if (response.statusCode === 200 || response.statusCode === 201) {
                        console.log('nlmNames length::: ' + response.body.data.length);
                        console.log("nlmNames response:::"+JSON.stringify(response.body.data));
                        result=response.body.data;

                        console.log("success reports"+result);
                        res.send(result);
                    } else {
                        console.log("api error" );
                        res.send({"error": "API Error"});
                    }
                }
            });
        }
    });


router.post('/getCurrentNl', function (req, res) {

    var id = parseInt(req.cookies.userid);

    var date1 = new Date().toISOString().substr(0, 10);
    var date = new Date(date1+" 00:00:00")
    var unixtimes = date.getTime() / 1000;

    var filter = {"where":{"$or":[{"status":0},{"status":1},{"status":4},{"status":3}],"startAt":{"gt":unixtimes},"userId":id}};

    var url = apiurl+"api/newsletters?filter="+JSON.stringify(filter);

    //console.log(url);
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        //console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @getCurrentNl');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    //console.log('getCurrentNl length::: ' + response.body.data.length);
                    //console.log("getCurrentNl response :"+JSON.stringify(response.body.data));
                    result=response.body.data;

                    // console.log("success getCurrentNl"+result);
                    res.send(result);
                } else {
                    // console.log("getCurrentNl api error" );
                    res.send({"error": "getCurrentNl API Error"});
                }
            }
        });
    }
});


router.post('/getNilNames', function (req, res) {

    var id = parseInt(req.cookies.userid);
    var nlmIds = req.body.nlmIds;
    console.log("getNlmNames  :  ",nlmIds);
    console.log("req.body :  ",nlmIds[0]);

    var filter = { "where":{"id":{"in":nlmIds}}, "fields":["id","SN","SL","pickId","userId"] };
    var url = apiurl+"api/newsletters?filter="+JSON.stringify(filter);
    console.log(url);
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @GetMainPermissions');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    console.log('Reports length::: ' + response.body.data.length);
                    console.log("getReportNames response :"+JSON.stringify(response.body.data));
                    result=response.body.data;

                    console.log("success reportNames"+result);
                    res.send(result);
                } else {
                    console.log("api error" );
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});



router.post('/getDomain', function (req, res) {

    var id = parseInt(req.cookies.userid);

    var url = apiurl+"api/domains/cBy/"+id;
    console.log(url);
    var result = [];

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {
        console.log('requesting');
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @domain');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    console.log('domain length::: ' + response.body.data.length);
                    console.log("domain response::: "+JSON.stringify(response.body.data));
                    result=response.body.data;
                    console.log("success reports"+result);
                    res.send(result);
                } else {
                    console.log("api error" );
                    res.send({"error": "API Error"});
                }
            }
        });
    }
});



router.post('/createDomain', function(req, res) {

    var obj = {
        "name": req.body.name,
        "imgUrl": req.body.imgUrl,
        "trackUrl": req.body.trackUrl,
        "capacity": parseInt(req.body.capacity),
        "curPush": parseInt(req.body.curPush) ,
        "msgId":req.body.msgId,
        "cBy":parseInt(req.body.cBy)
    }

    console.log(obj);

    request({
        url: apiurl+"api/domains/create",
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            console.log('Domain : ' + response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('create domain error ' + response.statusCode);
                console.log(response.body.error.message)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('CReate domain Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }
        }
    });
})

router.post('/editDomain', function(req, res) {

    var obj = {
        "name": req.body.name,
        "imgUrl": req.body.imgUrl,
        "trackUrl": req.body.trackUrl,
        "capacity": parseInt(req.body.capacity),
        "curPush": parseInt(req.body.curPush) ,
        "msgId":req.body.msgId,
        "cBy":parseInt(req.body.cBy),
        "status":parseInt(req.body.status)
    }

    console.log(obj);
    console.log(apiurl+"api/domains/update/",parseInt(req.body.id));
    request({
        url: apiurl+"api/domains/update/"+parseInt(req.body.id),
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            console.log('Domain Edit: ' + response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('Edit domain error ' + response.statusCode);
                console.log(response.body.error.message)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('Edit domain Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }
        }
    });
})

router.post('/getViewDomain', function(req, res) {
    var id = $cookieStore.get("userid");
    console.log(apiurl+"api/domains/cBy/",id);
    request({
        url: apiurl+"api/domains/cBy/"+id,
        method: "GET"
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            console.log('getViewDomain Edit: ' + response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('getViewDomain error ' + response.statusCode);
                console.log(response.body.error.message)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('getViewDomain Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }
        }
    });
})

router.post('/postDomain',function(req,res){

    console.log("url  :  "+apiurl+"api/domains/update/"+parseInt(req.body.domainOpt));
    console.log("asgnTo   "+JSON.stringify(req.body.userId));
    var obj1 = {
        "asgnTo": parseInt(req.body.userId)
    }
    request({
        url: apiurl+"api/domains/update/"+parseInt(req.body.domainOpt),
        method: "POST",
        body:obj1,
        json:true
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            console.log('POSTDOMAIN Edit: ' + response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('POSTDOMAIN error ' + response.statusCode);
                console.log(response.body);
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('POSTDOMAIN Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }
        }
    });

});

router.post('/getUserDomain', function (req, res) {
    var id = parseInt(req.cookies.userid);

    console.log(apiurl+"api/domains/user/"+id);
    request({
        url: apiurl+"api/domains/user/"+id,
        method: "GET"
    }, function (err, response, body) {
        if (err) {
            console.log("getUserDomain   ",err.stack);
        } else {
            console.log('getUserDomain Edit: ' + response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('getUserDomain error ' + response.statusCode);
                console.log(response.body.error.message)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('getUserDomain Created  : ',response.body);
                res.send(response.body);
            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }
        }
    });
});

router.post('/requestVolume',function(req,res){

    var reqobj={
        "campId": parseInt(req.body.campId),
        "nlmId": parseInt(req.body.nlmId),
        "targets": req.body.targets,
        "date": req.body.date,
        "reqPush": req.body.reqPush,
        "userId":req.body.userId,
        "altPush": 0,
        "status": 0};



    request({
        url: apiurl+"api/nlmallottedpush/insert",
        method: "POST",
        json: true,
        body: reqobj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('step6 updateStep6 error ' + response.statusCode);

                console.log(response.body.error)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('step6 updateStep6 Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API step6 updateStep6 : ' + response.statusCode);
            }
        }
    });


});

router.post('/createNewsR', function(req, res) {

    console.log("Create NEwsletter  ");

    var bodyObj = req.body.news;
    console.log("bodyObj "+JSON.stringify(bodyObj));

    var campId = req.body.campId;

    var cBy = req.body.cBy;

    var startOn= parseInt(req.body.startOn);
    var endOn =parseInt(req.body.endOn);

    if(bodyObj.roi != null || bodyObj.roi!='undefined'){
        var roi = bodyObj.roi;}

    console.log(startOn);
    console.log(endOn);
    console.log(bodyObj.title,"  ",bodyObj.type);
  /*var date = new Date('2016-08-04 00:00:00'.split(' ').join('T'))
   var unixtimes=date.getTime() / 1000;*/
    var obj = {"campId":campId,
        "cBy": cBy,
        "title": bodyObj.title,
        "type": bodyObj.type,
        "startOn": startOn,
        "endOn": endOn,
        "status": -6,
        "cType":"retarget",
        "roi": roi}

    console.log(obj);

    request({
        url: apiurl+"api/nlm/create",
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            console.log('else newsletter error : '+response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('Newsletter error ' + response.statusCode);
                console.log(response.body.error.message);
              /*  console.log(JSON.parse(response.body.toString()).error);
               console.log(JSON.parse(response.body.toString()).error.message);*/
                res.send({data:response.body.error.message});

            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('NewsLetter Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API : ' + response.statusCode);
            }
        }
    });


})


router.post('/editNewsR',function(req,res){

    console.log(req.body.campId);
    var date = new Date('2016-08-04 00:00:00'.split(' ').join('T'))
    var unixtimes=date.getTime() / 1000;
    var startOn= parseInt(req.body.startOn);
    var endOn =parseInt(req.body.endOn);
    var obj = {
        "creative":'hello',"roi":req.body.roi,"status":-6,"title": req.body.title,"cBy": parseInt(req.body.cBy),"campId":parseInt(req.body.campId),"type":req.body.type,
        "startOn":startOn,"endOn":endOn}

    var newsId = parseInt(req.body.newsId);

    console.log(obj, "  ",newsId);
    request({
        url: apiurl+"api/nlm/update/"+newsId,
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            console.log('else nEWSEDIT error : '+response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('NEWSEDIT error ' + response.statusCode);
                console.log(response.body.error.message);
              /*        console.log(JSON.parse(response.body.toString()).error);
               console.log(JSON.parse(response.body.toString()).error.message);*/
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('nEWSEDIT Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API NEWS : ' + response.statusCode);
            }
        }
    });


})

router.post('/updateStep3R',function(req,res){

    console.log(req.body.SL);
    var obj = {"SN": req.body.SN,"cBy": parseInt(req.body.cBy),"SL":req.body.SL,"creative":req.body.creative}
    if(req.body.status != '')
    {
        obj.status=parseInt(req.body.status);
    }
    var newsId = parseInt(req.body.newsId);

    console.log(obj, "  ",newsId);
  /*  res.send("success");*/
    request({
        url: apiurl+"api/nlm/update/"+newsId,
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            console.log('step3 nEWSEDIT error : '+response.statusCode);
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('step3 NEWSEDIT error ' + response.statusCode);
                console.log(response.body.error)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('step3 nEWSEDIT Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API step3 : ' + response.statusCode);
            }
        }
    });


});

router.post('/updateStep4R',function(req,res){



    var obj = {"cBy":req.body.cBy,"tags": req.body.tags,status:-4}



    if(req.body.tBrands != ''){
        obj.tBrands=req.body.tBrands;
    }
    if(req.body.tPR !=''){
        obj.tPR=req.body.tPR;
    }

    console.log("updateStep4 obj  : "+JSON.stringify(obj))
    var newsId = parseInt(req.body.newsId);

    console.log(obj, "  ",newsId);
  /*  res.send("success");*/
    request({
        url: apiurl+"api/nlm/update/"+newsId,
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('step4 NEWSEDIT error ' + response.statusCode);
              /* console.log(JSON.parse(response.body.toString()).error);
               console.log(JSON.parse(response.body.toString()).error.message);*/
                console.log(response.body.error)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('step4 nEWSEDIT Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API step4 : ' + response.statusCode);
            }
        }
    });


});

router.post('/updateStep5R',function(req,res){


    var reqObj = {"eDomain":parseInt(req.body.eDomain),"country":parseInt(req.body.countries)}

    if(typeof req.body.gender !="undefined" && parseInt(req.body.gender) !== 0){
        reqObj.gender=parseInt(req.body.gender);
    }
    if(typeof req.body.age.from !="undefined"){
        if(typeof req.body.age.to !="undefined"){
            var age1={from:parseInt(req.body.age.from),to:parseInt(req.body.age.to)}
            reqObj.age=age1;
        }
    }
    if(typeof req.body.cities !="undefined"){
        if(req.body.cities!=='' && req.body.cities.toString() !== '')
        {
            reqObj.city = req.body.cities;
        }
    }
    if(typeof req.body.catTags !="undefined" && req.body.catTags.toString()!==''){
        reqObj.catTags=req.body.catTags;
    }

    reqObj.resTime = req.body.resTime;
    reqObj.returnType = req.body.returnType;
    reqObj.domainType = req.body.domainType;
    reqObj.device = req.body.device;

    var newsId = parseInt(req.body.newsId);
    var obj = {"status":-3,"targets":reqObj,"dVol":parseInt(req.body.dVol),"cBy":req.body.cBy};
    console.log(obj, "  ",newsId);
  /*  res.send("success");*/
    request({
        url: apiurl+"api/nlm/update/"+newsId,
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('step5 NEWSEDIT error ' + response.statusCode);
              /*       console.log(JSON.parse(response.body.toString()).error);
               console.log(JSON.parse(response.body.toString()).error.message);*/
                console.log(response.body.error)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('step5 nEWSEDIT R Created  : '+JSON.stringify(response.body));
                res.send(response.body);
            } else {
                res.send('unknown error from API step5 : ' + response.statusCode);
            }
        }
    });


});

/*router.post('/updateStep3R',function(req,res){

 console.log(req.body.SL);
 var obj = {"SN": req.body.SN,"cBy": parseInt(req.body.cBy),"SL":req.body.SL,status:-5,"creative":req.body.creative}

 var newsId = parseInt(req.body.newsId);

 console.log(obj, "  ",newsId);
 /!*  res.send("success");*!/
 request({
 url: apiurl+"api/nlm/update/"+newsId,
 method: "POST",
 json: true,
 body: obj
 }, function (err, response, body) {
 if (err) {
 console.log(err.stack);
 } else {
 console.log('step3 nEWSEDIT error : '+response.statusCode);
 if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
 console.log('step3 NEWSEDIT error ' + response.statusCode);
 console.log(response.body.error)
 res.send(response.body.error);
 }
 else if (response.statusCode === 200 || response.statusCode === 201) {
 console.log('step3 nEWSEDIT Created  : ');
 res.send(response.body);
 } else {
 res.send('unknown error from API step3 : ' + response.statusCode);
 }
 }
 });


 });*/

router.post('/updateStep4R',function(req,res){



    var obj = {"cBy":req.body.cBy,"tags": req.body.tags,status:-4}



    if(req.body.tBrands != ''){
        obj.tBrands=req.body.tBrands;
    }
    if(req.body.tPR !=''){
        obj.tPR=req.body.tPR;
    }

    console.log("updateStep4 obj  : "+JSON.stringify(obj))
    var newsId = parseInt(req.body.newsId);

    console.log(obj, "  ",newsId);
  /*  res.send("success");*/
    request({
        url: apiurl+"api/nlm/update/"+newsId,
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('step4 NEWSEDIT error ' + response.statusCode);
              /* console.log(JSON.parse(response.body.toString()).error);
               console.log(JSON.parse(response.body.toString()).error.message);*/
                console.log(response.body.error)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('step4 nEWSEDIT Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API step4 : ' + response.statusCode);
            }
        }
    });


});

router.post('/updateStep5R',function(req,res){


    var reqObj = {"eDomain":parseInt(req.body.eDomain),"country":parseInt(req.body.countries)}

    if(typeof req.body.gender !="undefined" && parseInt(req.body.gender) !== 0){
        reqObj.gender=parseInt(req.body.gender);
    }
    if(typeof req.body.age.from !="undefined"){
        if(typeof req.body.age.to !="undefined"){
            var age1={from:parseInt(req.body.age.from),to:parseInt(req.body.age.to)}
            reqObj.age=age1;
        }
    }
    if(typeof req.body.cities !="undefined"){
        if(req.body.cities!=='' && req.body.cities.toString() !== '')
        {
            reqObj.city = req.body.cities;
        }
    }
    if(typeof req.body.catTags !="undefined" && req.body.catTags.toString()!==''){
        reqObj.catTags=req.body.catTags;
    }

    var newsId = parseInt(req.body.newsId);
    var obj = {"status":-3,"targets":reqObj,"dVol":parseInt(req.body.dVol),"cBy":req.body.cBy};
    console.log(obj, "  ",newsId);
  /*  res.send("success");*/
    request({
        url: apiurl+"api/nlm/update/"+newsId,
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('step5 NEWSEDIT error ' + response.statusCode);
              /*       console.log(JSON.parse(response.body.toString()).error);
               console.log(JSON.parse(response.body.toString()).error.message);*/
                console.log(response.body.error)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('step5 nEWSEDIT Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API step5 : ' + response.statusCode);
            }
        }
    });


});
router.post('/updateStep6R',function(req,res){


    var newsId = parseInt(req.body.newsId);


    var obj ={ "cBy":req.body.cBy,"status":-2};
    console.log(obj, "  ",newsId);


    request({
        url: apiurl+"api/nlm/update/"+newsId,
        method: "POST",
        json: true,
        body: obj
    }, function (err, response, body) {
        if (err) {
            console.log(err.stack);
        } else {
            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                console.log('step6 updateStep6 error ' + response.statusCode);

                console.log(response.body.error)
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201) {
                console.log('step6 updateStep6 Created  : ');
                res.send(response.body);
            } else {
                res.send('unknown error from API step6 updateStep6 : ' + response.statusCode);
            }
        }
    });


})


router.post('/getStep1R/:campId',function(req,res){

    var campId = req.params.campId;
    console.log("getStep1  : "+apiurl+'api/campaigns/'+campId);
    request({

        method:'GET',
        url:apiurl+'api/campaigns/'+campId

    },function(error,response,then){
        if(error)
        {
            console.log(error.stack);
        }
        else{
            console.log("else response");
            if(response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500){
                console.log('Campaign error ' + response.statusCode);
                console.log(response.body);
              /*     console.log(JSON.parse(response.body.toString()).error);
               console.log(JSON.parse(response.body.toString()).error.message);*/
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201){
                console.log('Getting campaign : ');
                console.log(response.body);
                res.send(response.body);
            }
            else
            {
                res.send('unknown error from API  : ' + response.statusCode);
            }
        }

    })

})

// GET NEWSLETTER
router.post('/getStep2R/:newsId',function(req,res){

    var newsId = req.params.newsId;
    request({

        method:'GET',
        url:apiurl+'api/nlm/'+newsId

    },function(error,response,then){
        if(error)
        {
            console.log(error.stack);
        }
        else{
            console.log("else response news");
            if(response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500){
                console.log('NEws error STEP2 ' + response.statusCode);

              /*    console.log(JSON.parse(response.body.toString()).error);
               console.log(JSON.parse(response.body.toString()).error.message);*/
                res.send(response.body.error);
            }
            else if (response.statusCode === 200 || response.statusCode === 201){
                console.log('Getting news STEP2: ');
                res.send(response.body);
            }
            else
            {
                res.send('unknown error from API  NEws: ' + response.statusCode);
            }
        }

    })

});




router.post('/AllDomains', function (req, res) {
    var id = req.cookies.userid;
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var userid = parseInt(req.body.id);
        var url = apiurl + "api/domains";
        var urll = apiurl + "api/users";
        console.log(url);
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            console.log(response.body)
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});

                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    var obj_data = response.body.data;
                    // res.send({"success":obj_data});
                    request({
                        url: urll,
                        method: "GET",
                        json: true,
                    }, function (err, response, body) {
                        console.log(response.body)
                        if (err) {
                            console.log(err.stack);
                            res.send('Error while accessing API ');
                        } else {
                            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                                console.log('error ::: ' + response.statusCode);
                                if (response.statusCode === 404) {
                                    console.log(response.body.error.message)
                                    res.send({"error": "URL Not Found " + urll});
                                } else {
                                    console.log(response.body.error.message)
                                    res.send({"error": response.body.error.message});

                                }

                            }
                            else if (response.statusCode === 200 || response.statusCode === 201) {
                                var obj_user = response.body.data;
                                var result = JSON.stringify(obj_data) + "-" + JSON.stringify(obj_user);
                                res.send({"success": result});

                            } else {
                                res.send({"error": "API Error"});
                            }

                        }
                    });


                } else {
                    res.send({"error": "API Error"});
                }

            }
        });
    }
});

router.post('/domainName', function (req, res) {
    var id = req.cookies.userid;
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var userid = parseInt(req.body.id);
        var url = apiurl+"api/domains";
        console.log(url);
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            console.log(response.body)
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});
                    }
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    var obj_data=response.body.data;
                    res.send({"success":obj_data});
                } else {
                    res.send({"error": "API Error"});
                }

            }
        });
    }


});

router.post('/SingleDomain', function (req, res) {
    var id = req.cookies.userid;
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var domainId = parseInt(req.body.domainId);
        console.log("HI HI HI HI HI HI HI "+domainId);
        var filter={"fields":["id","dId","ip"]}
        var url = apiurl+"api/domains/"+domainId;
        var urll=apiurl+"api/ips/domain/"+domainId+"?filter="+JSON.stringify(filter);
        console.log(urll);
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            console.log(response.body)
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});

                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    if(response.body.data != undefined){
                        var data_first=response.body.data;

                        request({
                            url: urll,
                            method: "GET",
                            json: true,
                        }, function (err, response, body) {
                            console.log(response.body)
                            if (err) {
                                console.log(err.stack);
                                res.send('Error while accessing API ');
                            } else {
                                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                                    console.log('error ::: ' + response.statusCode);
                                    if (response.statusCode === 404) {
                                        console.log(response.body.error.message)
                                        res.send({"error": "URL Not Found " + urll});
                                    } else {
                                        console.log(response.body.error.message)
                                        res.send({"error": response.body.error.message});

                                    }

                                }
                                else if (response.statusCode === 200 || response.statusCode === 201) {
                                    if(response.body.data != undefined){

                                        var data_second=response.body.data;
                                        var result = JSON.stringify(data_first) + "^" + JSON.stringify(data_second);
                                        //console.log(result+"0000000000000000000000000000");
                                        res.send({"success": result});

                                    }
                                    else{
                                        res.send({"error": "API Error"});
                                    }


                                } else {
                                    res.send({"error": "API Error"});
                                }

                            }
                        });
                    }
                    else{
                        res.send({"error": "API Error"});
                    }


                } else {
                    res.send({"error": "API Error"});
                }

            }
        });

    }


});

router.post('/startEND', function (req, res) {
    var id = req.cookies.userid;

    var withipid=req.body.withIp;
    console.log("99999"+JSON.stringify(withipid));
    var FROM=withipid.from;
    var TO=withipid.to;
    var DID=withipid.did;
    console.log(FROM+"----"+TO+"---"+DID);
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        if(withipid.IpId){
            var ipId=withipid.IpId;
        }
        var espid=withipid.espId;
        console.log(ipId+"==="+espid);
        if(ipId){
            var url2=apiurl+"api/statsDiIp/getBwtnDates?from="+FROM+"&to="+TO+"&dId="+DID+"&ipId="+parseInt(ipId)+"&espId="+espid;
        }if(!ipId){
            var url2=apiurl+"api/statsDiDomain/getBwtnDates?from="+FROM+"&to="+TO+"&dId="+DID+"&espId="+espid;
        }
        console.log(url2);
        request({
            url: url2,
            method: "POST",
            json: true,
        }, function (err, response, body) {
            console.log(response.body)
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url2});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});

                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    if(response.body.data != undefined){
                        var data_THIRD=response.body.data;
                        res.send({"success":data_THIRD})
                    }
                    else{
                        res.send({"error": "API Error"});
                    }


                } else {
                    res.send({"error": "API Error"});
                }

            }
        });

    }


});
router.post('/updateDomain', function (req, res) {
    var id = req.cookies.userid;

    var newIP=req.body.addIP;
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var where={"ip":newIP.ip,"hostName":newIP.hostName};
        var url1=apiurl+"api/ips/count?where="+JSON.stringify(where);
        var url2=apiurl+"api/ips/create";
        console.log(url2);
        console.log(url1);
        request({
            url: url1,
            method: "GET",
        }, function (err, response, body) {
            console.log(response.body)
            console.log(JSON.parse(response.body).data.count);
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url1});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});

                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    if(JSON.parse(response.body).data.count != undefined){
                        if(JSON.parse(response.body).data.count==0) {
                            request({
                                url: url2,
                                method: "POST",
                                json: true,
                                body:newIP

                            }, function (err, response, body) {
                                if (err) {
                                    console.log(err.stack);
                                    res.send('Error while accessing API ');
                                } else {
                                    if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                                        console.log('error ::: ' + response.statusCode);
                                        if (response.statusCode === 404) {
                                            console.log(response.body.error.message)
                                            res.send({"error": "URL Not Found " + url2});
                                        } else {
                                            console.log(response.body.error.message)
                                            res.send({"error": response.body.error.message});

                                        }

                                    }
                                    else if (response.statusCode === 200 || response.statusCode === 201) {
                                        if(response.body.data != undefined){
                                            var data_D2=response.body.data;
                                            console.log(JSON.stringify(data_D2)+"second");
                                            res.send({"success":data_D2})

                                        }
                                        else{
                                            res.send({"error": "API Error"});
                                        }


                                    } else {
                                        res.send({"error": "API Error"});
                                    }

                                }
                            });

                        }else if(JSON.parse(response.body).data.count>0){
                            res.send({"success":"domain already exist with this ip and host name"})
                        }
                    }
                    else {
                        res.send({"error": "API Error"});
                    }


                } else {
                    res.send({"error": "API Error"});
                }

            }
        });

    }


});

router.post('/viewIPS', function (req, res) {
    var id = req.cookies.userid;
    var domainId = parseInt(req.body.domainId);
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var userid = parseInt(req.body.id);
        var url=apiurl+"api/ips/domain/"+domainId;
        console.log(url);
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            console.log(response.body)
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});

                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    var obj_data=response.body.data;
                    res.send({"success":obj_data});
                } else {
                    res.send({"error": "API Error"});
                }

            }
        });
    }


});
router.post('/saveIP', function (req, res) {
    var id = req.cookies.userid;
    var ipId=req.body.ID;
    var IP=req.body.ip;
    var HOSTNAME=req.body.hostName;
    var FROMMAIL=req.body.fromMail;
    var REPLYMAIL=req.body.replyMail;
    var BOUNCEMAIL=req.body.bounceMail;
    var CAPACITY=req.body.capacity;
    var CURPUSH=req.body.curPush;
    var DBIP=req.body.dbip;

    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {

        var url2=apiurl+"api/ips/update/"+ipId;

        console.log(url2);
        request({
            url: url2,
            method: "POST",
            body:{"ip": IP, "hostName": HOSTNAME, "fromMail": FROMMAIL, "replyMail": REPLYMAIL, "bounceMail": BOUNCEMAIL, "capacity": CAPACITY,"curPush": CURPUSH,"dbip": DBIP},
            json: true,
        }, function (err, response, body) {
            console.log(response.body)
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url2});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});

                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    if(response.body.data != undefined){
                        var data_D=response.body.data;
                        res.send({"success":data_D})
                    }
                    else{
                        res.send({"error": "API Error"});
                    }


                } else {
                    res.send({"error": "API Error"});
                }

            }
        });

    }


});
router.post('/removeIP', function (req, res) {
    var id = req.cookies.userid;
    var ipId=req.body.ID;
    var stat1=req.body.stat;
    if(stat1==1){
        var abc=1;
    }else{
        var abc=0;
    }
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {

        var url2=apiurl+"api/ips/update/"+ipId;

        console.log(url2);
        request({
            url: url2,
            method: "POST",
            body:{"status": abc},
            json: true,
        }, function (err, response, body) {
            console.log(response.body)
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url2});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});

                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    if(response.body.data != undefined){
                        var data_D=response.body.data;
                        res.send({"success":data_D})
                    }
                    else{
                        res.send({"error": "API Error"});
                    }


                } else {
                    res.send({"error": "API Error"});
                }

            }
        });

    }


});

router.post('/updateCP', function (req, res) {
    var id = req.cookies.userid;

    var dID=req.body.did;
    var espid=req.body.espId;
    var cp=req.body.CP;
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {

        var url2=apiurl+"api/domains/upsertESP?dId="+dID+"&espId="+parseInt(espid);

        console.log(url2)
        request({
            url: url2,
            method: "POST",
            body:{"CP":parseInt(cp)},
            json: true,
        }, function (err, response, body) {
            console.log(response.body)
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url2});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});

                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    if(response.body.data != undefined){
                        var data_D=response.body.data;
                        res.send({"success":data_D})
                    }
                    else{
                        res.send({"error": "API Error"});
                    }


                } else {
                    res.send({"error": "API Error"});
                }

            }
        });

    }


});



router.post('/insRetarget',function(req,res){

    var body = req.body;
//  console.log(JSON.stringify(body));
    processobjec(body);
    res.send();


});



function processobjec(body) {
    //console.log("body :: " + JSON.stringify(body));
    var date1 = new Date().toISOString().substr(0, 10);
    var date = new Date(date1 + " 00:00:00")
    var unixtimes = date.getTime() / 1000;
    //console.log("unixtimes :: "+unixtimes);
    if (body.email != undefined && body.email != null) {
        // console.log(apiurl + 'api/subscriber/profile/email/' + encodeURIComponent(body.email));
        request({

            method: 'GET',
            url: apiurl + 'api/subscriber/email/' + encodeURIComponent(body.email)

        }, function (error, response, then) {
            if (error) {
                console.log(error.stack);
            }
            else {
                //console.log("else response news" + JSON.stringify(response));
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                    console.log('NEws error STEP2 ' + response.statusCode);
                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    //  console.log('Getting news STEP2: ' + JSON.stringify(response.body.data));
                    //  console.log(typeof response.body);
                    var body1 = JSON.parse(response.body);
                    if (body1.data != undefined && body1.data.id != undefined) {
                        var finalobj = {
                            "campId": 0,
                            "nlmId": 0,
                            "nlId": 0,
                            "rType": 1,
                            "userId": 0,
                            "linkId": 0,
                            "startAt": unixtimes
                        };
                        // console.log("111111");
                        if (body.dId != undefined) {
                            finalobj.dId = body.dId;
                            if (body.eDomain != undefined) {
                                if (body.eDomain.indexOf('gmail') > -1) {
                                    finalobj.eDomain = 1;
                                }
                                else if (body.eDomain.indexOf('yahoo') > -1) {
                                    finalobj.eDomain = 2;
                                }
                                else if (body.eDomain.indexOf('hotmail') > -1) {
                                    finalobj.eDomain = 3
                                }
                                else if (body.eDomain.indexOf('msn') > -1) {
                                    finalobj.eDomain = 5;
                                }
                                else if (body.eDomain.indexOf('outlook') > -1) {
                                    finalobj.eDomain = 5;
                                }
                                else if (body.eDomain.indexOf('aol') > -1) {
                                    finalobj.eDomain = 3;
                                }
                                else {
                                    finalobj.eDomain = 6;
                                }
                                if (body.dType != undefined) {
                                    var targtesf={"dType": body.dType};

                                    finalobj.subId = body1.data.id;
                                    var counntry=body.ocountry;
                                    counntry=counntry.toLowerCase();
                                    // console.log("countryyyy :: "+counntry);
                                    request({
                                        method: 'GET',
                                        url: apiurl + 'api/countries/name/' +counntry

                                    }, function (error, response, then) {
                                        if (error) {
                                            console.log(error.stack);
                                        }
                                        else {
                                            //  console.log("else response news");
                                            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                                console.log('NEws error STEP2 ' + response.statusCode);
                                            }
                                            else if (response.statusCode === 200 || response.statusCode === 201) {

                                                var bodyss=JSON.parse(response.body);
                                                // console.log("bodyss.body  :: "+bodyss.data.id);
                                                if(bodyss.data!=undefined && bodyss.data.id!=undefined)
                                                {
                                                    targtesf.country =  bodyss.data.id
                                                }


                                                request({

                                                    method: 'GET',
                                                    url: apiurl + 'api/cities/name/' + (body.ocity).toLowerCase()

                                                }, function (error, response, then) {
                                                    if (error) {
                                                        console.log(error.stack);
                                                    }
                                                    else {
                                                        //  console.log("else response news");
                                                        if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                                            console.log('NEws error STEP2 ' + response.statusCode);
                                                        }
                                                        else if (response.statusCode === 200 || response.statusCode === 201) {

                                                            var bodyss=JSON.parse(response.body);
                                                            //console.log("bodyss.body  :: "+bodyss.data.id);
                                                            if(bodyss.data!=undefined && bodyss.data.id!=undefined)
                                                            {
                                                                targtesf.city =  bodyss.data.id
                                                            }
                                                            if(body.domain!=undefined)
                                                            {
                                                                finalobj.domain = body.domain;
                                                                finalobj.targets =targtesf
                                                                // console.log("INSERT DIRECTTTTTTTT");
                                                                insertFinalRet(finalobj);
                                                            }


                                                        }
                                                        else {

                                                        }
                                                    }

                                                });

                                            }
                                            else {

                                            }
                                        }

                                    });
                                }


                            }

                        }

                    }
                    else {
                        // console.log("NO DATA FOUND IN NEO00" + body.source);

                        if (body.source != undefined && body.source != null) {
                            // console.log(apiurl + 'api/sources/name/' + body.source);
                            request({
                                url: apiurl + 'api/sources/name/' + body.source,
                                method: "GET"
                            }, function (error, response, then) {
                                if (error) {
                                    console.log(error.stack);
                                }
                                else {
                                    // console.log("AAAAAA :: " + JSON.stringify(response));
                                    if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                        console.log('NEws error STEP2 ' + response.statusCode);
                                    }
                                    else if (response.statusCode === 200 || response.statusCode === 201) {


                                        var body1 = JSON.parse(response.body);
                                        //  console.log("22222 :L: " + JSON.stringify(body1));
                                        if (body1.data != undefined && body1.data != null && body1.data.id != null) {


                                            var createneo={};
                                            createneo["source"] = body1.data.id;
                                            createneo["email"] = body.email;
                                            var neoObj = {};

                                            if (body.profile!=undefined && body.profile.gend != undefined) {
                                                if (body.profile.gend == 'f') {

                                                    neoObj["gender"] = 2;
                                                }
                                                if (body.profile.gend == 'm') {

                                                    neoObj["gender"] = 1;
                                                }
                                            }
                                            if (body.profile!=undefined &&  body.profile.doy != undefined) {
                                                neoObj["yob"] = body.profile.doy;

                                            }
                                            if (body.name != undefined) {

                                                createneo["name"] = body.name;
                                            }
                                            var finalobj = {
                                                "campId": 0,
                                                "nlmId": 0,
                                                "nlId": 0,
                                                "rType": 1,
                                                "userId": 0,
                                                "linkId": 0,
                                                "startAt": unixtimes
                                            };
                                            if (body.dId != undefined) {
                                                finalobj.dId = body.dId;
                                                if (body.eDomain != undefined) {
                                                    if (body.eDomain.indexOf('gmail') > -1) {
                                                        finalobj.eDomain = 1;
                                                        createneo["eDomain"] = 1;
                                                    }
                                                    else if (body.eDomain.indexOf('yahoo') > -1) {
                                                        finalobj.eDomain = 2;
                                                        createneo["eDomain"] = 2;
                                                    }
                                                    else if (body.eDomain.indexOf('hotmail') > -1) {
                                                        finalobj.eDomain = 3
                                                        createneo["eDomain"] = 3;
                                                    }
                                                    else if (body.eDomain.indexOf('msn') > -1) {
                                                        finalobj.eDomain = 5;
                                                        createneo["eDomain"] = 5;
                                                    }
                                                    else if (body.eDomain.indexOf('outlook') > -1) {
                                                        finalobj.eDomain = 5;
                                                        createneo["eDomain"] = 3;
                                                    }
                                                    else if (body.eDomain.indexOf('aol') > -1) {
                                                        finalobj.eDomain = 3;
                                                        createneo["eDomain"] = 4;
                                                    }
                                                    else {
                                                        finalobj.eDomain = 6;
                                                        createneo["eDomain"] = 6;
                                                    }


                                                    if (body.dType != undefined) {
                                                        var targtesf={"dType": body.dType};

                                                        finalobj.subId = body1.data.id;
                                                        var counntry=body.ocountry;
                                                        counntry=counntry.toLowerCase();
                                                        console.log("countryyyy :: "+counntry);
                                                        request({
                                                            method: 'GET',
                                                            url: apiurl + 'api/countries/name/' +counntry

                                                        }, function (error, response, then) {
                                                            if (error) {
                                                                console.log(error.stack);
                                                            }
                                                            else {
                                                                //  console.log("else response news");
                                                                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                                                    console.log('NEws error STEP2 ' + response.statusCode);
                                                                }
                                                                else if (response.statusCode === 200 || response.statusCode === 201) {
                                                                    //console.log("response.body  :: "+response.body.data.id);
                                                                    var bodyss=JSON.parse(response.body);
                                                                    //console.log("bodyss.body  :: "+bodyss.data.id);
                                                                    if(bodyss.data!=undefined && bodyss.data.id!=undefined)
                                                                    {
                                                                        targtesf.country =  bodyss.data.id
                                                                    }


                                                                    request({

                                                                        method: 'GET',
                                                                        url: apiurl + 'api/cities/name/' + (body.ocity).toLowerCase()

                                                                    }, function (error, response, then) {
                                                                        if (error) {
                                                                            console.log(error.stack);
                                                                        }
                                                                        else {
                                                                            //  console.log("else response news");
                                                                            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                                                                console.log('NEws error STEP2 ' + response.statusCode);
                                                                            }
                                                                            else if (response.statusCode === 200 || response.statusCode === 201) {

                                                                                var bodyss=JSON.parse(response.body);
                                                                                //console.log("bodyss.body  :: "+bodyss.data.id);
                                                                                if(bodyss.data!=undefined && bodyss.data.id!=undefined)
                                                                                {
                                                                                    targtesf.city =  bodyss.data.id
                                                                                }
                                                                                if (body.domain != undefined) {
                                                                                    finalobj.targets =targtesf;
                                                                                    finalobj.domain = body.domain;
                                                                                    console.log("HAD SOURCEEEEEEEE");
                                                                                    insertNeo(neoObj, finalobj, createneo);
                                                                                }


                                                                            }
                                                                            else {

                                                                            }
                                                                        }

                                                                    });

                                                                }
                                                                else {

                                                                }
                                                            }

                                                        });
                                                    }


                                                }

                                            }

                                        }
                                        else {
                                            //console.log("NO DATA FOUND IN SOURCEEEEE" + body.source);
                                            var sources = body.source;
                                            request({
                                                url: apiurl + 'api/sources/create',
                                                method: "POST",
                                                json: true,
                                                body: {"name": sources}

                                            }, function (error, response, then) {
                                                if (error) {
                                                    console.log(error.stack);
                                                }
                                                else {
                                                    // console.log("else response news" + JSON.stringify(response));
                                                    if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                                        console.log('NEws error STEP2 ' + response.statusCode);
                                                    }
                                                    else if (response.statusCode === 200 || response.statusCode === 201) {

                                                        var body1 = response.body;
                                                        if (body1.data != undefined && body1.data.id != undefined) {
                                                            var createneo={};
                                                            createneo["source"] = body1.data.id;
                                                            createneo["email"] = body.email;
                                                            var neoObj = {};
                                                            if (body.profile!=undefined &&  body.profile.gend != undefined) {
                                                                if (body.profile.gend == 'f') {

                                                                    neoObj["gender"] = 2;
                                                                }
                                                                if (body.profile.gend == 'm') {

                                                                    neoObj["gender"] = 1;
                                                                }
                                                            }
                                                            if (body.profile!=undefined &&  body.profile.doy != undefined) {
                                                                neoObj["yob"] = body.profile.doy;

                                                            }
                                                            if (body.name != undefined) {

                                                                createneo["name"] = body.name;
                                                            }

                                                            var finalobj = {
                                                                "campId": 0,
                                                                "nlmId": 0,
                                                                "nlId": 0,
                                                                "rType": 1,
                                                                "userId": 0,
                                                                "linkId": 0,
                                                                "startAt": unixtimes
                                                            };
                                                            if (body.dId != undefined) {
                                                                finalobj.dId = body.dId;
                                                                if (body.eDomain != undefined) {
                                                                    if(body.eDomain.indexOf('gmail') > -1)
                                                                    {
                                                                        finalobj.eDomain = 1;
                                                                        createneo["eDomain"] =1;
                                                                    }
                                                                    else if(body.eDomain.indexOf('yahoo') > -1)
                                                                    {
                                                                        finalobj.eDomain = 2;
                                                                        createneo["eDomain"] =2;
                                                                    }
                                                                    else if(body.eDomain.indexOf('hotmail') > -1)
                                                                    {
                                                                        finalobj.eDomain = 3
                                                                        createneo["eDomain"] =3;
                                                                    }
                                                                    else if(body.eDomain.indexOf('msn') > -1)
                                                                    {
                                                                        finalobj.eDomain = 5;
                                                                        createneo["eDomain"] =5;
                                                                    }
                                                                    else if(body.eDomain.indexOf('outlook') > -1)
                                                                    {
                                                                        finalobj.eDomain = 5;
                                                                        createneo["eDomain"] =3;
                                                                    }
                                                                    else if(body.eDomain.indexOf('aol') > -1)
                                                                    {
                                                                        finalobj.eDomain =3;
                                                                        createneo["eDomain"] =4;
                                                                    }
                                                                    else
                                                                    {
                                                                        finalobj.eDomain =6;
                                                                        createneo["eDomain"] =6;
                                                                    }

                                                                    if (body.dType != undefined) {
                                                                        var targtesf={"dType": body.dType};


                                                                        finalobj.subId = body1.data.id;
                                                                        var counntry=body.ocountry;
                                                                        counntry=counntry.toLowerCase();
                                                                        console.log("countryyyy :: "+counntry);
                                                                        request({
                                                                            method: 'GET',
                                                                            url: apiurl + 'api/countries/name/' +counntry

                                                                        }, function (error, response, then) {
                                                                            if (error) {
                                                                                console.log(error.stack);
                                                                            }
                                                                            else {
                                                                                //  console.log("else response news");
                                                                                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                                                                    console.log('NEws error STEP2 ' + response.statusCode);
                                                                                }
                                                                                else if (response.statusCode === 200 || response.statusCode === 201) {

                                                                                    console.log("response.body  :: "+response.body.data.id);
                                                                                    var bodyss=JSON.parse(response.body);
                                                                                    // console.log("bodyss.body  :: "+bodyss.data.id);
                                                                                    if(bodyss.data!=undefined && bodyss.data.id!=undefined)
                                                                                    {
                                                                                        targtesf.country =  bodyss.data.id
                                                                                    }


                                                                                    request({

                                                                                        method: 'GET',
                                                                                        url: apiurl + 'api/cities/name/' + (body.ocity).toLowerCase()

                                                                                    }, function (error, response, then) {
                                                                                        if (error) {
                                                                                            console.log(error.stack);
                                                                                        }
                                                                                        else {
                                                                                            //  console.log("else response news");
                                                                                            if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                                                                                console.log('NEws error STEP2 ' + response.statusCode);
                                                                                            }
                                                                                            else if (response.statusCode === 200 || response.statusCode === 201) {

                                                                                                var bodyss=JSON.parse(response.body);
                                                                                                // console.log("bodyss.body  :: "+bodyss.data.id);
                                                                                                if(bodyss.data!=undefined && bodyss.data.id!=undefined)
                                                                                                {
                                                                                                    targtesf.city =  bodyss.data.id
                                                                                                }
                                                                                                if (body.domain != undefined) {
                                                                                                    finalobj.targets =targtesf
                                                                                                    finalobj.domain = body.domain;
                                                                                                    console.log("CREATEEEE SOURCEEEEE");
                                                                                                    insertNeo(neoObj, finalobj,createneo);
                                                                                                }


                                                                                            }
                                                                                            else {

                                                                                            }
                                                                                        }

                                                                                    });

                                                                                }
                                                                                else {

                                                                                }
                                                                            }

                                                                        });
                                                                    }
                                                                }

                                                            }

                                                        }

                                                    }
                                                    else {

                                                    }
                                                }

                                            })


                                        }
                                    }
                                    else {
                                    }
                                }

                            });
                        }
                    }
                }
                else {

                }
            }

        })

    }


    function insertNeo(neoobj, finalobj,createneo) {
        // console.log(neoobj);
        // console.log(finalobj);
        request({
            method: 'POST',
            url: apiurl + 'api/subscriber/create',
            json: true,
            body: createneo

        }, function (error, response, then) {
            if (error) {
                console.log(error.stack);
            }
            else {
                // console.log("else response news" + JSON.stringify(response));
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                    console.log('NEws error STEP2 ' + response.statusCode);

                  /*    console.log(JSON.parse(response.body.toString()).error);
                   console.log(JSON.parse(response.body.toString()).error.message);*/

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    // console.log("inserted neo succesfullyyy" + JSON.stringify(response));
                    var body1=response.body;
                    if(body1.data!=undefined && body1.data.id!=undefined)
                    {
                        finalobj.subId = body1.data.id;

                        request({

                            method:'POST',
                            url:apiurl+'api/subscriber/update/profile/'+body1.data.id,
                            json: true,
                            body: neoobj
                        },function(error,response,then){
                            if(error)
                            {
                                console.log(error.stack);
                            }
                            else{
                                // console.log("else response news");
                                if(response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500){
                                    console.log('NEws error STEP2 ' + response.statusCode);

                                  /*    console.log(JSON.parse(response.body.toString()).error);
                                   console.log(JSON.parse(response.body.toString()).error.message);*/

                                }
                                else if (response.statusCode === 200 || response.statusCode === 201){

                                    var body1=response.body;
                                    if(body1.data!=undefined)
                                    {
                                        insertFinalRet(finalobj);


                                    }
                                }
                                else
                                {

                                }
                            }

                        });
                    }
                }
                else {

                }
            }

        });

    }

    function insertFinalRet(finalobj) {



        // console.log("finalobj :: "+JSON.stringify(finalobj));
        var filter={"where":{"name":finalobj.domain}};

        //console.log(apiurl+'api/domains?filter='+JSON.stringify(filter));
        request({

            method:'GET',
            url:apiurl+'api/domains?filter='+JSON.stringify(filter)

        },function(error,response,then){
            if(error)
            {
                console.log(error.stack);
            }
            else{
                //  console.log("else response news");
                if(response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500){
                    console.log('NEws error STEP2 ' + response.statusCode);
                }
                else if (response.statusCode === 200 || response.statusCode === 201){


                    var body2=JSON.parse(response.body);
                    //console.log("body2 :: "+JSON.stringify(body2));
                    var data1=body2.data;
                    // console.log("data1 :: "+JSON.stringify(data1));
                    if(data1!=undefined && data1.length>0)
                    {
                        finalobj.dId=data1[0].id;
                        //console.log(apiurl + 'api/RetargetData/upsert?subId=' + finalobj.subId);
                        request({

                            method: 'POST',
                            url: apiurl + 'api/RetargetData/upsert?subId=' + finalobj.subId,
                            json: true,
                            body: finalobj

                        }, function (error, response, then) {
                            if (error) {
                                console.log(error.stack);
                            }
                            else {
                                // console.log("else response news" + JSON.stringify(response));
                                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                                    console.log('NEws error STEP2 ' + response.statusCode);
                                }
                                else if (response.statusCode === 200 || response.statusCode === 201) {
                                    // console.log("DATA INSERTEDDDDDDDDDD SUCCEFULLLYYYYYYYY");

                                }
                                else {

                                }
                            }

                        });
                    }
                    else {

                        console.log("NO DOMAIN FOUNDDDDDDDDD");

                    }


                }
                else
                {

                }
            }

        });
    }

}






//DATA ANALYTICS


router.post('/countryData', function (req, res) {
    var id = req.cookies.userid;
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        /* var domainId = parseInt(req.body.domainId);
         console.log("HI HI HI HI HI HI HI "+domainId);*/
        var url = apiurl+"api/countries/";
        console.log(url);
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            console.log(response.body)
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});

                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    if(response.body.data != undefined){
                        var data=response.body.data;
                        console.log("HI HI HI HI data"+JSON.stringify(data));
                        res.send({"success": data});
                    }
                    else{
                        res.send({"error": "API Error"});
                    }


                } else {
                    res.send({"error": "API Error"});
                }

            }
        });
    }


});








router.post('/createTarget', function (req, res) {
    var target = (req.body.target);
    console.log(target);
    console.log("target query is : ",(target));
    // console.log(selectedDate);
    var id = req.cookies.userid;
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var url = apiurl+"api/daQueries";
        console.log(url);
        request({
            url: url,
            method: "POST",
            json: true,
            body:target
        }, function (err, response, body) {
            console.log(response.body)
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        console.log("error 400 is occured");
                        res.send({"error": response.body.error.message});

                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    if(response.body.data != undefined){

                        var data=response.body.data;
                        console.log("data will be dispaly based on selected date"+JSON.stringify(data));
                        res.send({"success": data});
                    }
                    else{
                        res.send({"error": "API Error"});
                    }


                } else {
                    res.send({"error": "API Error"});
                }

            }
        });
    }


});



router.post('/allDataToday', function (req, res) {         //retrieving alldata(today)
    var id = req.cookies.userid;
    console.log("user id is:"+id);
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var url = apiurl+"api/daQueries/today/";
        console.log(url);
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            console.log(response.body)
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});

                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    if(response.body.data != undefined){
                        var data=response.body.data;
                        console.log("HI HI HI HI 123456789 hi hello"+JSON.stringify(data));
                        res.send({"success": data});
                    }
                    else{
                        res.send({"error": "API Error"});
                    }


                } else {
                    res.send({"error": "API Error"});
                }

            }
        });
    }


});





router.post('/getUserName', function (req, res) {                //to get the user name
    var myString = (req.body.myString);
    console.log("this  process");
    //console.log(myString);
    var userObj=myString;
    //console.log("this is the data");
    //console.log(userObj);
    var i=0;
    var datarr=[];
    getusername();
    function getusername() {
        if (i < userObj.length) {
            var uId = userObj[i].userId;
            //var mjson= {open:cityObj[i].uOpen,click:cityObj[i].uClick}
            if(parseInt(uId)!=0){
                request({
                    url: apiurl + 'api/users/' + parseInt(uId),
                    method: 'GET'
                }, function (err, response, body) {
                    if (err) {
                        console.log(err.stack);
                        res.send('Error getStatsCity while accessing API');
                    } else {
                        if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500) {
                            console.log('step6 getStatsCity get error ' + response.statusCode);
                            console.log(JSON.stringify(response.body));
                            res.send(response.body);
                        }
                        else if (response.statusCode === 200 || response.statusCode === 201) {
                            var tempObj = JSON.parse(response.body).data;
                            // console.log("tempObj is"+JSON.stringify(tempObj));
                            var userName= tempObj.name;
                            // console.log("userName is"+JSON.stringify(userName));
                            datarr.push(userName);
                           // console.log("datarr is"+JSON.stringify(datarr));
                            //console.log("datarr getStatsCity LL  "+JSON.stringify(datarr));
                            i++;
                            setImmediate(getusername);
                        } else {
                            res.send('unknown error from API getStatsCity : ' + response.statusCode);
                        }
                    }
                });
            }/*else{
             mjson.name='';
             datarr.push(mjson);
             //console.log("city with id 0  "+JSON.stringify(datarr));
             i++;
             setImmediate(getusername);
             }*/
        }
        else
        {
            //console.log("DATARRA getStatsCity :: "+JSON.stringify(datarr));
            res.send({"success":datarr});
        }
    }


});




router.post('/myRequestToday', function (req, res) {             //retrieving myrequest data(today)
    var id = req.cookies.userid;
    console.log("user id is:"+id);
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var url = apiurl+"api/daQueries/today/user/"+id;
        console.log(url);
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            console.log(response.body)
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});

                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    if(response.body.data != undefined){
                        var data=response.body.data;
                        console.log("requested data is "+JSON.stringify(data));
                        res.send({"success": data});
                    }
                    else{
                        res.send({"error": "API Error"});
                    }
                } else {
                    res.send({"error": "API Error"});
                }

            }
        });
    }


});


router.post('/allDataOntime', function (req, res) {                 //retrieving all data(ondate)
    var selectedDate = parseInt(req.body.selectedDate);
    var todayDate=parseInt(req.body.todayDate);
    console.log("todayDate:",parseInt(selectedDate)+ "selectedDate  : ",parseInt(selectedDate));
    // console.log(selectedDate);
    var id = req.cookies.userid;
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var url = apiurl+"api/daQueries/inSpan?from="+selectedDate+"&to="+todayDate;
        console.log(url);
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            console.log(response.body)
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});

                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    if(response.body.data != undefined){
                        var data=response.body.data;
                        console.log("all data will be dispaly based on selected date"+JSON.stringify(data));
                        res.send({"success": data});
                    }
                    else{
                        res.send({"error": "API Error"});
                    }


                } else {
                    res.send({"error": "API Error"});
                }

            }
        });
    }


});

router.post('/myRequestOntime', function (req, res) {                 //retrieving myrequest data(ondate)
    var selectedDate = parseInt(req.body.selectedDate);
    var todayDate=parseInt(req.body.todayDate);
    console.log("todayDate:",parseInt(selectedDate)+ "selectedDate  : ",parseInt(selectedDate));
    console.log("selectedDate  : ",parseInt(selectedDate));
    // console.log(selectedDate);
    var id = req.cookies.userid;
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var url = apiurl+"api/daQueries/inSpan/user/"+id+"?from="+selectedDate+"&to="+todayDate;
        console.log(url);
        request({
            url: url,
            method: "GET",
            json: true,
        }, function (err, response, body) {
            console.log(response.body)
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404) {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        res.send({"error": response.body.error.message});

                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    if(response.body.data != undefined){
                        var data=response.body.data;
                        console.log("requested data will be dispaly based on selected date"+JSON.stringify(data));
                        res.send({"success": data});
                    }
                    else{
                        res.send({"error": "API Error"});
                    }


                } else {
                    res.send({"error": "API Error"});
                }

            }
        });
    }


});

router.post('/putNotification', function (req, res) {                  //Notification

    // console.log('putNotification');
    var id = req.cookies.userid;


    var obj = (req.body.obj);
    console.log("obj query is : ",(obj));

    // console.log(url+" and obj putNotification  "+obj);
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        console.log('if failed');
        res.send('logout');
    } else {

        console.log('requesting putNotification');
        request({
            url: apiurl + "api/notifications/insert",
            method: "POST",
            json: true,
            body:obj
        }, function (err, response, body) {

            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API @putNotification');
            } else {

                //console.log(response.body)
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    console.log('error putNotification::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        //res.send({"error": "URL Not Found " + url});

                    } else {
                        console.log(response.body.error.message);
                        res.send({"error putNotification": response.body.error.message});
                        //socket.emit('addNotification', response.body.error.message);
                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201)
                {
                   /* var data=response.body.data;
                    res.send({"success": data});

                    //res.send(response.body.data);
                    console.log("Notification send");*/
                    var data=response.body.data;
                    res.send({"success": data});
                    console.log("putNotification res is"+JSON.stringify(data))

                } else
                {
                    res.send({"error": "putNotification API Error"});
                }

            }
        });


    }

});

router.post('/notifyUpdate', function (req, res) {
    var obj = (req.body.obj);
    console.log(obj);
    console.log("notifyUpdate is : ",(obj));
    // console.log(selectedDate);
    var id = req.cookies.userid;
    if (id === undefined || (JSON.stringify(id).indexOf('null') > -1)) {
        res.send('logout');
    } else {
        var url = apiurl+"api/daQueries/multiUpdate";
        console.log("updated111111111111111");
        request({
            url: url,
            method: "POST",
            json: true,
            body:obj
        }, function (err, response, body) {
            console.log(response.body)
            if (err) {
                console.log(err.stack);
                res.send('Error while accessing API ');
            } else {
                if (response.statusCode === 400 || response.statusCode === 401 || response.statusCode === 500 || response.statusCode === 404)
                {
                    console.log('error ::: ' + response.statusCode);
                    if (response.statusCode === 404) {
                        console.log(response.body.error.message)
                        res.send({"error": "URL Not Found " + url});
                    } else {
                        console.log(response.body.error.message)
                        console.log("error 400 is occured");
                        res.send({"error": response.body.error.message});

                    }

                }
                else if (response.statusCode === 200 || response.statusCode === 201) {
                    if(response.body.data != undefined){

                        var data=response.body.data;
                        res.send({"success": data});
                    }
                    else{
                        res.send({"error": "API Error"});
                    }


                } else {
                    res.send({"error": "API Error"});
                }

            }
        });
    }


});





module.exports = router;