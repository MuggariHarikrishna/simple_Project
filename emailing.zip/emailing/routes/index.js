var express = require('express');
var router = express.Router();

var user_mail="";
var inbox_data=[];
var MongoClient = require('mongodb').MongoClient;
/* GET home page. */
router.get('/', function(req, res, next) {
    res.render('index', { title: 'Express' });
});
router.post('/signup', function(req, res, next) {
    res.render('signup', { title: 'Express' });
});
router.get('/signup', function(req, res, next) {
    res.render('signup', { title: 'Express' });
});
router.post('/validate', function(req, res, next) {
    var item={
        email:req.body.email_n,
        password:req.body.password
    }
    user_mail=item.email;
    console.log(item);
    // Connect to the db
    var status="";
    MongoClient.connect("mongodb://localhost:27017/email", function(err, db) {
        if(!err) {
            console.log("We are connected");
            db.collection('email_users').findOne({new_email: item.email}, function(err, users) {
                if( !err && users ){
                    console.log("in the if");
                    if(item.password == users.password ) {
                        console.log("in the if if");
                        status="true";
                    }
                    else {
                        console.log("in the if else");
                        status = 'failed';
                    }
                }
                else {
                    console.log("in the else");
                    status= 'failed' ;
                }
                // console.log(users.new_email+"\t"+users.password+"req.query\t"+req.query.password);
                console.log("status=="+status);
                if(status=="true") {
                    console.log("documents==");
                    inbox_data=[];
                    MongoClient.connect('mongodb://localhost:27017/email', function (err, db) {
                        // assert.equal(null, err);
                        var cursor = db.collection('emails').find({'receiver':user_mail,'trash':'no'});
                        cursor.forEach(function (doc, err) {
                            //   assert.equal(null, err);
                            inbox_data.push(doc);
                        }, function () {
                            db.close();
                            inbox_data.forEach(function (doc, err) {
                            });
                            console.log("in the login");
                            for (var i = 0; i < inbox_data.length; i++)
                                console.log(inbox_data[i].sender )
                            res.render("inbox", {title:'Express',u_mail:user_mail,status:"",i_data:inbox_data});
                        });
                    });

                }
                else
                {
                    res.render('index', {title: 'Express',u_mail:user_mail,status:"",i_data:inbox_data});
                }
            });
        }
    });

});

router.post('/register', function(req, res, next) {
    var dob_d=req.body.d_day;
    var dob_m=req.body.d_month;
    var dob_y=req.body.d_year;
    var dobb=dob_d+":"+dob_m+":"+dob_y;
    var item={
        name:req.body.fullname,
        password:req.body.password,
        new_email:req.body.email_n,
        dob:dobb,
        gender:req.body.gender,
        state:req.body.state,
        email:req.body.email,
        phno:req.body.phno
    };
    user_mail=item.new_email;
    //console.log("item is:"+item.name+"\t"+item.password+"\t"+item.new_email+"\t"+item.dob+"\t"+item.gender+"\t"+item.state+"\t"+item.email+"\t"+item.phno);
    // Connect to the db
    MongoClient.connect("mongodb://localhost:27017/email", function(err, db) {
        if(!err) {
            console.log("We are connected");
            db.collection("email_users").insertOne(item, function(err, res) {
                if (err) throw err;
                console.log("1 record inserted");
                db.close();
            });
        }
    });
    res.render('index', { title: 'Express',i_data:inbox_data });
});

router.post('/insert', function(req, res, next) {
    var item={
        sender:req.body.f_email,
        receiver:req.body.to_email,
        subject:req.body.subject,
        message:req.body.msg,
        trash:"no"
    };
    console.log("sender=="+item.sender+"\treceiver=="+item.receiver+"\tsubject=="+item.subject+"\tmessage=="+item.message+"\ttrash==no");
    MongoClient.connect("mongodb://localhost:27017/email", function(err, db) {
        if(!err) {
            console.log("We are connected");
            db.collection("emails").insertOne(item, function(err, res) {
                if (err) throw err;
                console.log("1 mail inserted");
                db.close();
            });
            res.render('inbox', { title: 'Express',u_mail:user_mail,status:"your_mail_sent",i_data:inbox_data });
        }
    });

});
router.get("/user_inbox",function (req,res,next) {
    inbox_data=[];
    MongoClient.connect('mongodb://localhost:27017/email', function (err, db) {
        // assert.equal(null, err);
        var cursor = db.collection('emails').find({'receiver':user_mail,'trash':'no'});
        cursor.forEach(function (doc, err) {
            //   assert.equal(null, err);
            inbox_data.push(doc);
        }, function () {
            db.close();
            inbox_data.forEach(function (doc, err) {
            });
            console.log("in the login");
            for (var i = 0; i < inbox_data.length; i++)
                console.log(inbox_data[i].sender )
            res.render("inbox", {title:'Express',u_mail:user_mail,status:"",i_data:inbox_data});
        });
    });
});


router.get('/user_sent', function(req, res, next) {

    inbox_data=[];
    MongoClient.connect('mongodb://localhost:27017/email', function (err, db) {
        // assert.equal(null, err);
        var cursor = db.collection('emails').find({'sender':user_mail,'trash':'no'});
        cursor.forEach(function (doc, err) {
            //   assert.equal(null, err);
            inbox_data.push(doc);
        }, function () {
            db.close();
            inbox_data.forEach(function (doc, err) {
            });
            console.log("in the login");
            for (var i = 0; i < inbox_data.length; i++)
                console.log(inbox_data[i].sender )
            res.render("sent", {title:'Express',u_mail:user_mail,status:"",i_data:inbox_data});
        });
    });
});


router.get('/user_trash', function(req, res, next) {

    inbox_data=[];
    MongoClient.connect('mongodb://localhost:27017/email', function (err, db) {
        // assert.equal(null, err);
        var cursor = db.collection('emails').find({
            $and:[
                {$or:[
                    {"sender" : user_mail},
                    {"receiver" : user_mail}
                ]},
                {"trash": "yes"}
            ]});
        cursor.forEach(function (doc, err) {
            //   assert.equal(null, err);
            inbox_data.push(doc);
        }, function () {
            db.close();
            inbox_data.forEach(function (doc, err) {
            });
            console.log("in the login");
            for (var i = 0; i < inbox_data.length; i++)
                console.log(inbox_data[i].sender )
            res.render("trash", {title:'Express',u_mail:user_mail,status:"",i_data:inbox_data});
        });
    });
});

router.post('/inbox_delete', function(req, res, next) {
    var sender=req.body.sender;
    var receiver=req.body.receiver;
    var subject=req.body.subject;
    var message=req.body.message;
    var status="";
    console.log("inthe inbox delete");
    console.log("sender="+sender+"\nreceiver=="+receiver+"\nsubject=="+subject);
    MongoClient.connect('mongodb://localhost:27017/email', function(err, db) {
        if (err) throw err;
        var myquery = {sender:sender,receiver:receiver,subject:subject,message:message };

        db.collection("emails").updateOne(myquery,{$set:{'trash':'yes'}}, function(err, res) {
            if (err) throw err;
            else {
                console.log("1 record updated");
                status="Moved to Trash";
            }
            db.close();
        });
        inbox_data=[];
        MongoClient.connect('mongodb://localhost:27017/email', function (err, db) {
            var cursor = db.collection('emails').find({'receiver':user_mail,'trash':'no'});
            cursor.forEach(function (doc, err) {
                inbox_data.push(doc);
            }, function () {
                db.close();
                inbox_data.forEach(function (doc, err) {
                });
                console.log("in the login");
                for (var i = 0; i < inbox_data.length; i++)
                    console.log(inbox_data[i].sender )
                res.render("inbox", {title:'Express',u_mail:user_mail,status:status,i_data:inbox_data});
            });
        });
    });
});

router.post('/sent_delete', function(req, res, next) {
    var sender=req.body.sender;
    var receiver=req.body.receiver;
    var subject=req.body.subject;
    var message=req.body.message;
    var status="";
    console.log("inthe sent delete");
    console.log("sender="+sender+"\nreceiver=="+receiver+"\nsubject=="+subject);
    MongoClient.connect('mongodb://localhost:27017/email', function(err, db) {
        if (err) throw err;
        var myquery = {sender:sender,receiver:receiver,subject:subject,message:message };

        db.collection("emails").updateOne(myquery,{$set:{'trash':'yes'}}, function(err, res) {
            if (err) throw err;
            else {
                console.log("1 record updated");
                status="Moved to Trash";
            }
            db.close();
        });
        inbox_data=[];
            var cursor = db.collection('emails').find({'sender':user_mail,'trash':'no'});
            cursor.forEach(function (doc, err) {
                inbox_data.push(doc);
            }, function () {
                db.close();
                inbox_data.forEach(function (doc, err) {
                });
                console.log("in the login");
                for (var i = 0; i < inbox_data.length; i++)
                    console.log(inbox_data[i].sender )
                res.render("sent", {title:'Express',u_mail:user_mail,status:status,i_data:inbox_data});
            });
    });

});

router.post('/trash_delete', function(req, res, next) {
    var sender=req.body.sender;
    var receiver=req.body.receiver;
    var subject=req.body.subject;
    var message=req.body.message;
    var status="";
    console.log("inthe trash delete");
    console.log("sender="+sender+"\nreceiver=="+receiver+"\nsubject=="+subject);
    MongoClient.connect('mongodb://localhost:27017/email', function(err, db) {
        if (err) throw err;
        var myquery = {sender:sender,receiver:receiver,subject:subject,message:message,trash:'yes' };

        db.collection("emails").removeOne(myquery, function(err, res) {
            if (err) throw err;
            else {
                console.log("1 record updated");
                status="Deleted permanently";
            }
            db.close();
        });
        inbox_data=[];
        var cursor = db.collection('emails').find({'trash':'yes'});
        cursor.forEach(function (doc, err) {
            inbox_data.push(doc);
        }, function () {
            db.close();
            inbox_data.forEach(function (doc, err) {
            });
            console.log("in the login");
            for (var i = 0; i < inbox_data.length; i++)
                console.log(inbox_data[i].sender )
            res.render("trash", {title:'Express',u_mail:user_mail,status:status,i_data:inbox_data});
        });
    });
});

module.exports = router;
